"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

class OpenSearchService {
  constructor(osDriver) {
    _defineProperty(this, "osDriver", void 0);
    /**
     * Searches the provided index for documents with the provided IDs.
     */
    _defineProperty(this, "documentIdsQuery", async (context, request, response) => {
      try {
        const {
          index,
          documentIds
        } = request.body;
        const body = {
          query: {
            terms: {
              _id: documentIds
            }
          }
        };
        const params = {
          index,
          body: JSON.stringify(body)
        };
        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const searchResponse = await callWithRequest('search', params);
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: searchResponse
          }
        });
      } catch (error) {
        console.error('Security Analytics - OpenSearchService - documentIdsQuery:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });
    _defineProperty(this, "timeRangeQuery", async (context, request, response) => {
      try {
        const {
          index,
          timeField = 'timestamp',
          startTime = 'now-15m',
          endTime = 'now'
        } = request.query;
        const body = {
          query: {
            range: {
              [timeField]: {
                gte: startTime,
                lt: endTime
              }
            }
          }
        };
        const params = {
          index,
          body: JSON.stringify(body)
        };
        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const searchResponse = await callWithRequest('search', params);
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: searchResponse
          }
        });
      } catch (error) {
        console.error('Security Analytics - OpenSearchService - timeRangeQuery:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });
    _defineProperty(this, "getPlugins", async (context, request, response) => {
      try {
        const {
          callAsCurrentUser
        } = this.osDriver.asScoped(request);
        const plugins = await callAsCurrentUser('cat.plugins', {
          format: 'json',
          h: 'component'
        });
        return response.ok({
          body: {
            ok: true,
            response: plugins
          }
        });
      } catch (error) {
        console.error('Security Analytics - OpensearchService - getPlugins:', error);
        return response.ok({
          body: {
            ok: false,
            response: error.message
          }
        });
      }
    });
    this.osDriver = osDriver;
  }
}
exports.default = OpenSearchService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPcGVuU2VhcmNoU2VydmljZSIsImNvbnN0cnVjdG9yIiwib3NEcml2ZXIiLCJfZGVmaW5lUHJvcGVydHkiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiaW5kZXgiLCJkb2N1bWVudElkcyIsImJvZHkiLCJxdWVyeSIsInRlcm1zIiwiX2lkIiwicGFyYW1zIiwiSlNPTiIsInN0cmluZ2lmeSIsImNhbGxBc0N1cnJlbnRVc2VyIiwiY2FsbFdpdGhSZXF1ZXN0IiwiYXNTY29wZWQiLCJzZWFyY2hSZXNwb25zZSIsImN1c3RvbSIsInN0YXR1c0NvZGUiLCJvayIsImVycm9yIiwiY29uc29sZSIsIm1lc3NhZ2UiLCJ0aW1lRmllbGQiLCJzdGFydFRpbWUiLCJlbmRUaW1lIiwicmFuZ2UiLCJndGUiLCJsdCIsInBsdWdpbnMiLCJmb3JtYXQiLCJoIiwiZXhwb3J0cyIsImRlZmF1bHQiLCJtb2R1bGUiXSwic291cmNlcyI6WyJPcGVuU2VhcmNoU2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7XG4gIElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50LFxuICBJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZSxcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICBSZXNwb25zZUVycm9yLFxufSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IFNlcnZlclJlc3BvbnNlIH0gZnJvbSAnLi4vbW9kZWxzL3R5cGVzJztcbmltcG9ydCB7IERvY3VtZW50SWRzUXVlcnlQYXJhbXMsIFNlYXJjaFJlc3BvbnNlLCBUaW1lUmFuZ2VRdWVyeVBhcmFtcyB9IGZyb20gJy4uL21vZGVscy9pbnRlcmZhY2VzJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgT3BlblNlYXJjaFNlcnZpY2Uge1xuICBvc0RyaXZlcjogSUxlZ2FjeUN1c3RvbUNsdXN0ZXJDbGllbnQ7XG5cbiAgY29uc3RydWN0b3Iob3NEcml2ZXI6IElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50KSB7XG4gICAgdGhpcy5vc0RyaXZlciA9IG9zRHJpdmVyO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlYXJjaGVzIHRoZSBwcm92aWRlZCBpbmRleCBmb3IgZG9jdW1lbnRzIHdpdGggdGhlIHByb3ZpZGVkIElEcy5cbiAgICovXG4gIGRvY3VtZW50SWRzUXVlcnkgPSBhc3luYyAoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcbiAgKTogUHJvbWlzZTxcbiAgICBJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxTZXJ2ZXJSZXNwb25zZTxTZWFyY2hSZXNwb25zZTxhbnk+PiB8IFJlc3BvbnNlRXJyb3I+XG4gID4gPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGluZGV4LCBkb2N1bWVudElkcyB9ID0gcmVxdWVzdC5ib2R5IGFzIHsgaW5kZXg6IHN0cmluZzsgZG9jdW1lbnRJZHM6IHN0cmluZ1tdIH07XG4gICAgICBjb25zdCBib2R5ID0ge1xuICAgICAgICBxdWVyeToge1xuICAgICAgICAgIHRlcm1zOiB7XG4gICAgICAgICAgICBfaWQ6IGRvY3VtZW50SWRzLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgICAgY29uc3QgcGFyYW1zOiBEb2N1bWVudElkc1F1ZXJ5UGFyYW1zID0geyBpbmRleCwgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGNhbGxXaXRoUmVxdWVzdCB9ID0gdGhpcy5vc0RyaXZlci5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGNvbnN0IHNlYXJjaFJlc3BvbnNlOiBTZWFyY2hSZXNwb25zZTxhbnk+ID0gYXdhaXQgY2FsbFdpdGhSZXF1ZXN0KCdzZWFyY2gnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3BvbnNlOiBzZWFyY2hSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NlY3VyaXR5IEFuYWx5dGljcyAtIE9wZW5TZWFyY2hTZXJ2aWNlIC0gZG9jdW1lbnRJZHNRdWVyeTonLCBlcnJvcik7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIHRpbWVSYW5nZVF1ZXJ5ID0gYXN5bmMgKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICk6IFByb21pc2U8XG4gICAgSU9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2U8U2VydmVyUmVzcG9uc2U8U2VhcmNoUmVzcG9uc2U8YW55Pj4gfCBSZXNwb25zZUVycm9yPlxuICA+ID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qge1xuICAgICAgICBpbmRleCxcbiAgICAgICAgdGltZUZpZWxkID0gJ3RpbWVzdGFtcCcsXG4gICAgICAgIHN0YXJ0VGltZSA9ICdub3ctMTVtJyxcbiAgICAgICAgZW5kVGltZSA9ICdub3cnLFxuICAgICAgfSA9IHJlcXVlc3QucXVlcnkgYXMge1xuICAgICAgICBpbmRleDogc3RyaW5nO1xuICAgICAgICB0aW1lRmllbGQ6IHN0cmluZztcbiAgICAgICAgc3RhcnRUaW1lOiBzdHJpbmc7XG4gICAgICAgIGVuZFRpbWU6IHN0cmluZztcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IGJvZHkgPSB7XG4gICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgcmFuZ2U6IHtcbiAgICAgICAgICAgIFt0aW1lRmllbGRdOiB7XG4gICAgICAgICAgICAgIGd0ZTogc3RhcnRUaW1lLFxuICAgICAgICAgICAgICBsdDogZW5kVGltZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHBhcmFtczogVGltZVJhbmdlUXVlcnlQYXJhbXMgPSB7IGluZGV4LCBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlcjogY2FsbFdpdGhSZXF1ZXN0IH0gPSB0aGlzLm9zRHJpdmVyLmFzU2NvcGVkKHJlcXVlc3QpO1xuICAgICAgY29uc3Qgc2VhcmNoUmVzcG9uc2U6IFNlYXJjaFJlc3BvbnNlPGFueT4gPSBhd2FpdCBjYWxsV2l0aFJlcXVlc3QoJ3NlYXJjaCcsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcG9uc2U6IHNlYXJjaFJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgY29uc29sZS5lcnJvcignU2VjdXJpdHkgQW5hbHl0aWNzIC0gT3BlblNlYXJjaFNlcnZpY2UgLSB0aW1lUmFuZ2VRdWVyeTonLCBlcnJvcik7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldFBsdWdpbnMgPSBhc3luYyAoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcbiAgKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMub3NEcml2ZXIuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBjb25zdCBwbHVnaW5zID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2NhdC5wbHVnaW5zJywge1xuICAgICAgICBmb3JtYXQ6ICdqc29uJyxcbiAgICAgICAgaDogJ2NvbXBvbmVudCcsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwb25zZTogcGx1Z2lucyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NlY3VyaXR5IEFuYWx5dGljcyAtIE9wZW5zZWFyY2hTZXJ2aWNlIC0gZ2V0UGx1Z2luczonLCBlcnJvcik7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3BvbnNlOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7QUFhZSxNQUFNQSxpQkFBaUIsQ0FBQztFQUdyQ0MsV0FBV0EsQ0FBQ0MsUUFBb0MsRUFBRTtJQUFBQyxlQUFBO0lBSWxEO0FBQ0Y7QUFDQTtJQUZFQSxlQUFBLDJCQUdtQixPQUNqQkMsT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxLQUcxQztNQUNILElBQUk7UUFDRixNQUFNO1VBQUVDLEtBQUs7VUFBRUM7UUFBWSxDQUFDLEdBQUdILE9BQU8sQ0FBQ0ksSUFBZ0Q7UUFDdkYsTUFBTUEsSUFBSSxHQUFHO1VBQ1hDLEtBQUssRUFBRTtZQUNMQyxLQUFLLEVBQUU7Y0FDTEMsR0FBRyxFQUFFSjtZQUNQO1VBQ0Y7UUFDRixDQUFDO1FBQ0QsTUFBTUssTUFBOEIsR0FBRztVQUFFTixLQUFLO1VBQUVFLElBQUksRUFBRUssSUFBSSxDQUFDQyxTQUFTLENBQUNOLElBQUk7UUFBRSxDQUFDO1FBQzVFLE1BQU07VUFBRU8saUJBQWlCLEVBQUVDO1FBQWdCLENBQUMsR0FBRyxJQUFJLENBQUNmLFFBQVEsQ0FBQ2dCLFFBQVEsQ0FBQ2IsT0FBTyxDQUFDO1FBQzlFLE1BQU1jLGNBQW1DLEdBQUcsTUFBTUYsZUFBZSxDQUFDLFFBQVEsRUFBRUosTUFBTSxDQUFDO1FBQ25GLE9BQU9QLFFBQVEsQ0FBQ2MsTUFBTSxDQUFDO1VBQ3JCQyxVQUFVLEVBQUUsR0FBRztVQUNmWixJQUFJLEVBQUU7WUFDSmEsRUFBRSxFQUFFLElBQUk7WUFDUmhCLFFBQVEsRUFBRWE7VUFDWjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPSSxLQUFVLEVBQUU7UUFDbkJDLE9BQU8sQ0FBQ0QsS0FBSyxDQUFDLDREQUE0RCxFQUFFQSxLQUFLLENBQUM7UUFDbEYsT0FBT2pCLFFBQVEsQ0FBQ2MsTUFBTSxDQUFDO1VBQ3JCQyxVQUFVLEVBQUUsR0FBRztVQUNmWixJQUFJLEVBQUU7WUFDSmEsRUFBRSxFQUFFLEtBQUs7WUFDVEMsS0FBSyxFQUFFQSxLQUFLLENBQUNFO1VBQ2Y7UUFDRixDQUFDLENBQUM7TUFDSjtJQUNGLENBQUM7SUFBQXRCLGVBQUEseUJBRWdCLE9BQ2ZDLE9BQThCLEVBQzlCQyxPQUFvQyxFQUNwQ0MsUUFBNkMsS0FHMUM7TUFDSCxJQUFJO1FBQ0YsTUFBTTtVQUNKQyxLQUFLO1VBQ0xtQixTQUFTLEdBQUcsV0FBVztVQUN2QkMsU0FBUyxHQUFHLFNBQVM7VUFDckJDLE9BQU8sR0FBRztRQUNaLENBQUMsR0FBR3ZCLE9BQU8sQ0FBQ0ssS0FLWDtRQUVELE1BQU1ELElBQUksR0FBRztVQUNYQyxLQUFLLEVBQUU7WUFDTG1CLEtBQUssRUFBRTtjQUNMLENBQUNILFNBQVMsR0FBRztnQkFDWEksR0FBRyxFQUFFSCxTQUFTO2dCQUNkSSxFQUFFLEVBQUVIO2NBQ047WUFDRjtVQUNGO1FBQ0YsQ0FBQztRQUVELE1BQU1mLE1BQTRCLEdBQUc7VUFBRU4sS0FBSztVQUFFRSxJQUFJLEVBQUVLLElBQUksQ0FBQ0MsU0FBUyxDQUFDTixJQUFJO1FBQUUsQ0FBQztRQUMxRSxNQUFNO1VBQUVPLGlCQUFpQixFQUFFQztRQUFnQixDQUFDLEdBQUcsSUFBSSxDQUFDZixRQUFRLENBQUNnQixRQUFRLENBQUNiLE9BQU8sQ0FBQztRQUM5RSxNQUFNYyxjQUFtQyxHQUFHLE1BQU1GLGVBQWUsQ0FBQyxRQUFRLEVBQUVKLE1BQU0sQ0FBQztRQUNuRixPQUFPUCxRQUFRLENBQUNjLE1BQU0sQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZlosSUFBSSxFQUFFO1lBQ0phLEVBQUUsRUFBRSxJQUFJO1lBQ1JoQixRQUFRLEVBQUVhO1VBQ1o7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0ksS0FBVSxFQUFFO1FBQ25CQyxPQUFPLENBQUNELEtBQUssQ0FBQywwREFBMEQsRUFBRUEsS0FBSyxDQUFDO1FBQ2hGLE9BQU9qQixRQUFRLENBQUNjLE1BQU0sQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZlosSUFBSSxFQUFFO1lBQ0phLEVBQUUsRUFBRSxLQUFLO1lBQ1RDLEtBQUssRUFBRUEsS0FBSyxDQUFDRTtVQUNmO1FBQ0YsQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDO0lBQUF0QixlQUFBLHFCQUVZLE9BQ1hDLE9BQThCLEVBQzlCQyxPQUFvQyxFQUNwQ0MsUUFBNkMsS0FDMUM7TUFDSCxJQUFJO1FBQ0YsTUFBTTtVQUFFVTtRQUFrQixDQUFDLEdBQUcsSUFBSSxDQUFDZCxRQUFRLENBQUNnQixRQUFRLENBQUNiLE9BQU8sQ0FBQztRQUM3RCxNQUFNMkIsT0FBTyxHQUFHLE1BQU1oQixpQkFBaUIsQ0FBQyxhQUFhLEVBQUU7VUFDckRpQixNQUFNLEVBQUUsTUFBTTtVQUNkQyxDQUFDLEVBQUU7UUFDTCxDQUFDLENBQUM7UUFDRixPQUFPNUIsUUFBUSxDQUFDZ0IsRUFBRSxDQUFDO1VBQ2pCYixJQUFJLEVBQUU7WUFDSmEsRUFBRSxFQUFFLElBQUk7WUFDUmhCLFFBQVEsRUFBRTBCO1VBQ1o7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT1QsS0FBVSxFQUFFO1FBQ25CQyxPQUFPLENBQUNELEtBQUssQ0FBQyxzREFBc0QsRUFBRUEsS0FBSyxDQUFDO1FBQzVFLE9BQU9qQixRQUFRLENBQUNnQixFQUFFLENBQUM7VUFDakJiLElBQUksRUFBRTtZQUNKYSxFQUFFLEVBQUUsS0FBSztZQUNUaEIsUUFBUSxFQUFFaUIsS0FBSyxDQUFDRTtVQUNsQjtRQUNGLENBQUMsQ0FBQztNQUNKO0lBQ0YsQ0FBQztJQTNIQyxJQUFJLENBQUN2QixRQUFRLEdBQUdBLFFBQVE7RUFDMUI7QUEySEY7QUFBQ2lDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBcEMsaUJBQUE7QUFBQXFDLE1BQUEsQ0FBQUYsT0FBQSxHQUFBQSxPQUFBLENBQUFDLE9BQUEifQ==