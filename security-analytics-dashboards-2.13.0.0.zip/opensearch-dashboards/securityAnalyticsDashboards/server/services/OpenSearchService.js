"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

class OpenSearchService {
  constructor(osDriver) {
    _defineProperty(this, "osDriver", void 0);
    /**
     * Searches the provided index for documents with the provided IDs.
     */
    _defineProperty(this, "documentIdsQuery", async (context, request, response) => {
      try {
        const {
          index,
          documentIds
        } = request.query;
        const body = {
          query: {
            terms: {
              _id: documentIds
            }
          }
        };
        const params = {
          index,
          body: JSON.stringify(body)
        };
        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const searchResponse = await callWithRequest('search', params);
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: searchResponse
          }
        });
      } catch (error) {
        console.error('Security Analytics - OpenSearchService - documentIdsQuery:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });
    _defineProperty(this, "timeRangeQuery", async (context, request, response) => {
      try {
        const {
          index,
          timeField = 'timestamp',
          startTime = 'now-15m',
          endTime = 'now'
        } = request.query;
        const body = {
          query: {
            range: {
              [timeField]: {
                gte: startTime,
                lt: endTime
              }
            }
          }
        };
        const params = {
          index,
          body: JSON.stringify(body)
        };
        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const searchResponse = await callWithRequest('search', params);
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: searchResponse
          }
        });
      } catch (error) {
        console.error('Security Analytics - OpenSearchService - timeRangeQuery:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });
    _defineProperty(this, "getPlugins", async (context, request, response) => {
      try {
        const {
          callAsCurrentUser
        } = this.osDriver.asScoped(request);
        const plugins = await callAsCurrentUser('cat.plugins', {
          format: 'json',
          h: 'component'
        });
        return response.ok({
          body: {
            ok: true,
            response: plugins
          }
        });
      } catch (error) {
        console.error('Security Analytics - OpensearchService - getPlugins:', error);
        return response.ok({
          body: {
            ok: false,
            response: error.message
          }
        });
      }
    });
    this.osDriver = osDriver;
  }
}
exports.default = OpenSearchService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPcGVuU2VhcmNoU2VydmljZSIsImNvbnN0cnVjdG9yIiwib3NEcml2ZXIiLCJfZGVmaW5lUHJvcGVydHkiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiaW5kZXgiLCJkb2N1bWVudElkcyIsInF1ZXJ5IiwiYm9keSIsInRlcm1zIiwiX2lkIiwicGFyYW1zIiwiSlNPTiIsInN0cmluZ2lmeSIsImNhbGxBc0N1cnJlbnRVc2VyIiwiY2FsbFdpdGhSZXF1ZXN0IiwiYXNTY29wZWQiLCJzZWFyY2hSZXNwb25zZSIsImN1c3RvbSIsInN0YXR1c0NvZGUiLCJvayIsImVycm9yIiwiY29uc29sZSIsIm1lc3NhZ2UiLCJ0aW1lRmllbGQiLCJzdGFydFRpbWUiLCJlbmRUaW1lIiwicmFuZ2UiLCJndGUiLCJsdCIsInBsdWdpbnMiLCJmb3JtYXQiLCJoIiwiZXhwb3J0cyIsImRlZmF1bHQiLCJtb2R1bGUiXSwic291cmNlcyI6WyJPcGVuU2VhcmNoU2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7XG4gIElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50LFxuICBJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZSxcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICBSZXNwb25zZUVycm9yLFxufSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IFNlcnZlclJlc3BvbnNlIH0gZnJvbSAnLi4vbW9kZWxzL3R5cGVzJztcbmltcG9ydCB7IERvY3VtZW50SWRzUXVlcnlQYXJhbXMsIFNlYXJjaFJlc3BvbnNlLCBUaW1lUmFuZ2VRdWVyeVBhcmFtcyB9IGZyb20gJy4uL21vZGVscy9pbnRlcmZhY2VzJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgT3BlblNlYXJjaFNlcnZpY2Uge1xuICBvc0RyaXZlcjogSUxlZ2FjeUN1c3RvbUNsdXN0ZXJDbGllbnQ7XG5cbiAgY29uc3RydWN0b3Iob3NEcml2ZXI6IElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50KSB7XG4gICAgdGhpcy5vc0RyaXZlciA9IG9zRHJpdmVyO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlYXJjaGVzIHRoZSBwcm92aWRlZCBpbmRleCBmb3IgZG9jdW1lbnRzIHdpdGggdGhlIHByb3ZpZGVkIElEcy5cbiAgICovXG4gIGRvY3VtZW50SWRzUXVlcnkgPSBhc3luYyAoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcbiAgKTogUHJvbWlzZTxcbiAgICBJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxTZXJ2ZXJSZXNwb25zZTxTZWFyY2hSZXNwb25zZTxhbnk+PiB8IFJlc3BvbnNlRXJyb3I+XG4gID4gPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGluZGV4LCBkb2N1bWVudElkcyB9ID0gcmVxdWVzdC5xdWVyeSBhcyB7IGluZGV4OiBzdHJpbmc7IGRvY3VtZW50SWRzOiBzdHJpbmdbXSB9O1xuICAgICAgY29uc3QgYm9keSA9IHtcbiAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgX2lkOiBkb2N1bWVudElkcyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHBhcmFtczogRG9jdW1lbnRJZHNRdWVyeVBhcmFtcyA9IHsgaW5kZXgsIGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyOiBjYWxsV2l0aFJlcXVlc3QgfSA9IHRoaXMub3NEcml2ZXIuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBjb25zdCBzZWFyY2hSZXNwb25zZTogU2VhcmNoUmVzcG9uc2U8YW55PiA9IGF3YWl0IGNhbGxXaXRoUmVxdWVzdCgnc2VhcmNoJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b20oe1xuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwb25zZTogc2VhcmNoUmVzcG9uc2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdTZWN1cml0eSBBbmFseXRpY3MgLSBPcGVuU2VhcmNoU2VydmljZSAtIGRvY3VtZW50SWRzUXVlcnk6JywgZXJyb3IpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICB0aW1lUmFuZ2VRdWVyeSA9IGFzeW5jIChcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeVxuICApOiBQcm9taXNlPFxuICAgIElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPFNlcnZlclJlc3BvbnNlPFNlYXJjaFJlc3BvbnNlPGFueT4+IHwgUmVzcG9uc2VFcnJvcj5cbiAgPiA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgaW5kZXgsXG4gICAgICAgIHRpbWVGaWVsZCA9ICd0aW1lc3RhbXAnLFxuICAgICAgICBzdGFydFRpbWUgPSAnbm93LTE1bScsXG4gICAgICAgIGVuZFRpbWUgPSAnbm93JyxcbiAgICAgIH0gPSByZXF1ZXN0LnF1ZXJ5IGFzIHtcbiAgICAgICAgaW5kZXg6IHN0cmluZztcbiAgICAgICAgdGltZUZpZWxkOiBzdHJpbmc7XG4gICAgICAgIHN0YXJ0VGltZTogc3RyaW5nO1xuICAgICAgICBlbmRUaW1lOiBzdHJpbmc7XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBib2R5ID0ge1xuICAgICAgICBxdWVyeToge1xuICAgICAgICAgIHJhbmdlOiB7XG4gICAgICAgICAgICBbdGltZUZpZWxkXToge1xuICAgICAgICAgICAgICBndGU6IHN0YXJ0VGltZSxcbiAgICAgICAgICAgICAgbHQ6IGVuZFRpbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9O1xuXG4gICAgICBjb25zdCBwYXJhbXM6IFRpbWVSYW5nZVF1ZXJ5UGFyYW1zID0geyBpbmRleCwgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGNhbGxXaXRoUmVxdWVzdCB9ID0gdGhpcy5vc0RyaXZlci5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGNvbnN0IHNlYXJjaFJlc3BvbnNlOiBTZWFyY2hSZXNwb25zZTxhbnk+ID0gYXdhaXQgY2FsbFdpdGhSZXF1ZXN0KCdzZWFyY2gnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3BvbnNlOiBzZWFyY2hSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NlY3VyaXR5IEFuYWx5dGljcyAtIE9wZW5TZWFyY2hTZXJ2aWNlIC0gdGltZVJhbmdlUXVlcnk6JywgZXJyb3IpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBnZXRQbHVnaW5zID0gYXN5bmMgKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSB0aGlzLm9zRHJpdmVyLmFzU2NvcGVkKHJlcXVlc3QpO1xuICAgICAgY29uc3QgcGx1Z2lucyA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdjYXQucGx1Z2lucycsIHtcbiAgICAgICAgZm9ybWF0OiAnanNvbicsXG4gICAgICAgIGg6ICdjb21wb25lbnQnLFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcG9uc2U6IHBsdWdpbnMsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdTZWN1cml0eSBBbmFseXRpY3MgLSBPcGVuc2VhcmNoU2VydmljZSAtIGdldFBsdWdpbnM6JywgZXJyb3IpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwb25zZTogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBYWUsTUFBTUEsaUJBQWlCLENBQUM7RUFHckNDLFdBQVdBLENBQUNDLFFBQW9DLEVBQUU7SUFBQUMsZUFBQTtJQUlsRDtBQUNGO0FBQ0E7SUFGRUEsZUFBQSwyQkFHbUIsT0FDakJDLE9BQThCLEVBQzlCQyxPQUFvQyxFQUNwQ0MsUUFBNkMsS0FHMUM7TUFDSCxJQUFJO1FBQ0YsTUFBTTtVQUFFQyxLQUFLO1VBQUVDO1FBQVksQ0FBQyxHQUFHSCxPQUFPLENBQUNJLEtBQWlEO1FBQ3hGLE1BQU1DLElBQUksR0FBRztVQUNYRCxLQUFLLEVBQUU7WUFDTEUsS0FBSyxFQUFFO2NBQ0xDLEdBQUcsRUFBRUo7WUFDUDtVQUNGO1FBQ0YsQ0FBQztRQUNELE1BQU1LLE1BQThCLEdBQUc7VUFBRU4sS0FBSztVQUFFRyxJQUFJLEVBQUVJLElBQUksQ0FBQ0MsU0FBUyxDQUFDTCxJQUFJO1FBQUUsQ0FBQztRQUM1RSxNQUFNO1VBQUVNLGlCQUFpQixFQUFFQztRQUFnQixDQUFDLEdBQUcsSUFBSSxDQUFDZixRQUFRLENBQUNnQixRQUFRLENBQUNiLE9BQU8sQ0FBQztRQUM5RSxNQUFNYyxjQUFtQyxHQUFHLE1BQU1GLGVBQWUsQ0FBQyxRQUFRLEVBQUVKLE1BQU0sQ0FBQztRQUNuRixPQUFPUCxRQUFRLENBQUNjLE1BQU0sQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZlgsSUFBSSxFQUFFO1lBQ0pZLEVBQUUsRUFBRSxJQUFJO1lBQ1JoQixRQUFRLEVBQUVhO1VBQ1o7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0ksS0FBVSxFQUFFO1FBQ25CQyxPQUFPLENBQUNELEtBQUssQ0FBQyw0REFBNEQsRUFBRUEsS0FBSyxDQUFDO1FBQ2xGLE9BQU9qQixRQUFRLENBQUNjLE1BQU0sQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZlgsSUFBSSxFQUFFO1lBQ0pZLEVBQUUsRUFBRSxLQUFLO1lBQ1RDLEtBQUssRUFBRUEsS0FBSyxDQUFDRTtVQUNmO1FBQ0YsQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDO0lBQUF0QixlQUFBLHlCQUVnQixPQUNmQyxPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEtBRzFDO01BQ0gsSUFBSTtRQUNGLE1BQU07VUFDSkMsS0FBSztVQUNMbUIsU0FBUyxHQUFHLFdBQVc7VUFDdkJDLFNBQVMsR0FBRyxTQUFTO1VBQ3JCQyxPQUFPLEdBQUc7UUFDWixDQUFDLEdBQUd2QixPQUFPLENBQUNJLEtBS1g7UUFFRCxNQUFNQyxJQUFJLEdBQUc7VUFDWEQsS0FBSyxFQUFFO1lBQ0xvQixLQUFLLEVBQUU7Y0FDTCxDQUFDSCxTQUFTLEdBQUc7Z0JBQ1hJLEdBQUcsRUFBRUgsU0FBUztnQkFDZEksRUFBRSxFQUFFSDtjQUNOO1lBQ0Y7VUFDRjtRQUNGLENBQUM7UUFFRCxNQUFNZixNQUE0QixHQUFHO1VBQUVOLEtBQUs7VUFBRUcsSUFBSSxFQUFFSSxJQUFJLENBQUNDLFNBQVMsQ0FBQ0wsSUFBSTtRQUFFLENBQUM7UUFDMUUsTUFBTTtVQUFFTSxpQkFBaUIsRUFBRUM7UUFBZ0IsQ0FBQyxHQUFHLElBQUksQ0FBQ2YsUUFBUSxDQUFDZ0IsUUFBUSxDQUFDYixPQUFPLENBQUM7UUFDOUUsTUFBTWMsY0FBbUMsR0FBRyxNQUFNRixlQUFlLENBQUMsUUFBUSxFQUFFSixNQUFNLENBQUM7UUFDbkYsT0FBT1AsUUFBUSxDQUFDYyxNQUFNLENBQUM7VUFDckJDLFVBQVUsRUFBRSxHQUFHO1VBQ2ZYLElBQUksRUFBRTtZQUNKWSxFQUFFLEVBQUUsSUFBSTtZQUNSaEIsUUFBUSxFQUFFYTtVQUNaO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU9JLEtBQVUsRUFBRTtRQUNuQkMsT0FBTyxDQUFDRCxLQUFLLENBQUMsMERBQTBELEVBQUVBLEtBQUssQ0FBQztRQUNoRixPQUFPakIsUUFBUSxDQUFDYyxNQUFNLENBQUM7VUFDckJDLFVBQVUsRUFBRSxHQUFHO1VBQ2ZYLElBQUksRUFBRTtZQUNKWSxFQUFFLEVBQUUsS0FBSztZQUNUQyxLQUFLLEVBQUVBLEtBQUssQ0FBQ0U7VUFDZjtRQUNGLENBQUMsQ0FBQztNQUNKO0lBQ0YsQ0FBQztJQUFBdEIsZUFBQSxxQkFFWSxPQUNYQyxPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEtBQzFDO01BQ0gsSUFBSTtRQUNGLE1BQU07VUFBRVU7UUFBa0IsQ0FBQyxHQUFHLElBQUksQ0FBQ2QsUUFBUSxDQUFDZ0IsUUFBUSxDQUFDYixPQUFPLENBQUM7UUFDN0QsTUFBTTJCLE9BQU8sR0FBRyxNQUFNaEIsaUJBQWlCLENBQUMsYUFBYSxFQUFFO1VBQ3JEaUIsTUFBTSxFQUFFLE1BQU07VUFDZEMsQ0FBQyxFQUFFO1FBQ0wsQ0FBQyxDQUFDO1FBQ0YsT0FBTzVCLFFBQVEsQ0FBQ2dCLEVBQUUsQ0FBQztVQUNqQlosSUFBSSxFQUFFO1lBQ0pZLEVBQUUsRUFBRSxJQUFJO1lBQ1JoQixRQUFRLEVBQUUwQjtVQUNaO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU9ULEtBQVUsRUFBRTtRQUNuQkMsT0FBTyxDQUFDRCxLQUFLLENBQUMsc0RBQXNELEVBQUVBLEtBQUssQ0FBQztRQUM1RSxPQUFPakIsUUFBUSxDQUFDZ0IsRUFBRSxDQUFDO1VBQ2pCWixJQUFJLEVBQUU7WUFDSlksRUFBRSxFQUFFLEtBQUs7WUFDVGhCLFFBQVEsRUFBRWlCLEtBQUssQ0FBQ0U7VUFDbEI7UUFDRixDQUFDLENBQUM7TUFDSjtJQUNGLENBQUM7SUEzSEMsSUFBSSxDQUFDdkIsUUFBUSxHQUFHQSxRQUFRO0VBQzFCO0FBMkhGO0FBQUNpQyxPQUFBLENBQUFDLE9BQUEsR0FBQXBDLGlCQUFBO0FBQUFxQyxNQUFBLENBQUFGLE9BQUEsR0FBQUEsT0FBQSxDQUFBQyxPQUFBIn0=