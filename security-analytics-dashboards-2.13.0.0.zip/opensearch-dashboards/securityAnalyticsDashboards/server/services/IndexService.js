"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

class IndexService {
  constructor(osDriver) {
    _defineProperty(this, "osDriver", void 0);
    _defineProperty(this, "getIndexFields", async (_context, request, response) => {
      try {
        var _indexResponse$index;
        const {
          index
        } = request.body;
        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const indexResponse = await callWithRequest('indices.getFieldMapping', {
          index,
          fields: ['*']
        });
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: Object.keys(((_indexResponse$index = indexResponse[index]) === null || _indexResponse$index === void 0 ? void 0 : _indexResponse$index.mappings) || {})
          }
        });
      } catch (error) {
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });
    _defineProperty(this, "getIndices", async (_context, request, response) => {
      try {
        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const params = {
          format: 'json'
        };
        const getIndicesResponse = await callWithRequest('cat.indices', params);
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: {
              indices: getIndicesResponse
            }
          }
        });
      } catch (error) {
        console.error('Security Analytics - IndexService - getIndices:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });
    _defineProperty(this, "getAliases", async (_context, request, response) => {
      try {
        const {
          callAsCurrentUser
        } = this.osDriver.asScoped(request);
        const aliases = await callAsCurrentUser('cat.aliases', {
          format: 'json',
          h: 'alias,index'
        });
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: {
              aliases
            }
          }
        });
      } catch (err) {
        console.error('Security Analytcis - IndexService - getAliases:', err);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: err.message
          }
        });
      }
    });
    _defineProperty(this, "updateAliases", async (_context, request, response) => {
      try {
        const actions = request.body;
        const params = {
          body: actions
        };
        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        await callWithRequest('indices.updateAliases', params);
        return response.custom({
          statusCode: 200
        });
      } catch (error) {
        console.error('Security Analytics - IndexService - createAliases:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });
    this.osDriver = osDriver;
  }
}
exports.default = IndexService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJJbmRleFNlcnZpY2UiLCJjb25zdHJ1Y3RvciIsIm9zRHJpdmVyIiwiX2RlZmluZVByb3BlcnR5IiwiX2NvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJfaW5kZXhSZXNwb25zZSRpbmRleCIsImluZGV4IiwiYm9keSIsImNhbGxBc0N1cnJlbnRVc2VyIiwiY2FsbFdpdGhSZXF1ZXN0IiwiYXNTY29wZWQiLCJpbmRleFJlc3BvbnNlIiwiZmllbGRzIiwiY3VzdG9tIiwic3RhdHVzQ29kZSIsIm9rIiwiT2JqZWN0Iiwia2V5cyIsIm1hcHBpbmdzIiwiZXJyb3IiLCJtZXNzYWdlIiwicGFyYW1zIiwiZm9ybWF0IiwiZ2V0SW5kaWNlc1Jlc3BvbnNlIiwiaW5kaWNlcyIsImNvbnNvbGUiLCJhbGlhc2VzIiwiaCIsImVyciIsImFjdGlvbnMiLCJleHBvcnRzIiwiZGVmYXVsdCIsIm1vZHVsZSJdLCJzb3VyY2VzIjpbIkluZGV4U2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7XG4gIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gIElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlLFxuICBSZXNwb25zZUVycm9yLFxuICBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gIElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50LFxufSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IEdldEFsaWFzZXNSZXNwb25zZSwgR2V0SW5kaWNlc1Jlc3BvbnNlIH0gZnJvbSAnLi4vbW9kZWxzL2ludGVyZmFjZXMnO1xuaW1wb3J0IHsgU2VydmVyUmVzcG9uc2UgfSBmcm9tICcuLi9tb2RlbHMvdHlwZXMnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJbmRleFNlcnZpY2Uge1xuICBvc0RyaXZlcjogSUxlZ2FjeUN1c3RvbUNsdXN0ZXJDbGllbnQ7XG5cbiAgY29uc3RydWN0b3Iob3NEcml2ZXI6IElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50KSB7XG4gICAgdGhpcy5vc0RyaXZlciA9IG9zRHJpdmVyO1xuICB9XG5cbiAgZ2V0SW5kZXhGaWVsZHMgPSBhc3luYyAoXG4gICAgX2NvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3Q8e30sIHt9LCB7IGluZGV4OiBzdHJpbmcgfT4sXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGluZGV4IH0gPSByZXF1ZXN0LmJvZHk7XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyOiBjYWxsV2l0aFJlcXVlc3QgfSA9IHRoaXMub3NEcml2ZXIuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBjb25zdCBpbmRleFJlc3BvbnNlID0gYXdhaXQgY2FsbFdpdGhSZXF1ZXN0KCdpbmRpY2VzLmdldEZpZWxkTWFwcGluZycsIHtcbiAgICAgICAgaW5kZXgsXG4gICAgICAgIGZpZWxkczogWycqJ10sXG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3BvbnNlOiBPYmplY3Qua2V5cyhpbmRleFJlc3BvbnNlW2luZGV4XT8ubWFwcGluZ3MgfHwge30pLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBnZXRJbmRpY2VzID0gYXN5bmMgKFxuICAgIF9jb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeVxuICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPFNlcnZlclJlc3BvbnNlPEdldEluZGljZXNSZXNwb25zZT4gfCBSZXNwb25zZUVycm9yPj4gPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyOiBjYWxsV2l0aFJlcXVlc3QgfSA9IHRoaXMub3NEcml2ZXIuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIGZvcm1hdDogJ2pzb24nLFxuICAgICAgfTtcbiAgICAgIGNvbnN0IGdldEluZGljZXNSZXNwb25zZSA9IGF3YWl0IGNhbGxXaXRoUmVxdWVzdCgnY2F0LmluZGljZXMnLCBwYXJhbXMpO1xuXG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcG9uc2U6IHtcbiAgICAgICAgICAgIGluZGljZXM6IGdldEluZGljZXNSZXNwb25zZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgY29uc29sZS5lcnJvcignU2VjdXJpdHkgQW5hbHl0aWNzIC0gSW5kZXhTZXJ2aWNlIC0gZ2V0SW5kaWNlczonLCBlcnJvcik7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldEFsaWFzZXMgPSBhc3luYyAoXG4gICAgX2NvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICk6IFByb21pc2U8SU9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2U8U2VydmVyUmVzcG9uc2U8R2V0QWxpYXNlc1Jlc3BvbnNlPiB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMub3NEcml2ZXIuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBjb25zdCBhbGlhc2VzID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2NhdC5hbGlhc2VzJywge1xuICAgICAgICBmb3JtYXQ6ICdqc29uJyxcbiAgICAgICAgaDogJ2FsaWFzLGluZGV4JyxcbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcG9uc2U6IHtcbiAgICAgICAgICAgIGFsaWFzZXMsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdTZWN1cml0eSBBbmFseXRjaXMgLSBJbmRleFNlcnZpY2UgLSBnZXRBbGlhc2VzOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICB1cGRhdGVBbGlhc2VzID0gYXN5bmMgKFxuICAgIF9jb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeVxuICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPFNlcnZlclJlc3BvbnNlPHt9PiB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFjdGlvbnMgPSByZXF1ZXN0LmJvZHk7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IGJvZHk6IGFjdGlvbnMgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGNhbGxXaXRoUmVxdWVzdCB9ID0gdGhpcy5vc0RyaXZlci5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGF3YWl0IGNhbGxXaXRoUmVxdWVzdCgnaW5kaWNlcy51cGRhdGVBbGlhc2VzJywgcGFyYW1zKTtcblxuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NlY3VyaXR5IEFuYWx5dGljcyAtIEluZGV4U2VydmljZSAtIGNyZWF0ZUFsaWFzZXM6JywgZXJyb3IpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBYWUsTUFBTUEsWUFBWSxDQUFDO0VBR2hDQyxXQUFXQSxDQUFDQyxRQUFvQyxFQUFFO0lBQUFDLGVBQUE7SUFBQUEsZUFBQSx5QkFJakMsT0FDZkMsUUFBK0IsRUFDL0JDLE9BQStELEVBQy9EQyxRQUE2QyxLQUMxQztNQUNILElBQUk7UUFBQSxJQUFBQyxvQkFBQTtRQUNGLE1BQU07VUFBRUM7UUFBTSxDQUFDLEdBQUdILE9BQU8sQ0FBQ0ksSUFBSTtRQUM5QixNQUFNO1VBQUVDLGlCQUFpQixFQUFFQztRQUFnQixDQUFDLEdBQUcsSUFBSSxDQUFDVCxRQUFRLENBQUNVLFFBQVEsQ0FBQ1AsT0FBTyxDQUFDO1FBQzlFLE1BQU1RLGFBQWEsR0FBRyxNQUFNRixlQUFlLENBQUMseUJBQXlCLEVBQUU7VUFDckVILEtBQUs7VUFDTE0sTUFBTSxFQUFFLENBQUMsR0FBRztRQUNkLENBQUMsQ0FBQztRQUVGLE9BQU9SLFFBQVEsQ0FBQ1MsTUFBTSxDQUFDO1VBQ3JCQyxVQUFVLEVBQUUsR0FBRztVQUNmUCxJQUFJLEVBQUU7WUFDSlEsRUFBRSxFQUFFLElBQUk7WUFDUlgsUUFBUSxFQUFFWSxNQUFNLENBQUNDLElBQUksQ0FBQyxFQUFBWixvQkFBQSxHQUFBTSxhQUFhLENBQUNMLEtBQUssQ0FBQyxjQUFBRCxvQkFBQSx1QkFBcEJBLG9CQUFBLENBQXNCYSxRQUFRLEtBQUksQ0FBQyxDQUFDO1VBQzVEO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU9DLEtBQVUsRUFBRTtRQUNuQixPQUFPZixRQUFRLENBQUNTLE1BQU0sQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZlAsSUFBSSxFQUFFO1lBQ0pRLEVBQUUsRUFBRSxLQUFLO1lBQ1RJLEtBQUssRUFBRUEsS0FBSyxDQUFDQztVQUNmO1FBQ0YsQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDO0lBQUFuQixlQUFBLHFCQUVZLE9BQ1hDLFFBQStCLEVBQy9CQyxPQUFvQyxFQUNwQ0MsUUFBNkMsS0FDa0Q7TUFDL0YsSUFBSTtRQUNGLE1BQU07VUFBRUksaUJBQWlCLEVBQUVDO1FBQWdCLENBQUMsR0FBRyxJQUFJLENBQUNULFFBQVEsQ0FBQ1UsUUFBUSxDQUFDUCxPQUFPLENBQUM7UUFDOUUsTUFBTWtCLE1BQU0sR0FBRztVQUNiQyxNQUFNLEVBQUU7UUFDVixDQUFDO1FBQ0QsTUFBTUMsa0JBQWtCLEdBQUcsTUFBTWQsZUFBZSxDQUFDLGFBQWEsRUFBRVksTUFBTSxDQUFDO1FBRXZFLE9BQU9qQixRQUFRLENBQUNTLE1BQU0sQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZlAsSUFBSSxFQUFFO1lBQ0pRLEVBQUUsRUFBRSxJQUFJO1lBQ1JYLFFBQVEsRUFBRTtjQUNSb0IsT0FBTyxFQUFFRDtZQUNYO1VBQ0Y7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0osS0FBVSxFQUFFO1FBQ25CTSxPQUFPLENBQUNOLEtBQUssQ0FBQyxpREFBaUQsRUFBRUEsS0FBSyxDQUFDO1FBQ3ZFLE9BQU9mLFFBQVEsQ0FBQ1MsTUFBTSxDQUFDO1VBQ3JCQyxVQUFVLEVBQUUsR0FBRztVQUNmUCxJQUFJLEVBQUU7WUFDSlEsRUFBRSxFQUFFLEtBQUs7WUFDVEksS0FBSyxFQUFFQSxLQUFLLENBQUNDO1VBQ2Y7UUFDRixDQUFDLENBQUM7TUFDSjtJQUNGLENBQUM7SUFBQW5CLGVBQUEscUJBRVksT0FDWEMsUUFBK0IsRUFDL0JDLE9BQW9DLEVBQ3BDQyxRQUE2QyxLQUNrRDtNQUMvRixJQUFJO1FBQ0YsTUFBTTtVQUFFSTtRQUFrQixDQUFDLEdBQUcsSUFBSSxDQUFDUixRQUFRLENBQUNVLFFBQVEsQ0FBQ1AsT0FBTyxDQUFDO1FBQzdELE1BQU11QixPQUFPLEdBQUcsTUFBTWxCLGlCQUFpQixDQUFDLGFBQWEsRUFBRTtVQUNyRGMsTUFBTSxFQUFFLE1BQU07VUFDZEssQ0FBQyxFQUFFO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsT0FBT3ZCLFFBQVEsQ0FBQ1MsTUFBTSxDQUFDO1VBQ3JCQyxVQUFVLEVBQUUsR0FBRztVQUNmUCxJQUFJLEVBQUU7WUFDSlEsRUFBRSxFQUFFLElBQUk7WUFDUlgsUUFBUSxFQUFFO2NBQ1JzQjtZQUNGO1VBQ0Y7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0UsR0FBUSxFQUFFO1FBQ2pCSCxPQUFPLENBQUNOLEtBQUssQ0FBQyxpREFBaUQsRUFBRVMsR0FBRyxDQUFDO1FBQ3JFLE9BQU94QixRQUFRLENBQUNTLE1BQU0sQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZlAsSUFBSSxFQUFFO1lBQ0pRLEVBQUUsRUFBRSxLQUFLO1lBQ1RJLEtBQUssRUFBRVMsR0FBRyxDQUFDUjtVQUNiO1FBQ0YsQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDO0lBQUFuQixlQUFBLHdCQUVlLE9BQ2RDLFFBQStCLEVBQy9CQyxPQUFvQyxFQUNwQ0MsUUFBNkMsS0FDa0M7TUFDL0UsSUFBSTtRQUNGLE1BQU15QixPQUFPLEdBQUcxQixPQUFPLENBQUNJLElBQUk7UUFDNUIsTUFBTWMsTUFBTSxHQUFHO1VBQUVkLElBQUksRUFBRXNCO1FBQVEsQ0FBQztRQUNoQyxNQUFNO1VBQUVyQixpQkFBaUIsRUFBRUM7UUFBZ0IsQ0FBQyxHQUFHLElBQUksQ0FBQ1QsUUFBUSxDQUFDVSxRQUFRLENBQUNQLE9BQU8sQ0FBQztRQUM5RSxNQUFNTSxlQUFlLENBQUMsdUJBQXVCLEVBQUVZLE1BQU0sQ0FBQztRQUV0RCxPQUFPakIsUUFBUSxDQUFDUyxNQUFNLENBQUM7VUFDckJDLFVBQVUsRUFBRTtRQUNkLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPSyxLQUFVLEVBQUU7UUFDbkJNLE9BQU8sQ0FBQ04sS0FBSyxDQUFDLG9EQUFvRCxFQUFFQSxLQUFLLENBQUM7UUFDMUUsT0FBT2YsUUFBUSxDQUFDUyxNQUFNLENBQUM7VUFDckJDLFVBQVUsRUFBRSxHQUFHO1VBQ2ZQLElBQUksRUFBRTtZQUNKUSxFQUFFLEVBQUUsS0FBSztZQUNUSSxLQUFLLEVBQUVBLEtBQUssQ0FBQ0M7VUFDZjtRQUNGLENBQUMsQ0FBQztNQUNKO0lBQ0YsQ0FBQztJQTVIQyxJQUFJLENBQUNwQixRQUFRLEdBQUdBLFFBQVE7RUFDMUI7QUE0SEY7QUFBQzhCLE9BQUEsQ0FBQUMsT0FBQSxHQUFBakMsWUFBQTtBQUFBa0MsTUFBQSxDQUFBRixPQUFBLEdBQUFBLE9BQUEsQ0FBQUMsT0FBQSJ9