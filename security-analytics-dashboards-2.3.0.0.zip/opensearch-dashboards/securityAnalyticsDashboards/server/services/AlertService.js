"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _constants = require("../utils/constants");

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class AlertService {
  constructor(osDriver) {
    _defineProperty(this, "osDriver", void 0);

    _defineProperty(this, "getAlerts", async (_context, request, response) => {
      try {
        const {
          detectorType,
          detectorId
        } = request.query;
        let params;

        if (detectorId) {
          params = {
            detectorId
          };
        } else if (detectorType) {
          params = {
            detectorType
          };
        } else {
          throw Error(`Invalid request params: detectorId or detectorType must be specified`);
        }

        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const getAlertsResponse = await callWithRequest(_constants.CLIENT_ALERTS_METHODS.GET_ALERTS, params);
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: getAlertsResponse
          }
        });
      } catch (error) {
        console.error('Security Analytics - FindingsService - getAlerts:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });

    this.osDriver = osDriver;
  }
  /**
   * Calls backend GET Alerts API.
   */


}

exports.default = AlertService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFsZXJ0U2VydmljZS50cyJdLCJuYW1lcyI6WyJBbGVydFNlcnZpY2UiLCJjb25zdHJ1Y3RvciIsIm9zRHJpdmVyIiwiX2NvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJkZXRlY3RvclR5cGUiLCJkZXRlY3RvcklkIiwicXVlcnkiLCJwYXJhbXMiLCJFcnJvciIsImNhbGxBc0N1cnJlbnRVc2VyIiwiY2FsbFdpdGhSZXF1ZXN0IiwiYXNTY29wZWQiLCJnZXRBbGVydHNSZXNwb25zZSIsIkNMSUVOVF9BTEVSVFNfTUVUSE9EUyIsIkdFVF9BTEVSVFMiLCJjdXN0b20iLCJzdGF0dXNDb2RlIiwiYm9keSIsIm9rIiwiZXJyb3IiLCJjb25zb2xlIiwibWVzc2FnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWVBOzs7O0FBRWUsTUFBTUEsWUFBTixDQUFtQjtBQUdoQ0MsRUFBQUEsV0FBVyxDQUFDQyxRQUFELEVBQXVDO0FBQUE7O0FBQUEsdUNBT3RDLE9BQ1ZDLFFBRFUsRUFFVkMsT0FGVSxFQUdWQyxRQUhVLEtBSW9GO0FBQzlGLFVBQUk7QUFDRixjQUFNO0FBQUVDLFVBQUFBLFlBQUY7QUFBZ0JDLFVBQUFBO0FBQWhCLFlBQStCSCxPQUFPLENBQUNJLEtBQTdDO0FBQ0EsWUFBSUMsTUFBSjs7QUFFQSxZQUFJRixVQUFKLEVBQWdCO0FBQ2RFLFVBQUFBLE1BQU0sR0FBRztBQUNQRixZQUFBQTtBQURPLFdBQVQ7QUFHRCxTQUpELE1BSU8sSUFBSUQsWUFBSixFQUFrQjtBQUN2QkcsVUFBQUEsTUFBTSxHQUFHO0FBQ1BILFlBQUFBO0FBRE8sV0FBVDtBQUdELFNBSk0sTUFJQTtBQUNMLGdCQUFNSSxLQUFLLENBQUUsc0VBQUYsQ0FBWDtBQUNEOztBQUVELGNBQU07QUFBRUMsVUFBQUEsaUJBQWlCLEVBQUVDO0FBQXJCLFlBQXlDLEtBQUtWLFFBQUwsQ0FBY1csUUFBZCxDQUF1QlQsT0FBdkIsQ0FBL0M7QUFDQSxjQUFNVSxpQkFBb0MsR0FBRyxNQUFNRixlQUFlLENBQ2hFRyxpQ0FBc0JDLFVBRDBDLEVBRWhFUCxNQUZnRSxDQUFsRTtBQUlBLGVBQU9KLFFBQVEsQ0FBQ1ksTUFBVCxDQUFnQjtBQUNyQkMsVUFBQUEsVUFBVSxFQUFFLEdBRFM7QUFFckJDLFVBQUFBLElBQUksRUFBRTtBQUNKQyxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKZixZQUFBQSxRQUFRLEVBQUVTO0FBRk47QUFGZSxTQUFoQixDQUFQO0FBT0QsT0E1QkQsQ0E0QkUsT0FBT08sS0FBUCxFQUFtQjtBQUNuQkMsUUFBQUEsT0FBTyxDQUFDRCxLQUFSLENBQWMsbURBQWQsRUFBbUVBLEtBQW5FO0FBQ0EsZUFBT2hCLFFBQVEsQ0FBQ1ksTUFBVCxDQUFnQjtBQUNyQkMsVUFBQUEsVUFBVSxFQUFFLEdBRFM7QUFFckJDLFVBQUFBLElBQUksRUFBRTtBQUNKQyxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxLQUFLLEVBQUVBLEtBQUssQ0FBQ0U7QUFGVDtBQUZlLFNBQWhCLENBQVA7QUFPRDtBQUNGLEtBbERpRDs7QUFDaEQsU0FBS3JCLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQVRrQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IHtcbiAgSUxlZ2FjeUN1c3RvbUNsdXN0ZXJDbGllbnQsXG4gIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gIElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlLFxuICBSZXNwb25zZUVycm9yLFxuICBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG59IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IHsgR2V0QWxlcnRzUGFyYW1zLCBHZXRBbGVydHNSZXNwb25zZSB9IGZyb20gJy4uL21vZGVscy9pbnRlcmZhY2VzJztcbmltcG9ydCB7IFNlcnZlclJlc3BvbnNlIH0gZnJvbSAnLi4vbW9kZWxzL3R5cGVzJztcbmltcG9ydCB7IENMSUVOVF9BTEVSVFNfTUVUSE9EUyB9IGZyb20gJy4uL3V0aWxzL2NvbnN0YW50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEFsZXJ0U2VydmljZSB7XG4gIG9zRHJpdmVyOiBJTGVnYWN5Q3VzdG9tQ2x1c3RlckNsaWVudDtcblxuICBjb25zdHJ1Y3Rvcihvc0RyaXZlcjogSUxlZ2FjeUN1c3RvbUNsdXN0ZXJDbGllbnQpIHtcbiAgICB0aGlzLm9zRHJpdmVyID0gb3NEcml2ZXI7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbHMgYmFja2VuZCBHRVQgQWxlcnRzIEFQSS5cbiAgICovXG4gIGdldEFsZXJ0cyA9IGFzeW5jIChcbiAgICBfY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdDx7fSwgR2V0QWxlcnRzUGFyYW1zPixcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcbiAgKTogUHJvbWlzZTxJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxTZXJ2ZXJSZXNwb25zZTxHZXRBbGVydHNSZXNwb25zZT4gfCBSZXNwb25zZUVycm9yPj4gPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRldGVjdG9yVHlwZSwgZGV0ZWN0b3JJZCB9ID0gcmVxdWVzdC5xdWVyeTtcbiAgICAgIGxldCBwYXJhbXM6IEdldEFsZXJ0c1BhcmFtcztcblxuICAgICAgaWYgKGRldGVjdG9ySWQpIHtcbiAgICAgICAgcGFyYW1zID0ge1xuICAgICAgICAgIGRldGVjdG9ySWQsXG4gICAgICAgIH07XG4gICAgICB9IGVsc2UgaWYgKGRldGVjdG9yVHlwZSkge1xuICAgICAgICBwYXJhbXMgPSB7XG4gICAgICAgICAgZGV0ZWN0b3JUeXBlLFxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgRXJyb3IoYEludmFsaWQgcmVxdWVzdCBwYXJhbXM6IGRldGVjdG9ySWQgb3IgZGV0ZWN0b3JUeXBlIG11c3QgYmUgc3BlY2lmaWVkYCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGNhbGxXaXRoUmVxdWVzdCB9ID0gdGhpcy5vc0RyaXZlci5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGNvbnN0IGdldEFsZXJ0c1Jlc3BvbnNlOiBHZXRBbGVydHNSZXNwb25zZSA9IGF3YWl0IGNhbGxXaXRoUmVxdWVzdChcbiAgICAgICAgQ0xJRU5UX0FMRVJUU19NRVRIT0RTLkdFVF9BTEVSVFMsXG4gICAgICAgIHBhcmFtc1xuICAgICAgKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b20oe1xuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwb25zZTogZ2V0QWxlcnRzUmVzcG9uc2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdTZWN1cml0eSBBbmFseXRpY3MgLSBGaW5kaW5nc1NlcnZpY2UgLSBnZXRBbGVydHM6JywgZXJyb3IpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbn1cbiJdfQ==