"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _lodash = _interopRequireDefault(require("lodash"));

var _constants = require("../../utils/constants");

var _helpers = require("./utils/helpers");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class MonitorService {
  constructor(esDriver) {
    _defineProperty(this, "createMonitor", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "createWorkflow", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createWorkflow', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteMonitor', params);
        return res.ok({
          body: {
            ok: response.result === 'deleted' || response.result === undefined
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteWorkflow", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          workflowId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteWorkflow', params);
        return res.ok({
          body: {
            ok: response.result === 'deleted' || response.result === undefined
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getMonitor', params);

        let monitor = _lodash.default.get(getResponse, 'monitor', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        const associated_workflows = _lodash.default.get(getResponse, 'associated_workflows', null);

        if (monitor) {
          const {
            callAsCurrentUser
          } = this.esDriver.asScoped(req);
          const aggsParams = {
            index: _constants.INDEX.ALL_ALERTS,
            body: {
              size: 0,
              query: {
                bool: {
                  must: {
                    term: {
                      monitor_id: id
                    }
                  }
                }
              },
              aggs: {
                active_count: {
                  terms: {
                    field: 'state'
                  }
                },
                '24_hour_count': {
                  date_range: {
                    field: 'start_time',
                    ranges: [{
                      from: 'now-24h/h'
                    }]
                  }
                }
              }
            }
          };
          const searchResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

          const dayCount = _lodash.default.get(searchResponse, 'aggregations.24_hour_count.buckets.0.doc_count', 0);

          const activeBuckets = _lodash.default.get(searchResponse, 'aggregations.active_count.buckets', []);

          const activeCount = activeBuckets.reduce((acc, curr) => curr.key === 'ACTIVE' ? curr.doc_count : acc, 0);

          if (associated_workflows) {
            monitor = { ...monitor,
              associated_workflows
            };
          }

          monitor = { ...monitor,
            item_type: monitor.workflow_type || monitor.monitor_type,
            id,
            version
          };
          return res.ok({
            body: {
              ok: true,
              resp: monitor,
              activeCount,
              dayCount,
              version,
              ifSeqNo,
              ifPrimaryTerm
            }
          });
        } else {
          return res.ok({
            body: {
              ok: false
            }
          });
        }
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getWorkflow", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getWorkflow', params);

        let workflow = _lodash.default.get(getResponse, 'workflow', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        workflow.monitor_type = workflow.workflow_type;
        workflow = { ...workflow,
          item_type: workflow.workflow_type,
          id,
          version
        };
        return res.ok({
          body: {
            ok: true,
            resp: workflow,
            activeCount: 0,
            dayCount: 0,
            version,
            ifSeqNo,
            ifPrimaryTerm
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "updateMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body,
          refresh: 'wait_for'
        };
        const {
          type
        } = req.body; // TODO DRAFT: Are we sure we need to include ifSeqNo and ifPrimaryTerm from the UI side when updating monitors?

        const {
          ifSeqNo,
          ifPrimaryTerm
        } = req.query;

        if (ifSeqNo && ifPrimaryTerm) {
          params.if_seq_no = ifSeqNo;
          params.if_primary_term = ifPrimaryTerm;
        }

        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const updateResponse = await callAsCurrentUser(`alerting.${type === 'workflow' ? 'updateWorkflow' : 'updateMonitor'}`, params);
        const {
          _version,
          _id
        } = updateResponse;
        return res.ok({
          body: {
            ok: true,
            version: _version,
            id: _id
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - updateMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitors", async (context, req, res) => {
      try {
        const {
          from,
          size,
          search,
          sortDirection,
          sortField,
          state,
          monitorIds
        } = req.query;
        let must = {
          match_all: {}
        };

        if (search.trim()) {
          // This is an expensive wildcard query to match monitor names such as: "This is a long monitor name"
          // search query => "long monit"
          // This is acceptable because we will never allow more than 1,000 monitors
          must = {
            query_string: {
              default_field: 'monitor.name',
              default_operator: 'AND',
              query: `*${search.trim().split(' ').join('* *')}*`
            }
          };
        }

        const should = [];
        const mustList = [must];

        if (monitorIds !== undefined) {
          mustList.push({
            terms: {
              _id: Array.isArray(monitorIds) ? monitorIds : [monitorIds]
            }
          });
        } else if (monitorIds === 'empty') {
          mustList.push({
            terms: {
              _id: []
            }
          });
        }

        if (state !== 'all') {
          const enabled = state === 'enabled';
          should.push({
            term: {
              'monitor.enabled': enabled
            }
          });
          should.push({
            term: {
              'workflow.enabled': enabled
            }
          });
        }

        const monitorSorts = {
          name: 'monitor.name.keyword'
        };
        const monitorSortPageData = {
          size: 1000
        };

        if (monitorSorts[sortField]) {
          monitorSortPageData.sort = [{
            [monitorSorts[sortField]]: sortDirection
          }];
          monitorSortPageData.size = _lodash.default.defaultTo(size, 1000);
          monitorSortPageData.from = _lodash.default.defaultTo(from, 0);
        }

        const params = {
          body: {
            seq_no_primary_term: true,
            version: true,
            ...monitorSortPageData,
            query: {
              bool: {
                should,
                must: mustList
              }
            },
            aggregations: {
              associated_composite_monitors: {
                nested: {
                  path: 'workflow.inputs.composite_input.sequence.delegates'
                },
                aggs: {
                  monitor_ids: {
                    terms: {
                      field: 'workflow.inputs.composite_input.sequence.delegates.monitor_id'
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser: alertingCallAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await alertingCallAsCurrentUser('alerting.getMonitors', params);

        const totalMonitors = _lodash.default.get(getResponse, 'hits.total.value', 0);

        const monitorKeyValueTuples = _lodash.default.get(getResponse, 'hits.hits', []).map(result => {
          const {
            _id: id,
            _version: version,
            _seq_no: ifSeqNo,
            _primary_term: ifPrimaryTerm,
            _source
          } = result;
          const monitor = _source.monitor ? _source.monitor : _source;
          monitor['item_type'] = monitor.workflow_type || monitor.monitor_type;
          const {
            name,
            enabled
          } = monitor;
          return [id, {
            id,
            version,
            ifSeqNo,
            ifPrimaryTerm,
            name,
            enabled,
            monitor
          }];
        }, {});

        const monitorMap = new Map(monitorKeyValueTuples);
        const associatedCompositeMonitorCountMap = {};

        _lodash.default.get(getResponse, 'aggregations.associated_composite_monitors.monitor_ids.buckets', []).forEach(({
          key,
          doc_count
        }) => {
          associatedCompositeMonitorCountMap[key] = doc_count;
        });

        const monitorIdsOutput = [...monitorMap.keys()];
        const aggsOrderData = {};
        const aggsSorts = {
          active: 'active',
          acknowledged: 'acknowledged',
          errors: 'errors',
          ignored: 'ignored',
          lastNotificationTime: 'last_notification_time'
        };

        if (aggsSorts[sortField]) {
          aggsOrderData.order = {
            [aggsSorts[sortField]]: sortDirection
          };
        }

        const aggsParams = {
          index: _constants.INDEX.ALL_ALERTS,
          body: {
            size: 0,
            query: {
              terms: {
                monitor_id: monitorIdsOutput
              }
            },
            aggregations: {
              uniq_monitor_ids: {
                terms: {
                  field: 'monitor_id',
                  ...aggsOrderData,
                  size: from + size
                },
                aggregations: {
                  active: {
                    filter: {
                      term: {
                        state: 'ACTIVE'
                      }
                    }
                  },
                  acknowledged: {
                    filter: {
                      term: {
                        state: 'ACKNOWLEDGED'
                      }
                    }
                  },
                  errors: {
                    filter: {
                      term: {
                        state: 'ERROR'
                      }
                    }
                  },
                  ignored: {
                    filter: {
                      bool: {
                        filter: {
                          term: {
                            state: 'COMPLETED'
                          }
                        },
                        must_not: {
                          exists: {
                            field: 'acknowledged_time'
                          }
                        }
                      }
                    }
                  },
                  last_notification_time: {
                    max: {
                      field: 'last_notification_time'
                    }
                  },
                  latest_alert: {
                    top_hits: {
                      size: 1,
                      sort: [{
                        start_time: {
                          order: 'desc'
                        }
                      }],
                      _source: {
                        includes: ['last_notification_time', 'trigger_name']
                      }
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const esAggsResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

        const buckets = _lodash.default.get(esAggsResponse, 'aggregations.uniq_monitor_ids.buckets', []).map(bucket => {
          const {
            key: id,
            last_notification_time: {
              value: lastNotificationTime
            },
            ignored: {
              doc_count: ignored
            },
            acknowledged: {
              doc_count: acknowledged
            },
            active: {
              doc_count: active
            },
            errors: {
              doc_count: errors
            },
            latest_alert: {
              hits: {
                hits: [{
                  _source: {
                    trigger_name: latestAlert
                  }
                }]
              }
            }
          } = bucket;
          const monitor = monitorMap.get(id);
          monitorMap.delete(id);
          return { ...monitor,
            id,
            lastNotificationTime,
            ignored,
            latestAlert,
            acknowledged,
            active,
            errors,
            currentTime: Date.now(),
            associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[id] || 0
          };
        });

        const unusedMonitors = [...monitorMap.values()].map(monitor => ({ ...monitor,
          lastNotificationTime: null,
          ignored: 0,
          active: 0,
          acknowledged: 0,
          errors: 0,
          latestAlert: '--',
          currentTime: Date.now(),
          associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[monitor.id] || 0
        }));

        let results = _lodash.default.orderBy(buckets.concat(unusedMonitors), [sortField], [sortDirection]); // If we sorted on monitor name then we already applied from/size to the first query to limit what we're aggregating over
        // Therefore we do not need to apply from/size to this result set
        // If we sorted on aggregations, then this is our in memory pagination


        if (!monitorSorts[sortField]) {
          results = results.slice(from, from + size);
        }

        return res.ok({
          body: {
            ok: true,
            monitors: results,
            totalMonitors
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitors', err);

        if ((0, _helpers.isIndexNotFoundError)(err)) {
          return res.ok({
            body: {
              ok: false,
              resp: {
                totalMonitors: 0,
                monitors: []
              }
            }
          });
        }

        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "acknowledgeAlerts", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const acknowledgeResponse = await callAsCurrentUser('alerting.acknowledgeAlerts', params);
        return res.ok({
          body: {
            ok: !acknowledgeResponse.failed.length,
            resp: acknowledgeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - acknowledgeAlerts:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "acknowledgeChainedAlerts", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          workflowId: id,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const acknowledgeResponse = await callAsCurrentUser('alerting.acknowledgeChainedAlerts', params);
        return res.ok({
          body: {
            ok: !acknowledgeResponse.failed.length,
            resp: acknowledgeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - acknowledgeChainedAlerts:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "executeMonitor", async (context, req, res) => {
      try {
        const {
          dryrun = 'true'
        } = req.query;
        const params = {
          body: req.body,
          dryrun
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const executeResponse = await callAsCurrentUser('alerting.executeMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: executeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - executeMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "searchMonitors", async (context, req, res) => {
      try {
        const {
          query,
          index,
          size
        } = req.body;
        const params = {
          index,
          size,
          body: query
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const results = await callAsCurrentUser('alerting.getMonitors', params);
        return res.ok({
          body: {
            ok: true,
            resp: results
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - searchMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    this.esDriver = esDriver;
  }

}

exports.default = MonitorService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk1vbml0b3JTZXJ2aWNlLmpzIl0sIm5hbWVzIjpbIk1vbml0b3JTZXJ2aWNlIiwiY29uc3RydWN0b3IiLCJlc0RyaXZlciIsImNvbnRleHQiLCJyZXEiLCJyZXMiLCJwYXJhbXMiLCJib2R5IiwiY2FsbEFzQ3VycmVudFVzZXIiLCJhc1Njb3BlZCIsImNyZWF0ZVJlc3BvbnNlIiwib2siLCJyZXNwIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibWVzc2FnZSIsImlkIiwibW9uaXRvcklkIiwicmVzcG9uc2UiLCJyZXN1bHQiLCJ1bmRlZmluZWQiLCJ3b3JrZmxvd0lkIiwiZ2V0UmVzcG9uc2UiLCJtb25pdG9yIiwiXyIsImdldCIsInZlcnNpb24iLCJpZlNlcU5vIiwiaWZQcmltYXJ5VGVybSIsImFzc29jaWF0ZWRfd29ya2Zsb3dzIiwiYWdnc1BhcmFtcyIsImluZGV4IiwiSU5ERVgiLCJBTExfQUxFUlRTIiwic2l6ZSIsInF1ZXJ5IiwiYm9vbCIsIm11c3QiLCJ0ZXJtIiwibW9uaXRvcl9pZCIsImFnZ3MiLCJhY3RpdmVfY291bnQiLCJ0ZXJtcyIsImZpZWxkIiwiZGF0ZV9yYW5nZSIsInJhbmdlcyIsImZyb20iLCJzZWFyY2hSZXNwb25zZSIsImRheUNvdW50IiwiYWN0aXZlQnVja2V0cyIsImFjdGl2ZUNvdW50IiwicmVkdWNlIiwiYWNjIiwiY3VyciIsImtleSIsImRvY19jb3VudCIsIml0ZW1fdHlwZSIsIndvcmtmbG93X3R5cGUiLCJtb25pdG9yX3R5cGUiLCJ3b3JrZmxvdyIsInJlZnJlc2giLCJ0eXBlIiwiaWZfc2VxX25vIiwiaWZfcHJpbWFyeV90ZXJtIiwidXBkYXRlUmVzcG9uc2UiLCJfdmVyc2lvbiIsIl9pZCIsInNlYXJjaCIsInNvcnREaXJlY3Rpb24iLCJzb3J0RmllbGQiLCJzdGF0ZSIsIm1vbml0b3JJZHMiLCJtYXRjaF9hbGwiLCJ0cmltIiwicXVlcnlfc3RyaW5nIiwiZGVmYXVsdF9maWVsZCIsImRlZmF1bHRfb3BlcmF0b3IiLCJzcGxpdCIsImpvaW4iLCJzaG91bGQiLCJtdXN0TGlzdCIsInB1c2giLCJBcnJheSIsImlzQXJyYXkiLCJlbmFibGVkIiwibW9uaXRvclNvcnRzIiwibmFtZSIsIm1vbml0b3JTb3J0UGFnZURhdGEiLCJzb3J0IiwiZGVmYXVsdFRvIiwic2VxX25vX3ByaW1hcnlfdGVybSIsImFnZ3JlZ2F0aW9ucyIsImFzc29jaWF0ZWRfY29tcG9zaXRlX21vbml0b3JzIiwibmVzdGVkIiwicGF0aCIsIm1vbml0b3JfaWRzIiwiYWxlcnRpbmdDYWxsQXNDdXJyZW50VXNlciIsInRvdGFsTW9uaXRvcnMiLCJtb25pdG9yS2V5VmFsdWVUdXBsZXMiLCJtYXAiLCJfc2VxX25vIiwiX3ByaW1hcnlfdGVybSIsIl9zb3VyY2UiLCJtb25pdG9yTWFwIiwiTWFwIiwiYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcCIsImZvckVhY2giLCJtb25pdG9ySWRzT3V0cHV0Iiwia2V5cyIsImFnZ3NPcmRlckRhdGEiLCJhZ2dzU29ydHMiLCJhY3RpdmUiLCJhY2tub3dsZWRnZWQiLCJlcnJvcnMiLCJpZ25vcmVkIiwibGFzdE5vdGlmaWNhdGlvblRpbWUiLCJvcmRlciIsInVuaXFfbW9uaXRvcl9pZHMiLCJmaWx0ZXIiLCJtdXN0X25vdCIsImV4aXN0cyIsImxhc3Rfbm90aWZpY2F0aW9uX3RpbWUiLCJtYXgiLCJsYXRlc3RfYWxlcnQiLCJ0b3BfaGl0cyIsInN0YXJ0X3RpbWUiLCJpbmNsdWRlcyIsImVzQWdnc1Jlc3BvbnNlIiwiYnVja2V0cyIsImJ1Y2tldCIsInZhbHVlIiwiaGl0cyIsInRyaWdnZXJfbmFtZSIsImxhdGVzdEFsZXJ0IiwiZGVsZXRlIiwiY3VycmVudFRpbWUiLCJEYXRlIiwibm93IiwiYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDbnQiLCJ1bnVzZWRNb25pdG9ycyIsInZhbHVlcyIsInJlc3VsdHMiLCJvcmRlckJ5IiwiY29uY2F0Iiwic2xpY2UiLCJtb25pdG9ycyIsImFja25vd2xlZGdlUmVzcG9uc2UiLCJmYWlsZWQiLCJsZW5ndGgiLCJkcnlydW4iLCJleGVjdXRlUmVzcG9uc2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFLQTs7QUFFQTs7QUFDQTs7Ozs7O0FBRWUsTUFBTUEsY0FBTixDQUFxQjtBQUNsQ0MsRUFBQUEsV0FBVyxDQUFDQyxRQUFELEVBQVc7QUFBQSwyQ0FJTixPQUFPQyxPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDM0MsVUFBSTtBQUNGLGNBQU1DLE1BQU0sR0FBRztBQUFFQyxVQUFBQSxJQUFJLEVBQUVILEdBQUcsQ0FBQ0c7QUFBWixTQUFmO0FBQ0EsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1NLGNBQWMsR0FBRyxNQUFNRixpQkFBaUIsQ0FBQyx3QkFBRCxFQUEyQkYsTUFBM0IsQ0FBOUM7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFRjtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FWRCxDQVVFLE9BQU9HLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw0Q0FBZCxFQUE0REYsR0FBNUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBeEJxQjs7QUFBQSw0Q0EwQkwsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzVDLFVBQUk7QUFDRixjQUFNQyxNQUFNLEdBQUc7QUFBRUMsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBQVosU0FBZjtBQUNBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNTSxjQUFjLEdBQUcsTUFBTUYsaUJBQWlCLENBQUMseUJBQUQsRUFBNEJGLE1BQTVCLENBQTlDO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUY7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BVkQsQ0FVRSxPQUFPRyxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNkNBQWQsRUFBNkRGLEdBQTdEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQTlDcUI7O0FBQUEsMkNBZ0ROLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUMzQyxVQUFJO0FBQ0YsY0FBTTtBQUFFWSxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRVksVUFBQUEsU0FBUyxFQUFFRDtBQUFiLFNBQWY7QUFDQSxjQUFNO0FBQUVULFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTWUsUUFBUSxHQUFHLE1BQU1YLGlCQUFpQixDQUFDLHdCQUFELEVBQTJCRixNQUEzQixDQUF4QztBQUVBLGVBQU9ELEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUVRLFFBQVEsQ0FBQ0MsTUFBVCxLQUFvQixTQUFwQixJQUFpQ0QsUUFBUSxDQUFDQyxNQUFULEtBQW9CQztBQURyRDtBQURNLFNBQVAsQ0FBUDtBQUtELE9BWEQsQ0FXRSxPQUFPUixHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNENBQWQsRUFBNERGLEdBQTVEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXJFcUI7O0FBQUEsNENBdUVMLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUM1QyxVQUFJO0FBQ0YsY0FBTTtBQUFFWSxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRWdCLFVBQUFBLFVBQVUsRUFBRUw7QUFBZCxTQUFmO0FBQ0EsY0FBTTtBQUFFVCxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1lLFFBQVEsR0FBRyxNQUFNWCxpQkFBaUIsQ0FBQyx5QkFBRCxFQUE0QkYsTUFBNUIsQ0FBeEM7QUFFQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFUSxRQUFRLENBQUNDLE1BQVQsS0FBb0IsU0FBcEIsSUFBaUNELFFBQVEsQ0FBQ0MsTUFBVCxLQUFvQkM7QUFEckQ7QUFETSxTQUFQLENBQVA7QUFLRCxPQVhELENBV0UsT0FBT1IsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDZDQUFkLEVBQTZERixHQUE3RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0E1RnFCOztBQUFBLHdDQThGVCxPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDeEMsVUFBSTtBQUNGLGNBQU07QUFBRVksVUFBQUE7QUFBRixZQUFTYixHQUFHLENBQUNFLE1BQW5CO0FBQ0EsY0FBTUEsTUFBTSxHQUFHO0FBQUVZLFVBQUFBLFNBQVMsRUFBRUQ7QUFBYixTQUFmO0FBQ0EsY0FBTTtBQUFFVCxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1tQixXQUFXLEdBQUcsTUFBTWYsaUJBQWlCLENBQUMscUJBQUQsRUFBd0JGLE1BQXhCLENBQTNDOztBQUNBLFlBQUlrQixPQUFPLEdBQUdDLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsU0FBbkIsRUFBOEIsSUFBOUIsQ0FBZDs7QUFDQSxjQUFNSSxPQUFPLEdBQUdGLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsVUFBbkIsRUFBK0IsSUFBL0IsQ0FBaEI7O0FBQ0EsY0FBTUssT0FBTyxHQUFHSCxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFNBQW5CLEVBQThCLElBQTlCLENBQWhCOztBQUNBLGNBQU1NLGFBQWEsR0FBR0osZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixlQUFuQixFQUFvQyxJQUFwQyxDQUF0Qjs7QUFDQSxjQUFNTyxvQkFBb0IsR0FBR0wsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixzQkFBbkIsRUFBMkMsSUFBM0MsQ0FBN0I7O0FBQ0EsWUFBSUMsT0FBSixFQUFhO0FBQ1gsZ0JBQU07QUFBRWhCLFlBQUFBO0FBQUYsY0FBd0IsS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUE5QjtBQUNBLGdCQUFNMkIsVUFBVSxHQUFHO0FBQ2pCQyxZQUFBQSxLQUFLLEVBQUVDLGlCQUFNQyxVQURJO0FBRWpCM0IsWUFBQUEsSUFBSSxFQUFFO0FBQ0o0QixjQUFBQSxJQUFJLEVBQUUsQ0FERjtBQUVKQyxjQUFBQSxLQUFLLEVBQUU7QUFDTEMsZ0JBQUFBLElBQUksRUFBRTtBQUNKQyxrQkFBQUEsSUFBSSxFQUFFO0FBQ0pDLG9CQUFBQSxJQUFJLEVBQUU7QUFDSkMsc0JBQUFBLFVBQVUsRUFBRXZCO0FBRFI7QUFERjtBQURGO0FBREQsZUFGSDtBQVdKd0IsY0FBQUEsSUFBSSxFQUFFO0FBQ0pDLGdCQUFBQSxZQUFZLEVBQUU7QUFDWkMsa0JBQUFBLEtBQUssRUFBRTtBQUNMQyxvQkFBQUEsS0FBSyxFQUFFO0FBREY7QUFESyxpQkFEVjtBQU1KLGlDQUFpQjtBQUNmQyxrQkFBQUEsVUFBVSxFQUFFO0FBQ1ZELG9CQUFBQSxLQUFLLEVBQUUsWUFERztBQUVWRSxvQkFBQUEsTUFBTSxFQUFFLENBQUM7QUFBRUMsc0JBQUFBLElBQUksRUFBRTtBQUFSLHFCQUFEO0FBRkU7QUFERztBQU5iO0FBWEY7QUFGVyxXQUFuQjtBQTRCQSxnQkFBTUMsY0FBYyxHQUFHLE1BQU14QyxpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QnVCLFVBQXpCLENBQTlDOztBQUNBLGdCQUFNa0IsUUFBUSxHQUFHeEIsZ0JBQUVDLEdBQUYsQ0FBTXNCLGNBQU4sRUFBc0IsZ0RBQXRCLEVBQXdFLENBQXhFLENBQWpCOztBQUNBLGdCQUFNRSxhQUFhLEdBQUd6QixnQkFBRUMsR0FBRixDQUFNc0IsY0FBTixFQUFzQixtQ0FBdEIsRUFBMkQsRUFBM0QsQ0FBdEI7O0FBQ0EsZ0JBQU1HLFdBQVcsR0FBR0QsYUFBYSxDQUFDRSxNQUFkLENBQ2xCLENBQUNDLEdBQUQsRUFBTUMsSUFBTixLQUFnQkEsSUFBSSxDQUFDQyxHQUFMLEtBQWEsUUFBYixHQUF3QkQsSUFBSSxDQUFDRSxTQUE3QixHQUF5Q0gsR0FEdkMsRUFFbEIsQ0FGa0IsQ0FBcEI7O0FBSUEsY0FBSXZCLG9CQUFKLEVBQTBCO0FBQ3hCTixZQUFBQSxPQUFPLEdBQUcsRUFDUixHQUFHQSxPQURLO0FBRVJNLGNBQUFBO0FBRlEsYUFBVjtBQUlEOztBQUNETixVQUFBQSxPQUFPLEdBQUcsRUFDUixHQUFHQSxPQURLO0FBRVJpQyxZQUFBQSxTQUFTLEVBQUVqQyxPQUFPLENBQUNrQyxhQUFSLElBQXlCbEMsT0FBTyxDQUFDbUMsWUFGcEM7QUFHUjFDLFlBQUFBLEVBSFE7QUFJUlUsWUFBQUE7QUFKUSxXQUFWO0FBTUEsaUJBQU90QixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFBRUksY0FBQUEsRUFBRSxFQUFFLElBQU47QUFBWUMsY0FBQUEsSUFBSSxFQUFFWSxPQUFsQjtBQUEyQjJCLGNBQUFBLFdBQTNCO0FBQXdDRixjQUFBQSxRQUF4QztBQUFrRHRCLGNBQUFBLE9BQWxEO0FBQTJEQyxjQUFBQSxPQUEzRDtBQUFvRUMsY0FBQUE7QUFBcEU7QUFETSxXQUFQLENBQVA7QUFHRCxTQXBERCxNQW9ETztBQUNMLGlCQUFPeEIsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosWUFBQUEsSUFBSSxFQUFFO0FBQ0pJLGNBQUFBLEVBQUUsRUFBRTtBQURBO0FBRE0sV0FBUCxDQUFQO0FBS0Q7QUFDRixPQXJFRCxDQXFFRSxPQUFPRSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMseUNBQWQsRUFBeURGLEdBQXpEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQTdLcUI7O0FBQUEseUNBK0tSLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUN6QyxVQUFJO0FBQ0YsY0FBTTtBQUFFWSxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRVksVUFBQUEsU0FBUyxFQUFFRDtBQUFiLFNBQWY7QUFDQSxjQUFNO0FBQUVULFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTW1CLFdBQVcsR0FBRyxNQUFNZixpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QkYsTUFBekIsQ0FBM0M7O0FBQ0EsWUFBSXNELFFBQVEsR0FBR25DLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsVUFBbkIsRUFBK0IsSUFBL0IsQ0FBZjs7QUFDQSxjQUFNSSxPQUFPLEdBQUdGLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsVUFBbkIsRUFBK0IsSUFBL0IsQ0FBaEI7O0FBQ0EsY0FBTUssT0FBTyxHQUFHSCxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFNBQW5CLEVBQThCLElBQTlCLENBQWhCOztBQUNBLGNBQU1NLGFBQWEsR0FBR0osZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixlQUFuQixFQUFvQyxJQUFwQyxDQUF0Qjs7QUFDQXFDLFFBQUFBLFFBQVEsQ0FBQ0QsWUFBVCxHQUF3QkMsUUFBUSxDQUFDRixhQUFqQztBQUNBRSxRQUFBQSxRQUFRLEdBQUcsRUFDVCxHQUFHQSxRQURNO0FBRVRILFVBQUFBLFNBQVMsRUFBRUcsUUFBUSxDQUFDRixhQUZYO0FBR1R6QyxVQUFBQSxFQUhTO0FBSVRVLFVBQUFBO0FBSlMsU0FBWDtBQU9BLGVBQU90QixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFZ0QsUUFGRjtBQUdKVCxZQUFBQSxXQUFXLEVBQUUsQ0FIVDtBQUlKRixZQUFBQSxRQUFRLEVBQUUsQ0FKTjtBQUtKdEIsWUFBQUEsT0FMSTtBQU1KQyxZQUFBQSxPQU5JO0FBT0pDLFlBQUFBO0FBUEk7QUFETSxTQUFQLENBQVA7QUFXRCxPQTVCRCxDQTRCRSxPQUFPaEIsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDBDQUFkLEVBQTBERixHQUExRDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0FyTnFCOztBQUFBLDJDQXVOTixPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDM0MsVUFBSTtBQUNGLGNBQU07QUFBRVksVUFBQUE7QUFBRixZQUFTYixHQUFHLENBQUNFLE1BQW5CO0FBQ0EsY0FBTUEsTUFBTSxHQUFHO0FBQUVZLFVBQUFBLFNBQVMsRUFBRUQsRUFBYjtBQUFpQlYsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHLElBQTNCO0FBQWlDc0QsVUFBQUEsT0FBTyxFQUFFO0FBQTFDLFNBQWY7QUFDQSxjQUFNO0FBQUVDLFVBQUFBO0FBQUYsWUFBVzFELEdBQUcsQ0FBQ0csSUFBckIsQ0FIRSxDQUtGOztBQUNBLGNBQU07QUFBRXFCLFVBQUFBLE9BQUY7QUFBV0MsVUFBQUE7QUFBWCxZQUE2QnpCLEdBQUcsQ0FBQ2dDLEtBQXZDOztBQUNBLFlBQUlSLE9BQU8sSUFBSUMsYUFBZixFQUE4QjtBQUM1QnZCLFVBQUFBLE1BQU0sQ0FBQ3lELFNBQVAsR0FBbUJuQyxPQUFuQjtBQUNBdEIsVUFBQUEsTUFBTSxDQUFDMEQsZUFBUCxHQUF5Qm5DLGFBQXpCO0FBQ0Q7O0FBRUQsY0FBTTtBQUFFckIsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNNkQsY0FBYyxHQUFHLE1BQU16RCxpQkFBaUIsQ0FDM0MsWUFBV3NELElBQUksS0FBSyxVQUFULEdBQXNCLGdCQUF0QixHQUF5QyxlQUFnQixFQUR6QixFQUU1Q3hELE1BRjRDLENBQTlDO0FBSUEsY0FBTTtBQUFFNEQsVUFBQUEsUUFBRjtBQUFZQyxVQUFBQTtBQUFaLFlBQW9CRixjQUExQjtBQUNBLGVBQU81RCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSmdCLFlBQUFBLE9BQU8sRUFBRXVDLFFBRkw7QUFHSmpELFlBQUFBLEVBQUUsRUFBRWtEO0FBSEE7QUFETSxTQUFQLENBQVA7QUFPRCxPQXpCRCxDQXlCRSxPQUFPdEQsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDRDQUFkLEVBQTRERixHQUE1RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0ExUHFCOztBQUFBLHlDQTRQUixPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDekMsVUFBSTtBQUNGLGNBQU07QUFBRTBDLFVBQUFBLElBQUY7QUFBUVosVUFBQUEsSUFBUjtBQUFjaUMsVUFBQUEsTUFBZDtBQUFzQkMsVUFBQUEsYUFBdEI7QUFBcUNDLFVBQUFBLFNBQXJDO0FBQWdEQyxVQUFBQSxLQUFoRDtBQUF1REMsVUFBQUE7QUFBdkQsWUFBc0VwRSxHQUFHLENBQUNnQyxLQUFoRjtBQUVBLFlBQUlFLElBQUksR0FBRztBQUFFbUMsVUFBQUEsU0FBUyxFQUFFO0FBQWIsU0FBWDs7QUFDQSxZQUFJTCxNQUFNLENBQUNNLElBQVAsRUFBSixFQUFtQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQXBDLFVBQUFBLElBQUksR0FBRztBQUNMcUMsWUFBQUEsWUFBWSxFQUFFO0FBQ1pDLGNBQUFBLGFBQWEsRUFBRSxjQURIO0FBRVpDLGNBQUFBLGdCQUFnQixFQUFFLEtBRk47QUFHWnpDLGNBQUFBLEtBQUssRUFBRyxJQUFHZ0MsTUFBTSxDQUFDTSxJQUFQLEdBQWNJLEtBQWQsQ0FBb0IsR0FBcEIsRUFBeUJDLElBQXpCLENBQThCLEtBQTlCLENBQXFDO0FBSHBDO0FBRFQsV0FBUDtBQU9EOztBQUVELGNBQU1DLE1BQU0sR0FBRyxFQUFmO0FBQ0EsY0FBTUMsUUFBUSxHQUFHLENBQUMzQyxJQUFELENBQWpCOztBQUNBLFlBQUlrQyxVQUFVLEtBQUtuRCxTQUFuQixFQUE4QjtBQUM1QjRELFVBQUFBLFFBQVEsQ0FBQ0MsSUFBVCxDQUFjO0FBQ1p2QyxZQUFBQSxLQUFLLEVBQUU7QUFDTHdCLGNBQUFBLEdBQUcsRUFBRWdCLEtBQUssQ0FBQ0MsT0FBTixDQUFjWixVQUFkLElBQTRCQSxVQUE1QixHQUF5QyxDQUFDQSxVQUFEO0FBRHpDO0FBREssV0FBZDtBQUtELFNBTkQsTUFNTyxJQUFJQSxVQUFVLEtBQUssT0FBbkIsRUFBNEI7QUFDakNTLFVBQUFBLFFBQVEsQ0FBQ0MsSUFBVCxDQUFjO0FBQ1p2QyxZQUFBQSxLQUFLLEVBQUU7QUFDTHdCLGNBQUFBLEdBQUcsRUFBRTtBQURBO0FBREssV0FBZDtBQUtEOztBQUVELFlBQUlJLEtBQUssS0FBSyxLQUFkLEVBQXFCO0FBQ25CLGdCQUFNYyxPQUFPLEdBQUdkLEtBQUssS0FBSyxTQUExQjtBQUNBUyxVQUFBQSxNQUFNLENBQUNFLElBQVAsQ0FBWTtBQUFFM0MsWUFBQUEsSUFBSSxFQUFFO0FBQUUsaUNBQW1COEM7QUFBckI7QUFBUixXQUFaO0FBQ0FMLFVBQUFBLE1BQU0sQ0FBQ0UsSUFBUCxDQUFZO0FBQUUzQyxZQUFBQSxJQUFJLEVBQUU7QUFBRSxrQ0FBb0I4QztBQUF0QjtBQUFSLFdBQVo7QUFDRDs7QUFFRCxjQUFNQyxZQUFZLEdBQUc7QUFBRUMsVUFBQUEsSUFBSSxFQUFFO0FBQVIsU0FBckI7QUFDQSxjQUFNQyxtQkFBbUIsR0FBRztBQUFFckQsVUFBQUEsSUFBSSxFQUFFO0FBQVIsU0FBNUI7O0FBQ0EsWUFBSW1ELFlBQVksQ0FBQ2hCLFNBQUQsQ0FBaEIsRUFBNkI7QUFDM0JrQixVQUFBQSxtQkFBbUIsQ0FBQ0MsSUFBcEIsR0FBMkIsQ0FBQztBQUFFLGFBQUNILFlBQVksQ0FBQ2hCLFNBQUQsQ0FBYixHQUEyQkQ7QUFBN0IsV0FBRCxDQUEzQjtBQUNBbUIsVUFBQUEsbUJBQW1CLENBQUNyRCxJQUFwQixHQUEyQlYsZ0JBQUVpRSxTQUFGLENBQVl2RCxJQUFaLEVBQWtCLElBQWxCLENBQTNCO0FBQ0FxRCxVQUFBQSxtQkFBbUIsQ0FBQ3pDLElBQXBCLEdBQTJCdEIsZ0JBQUVpRSxTQUFGLENBQVkzQyxJQUFaLEVBQWtCLENBQWxCLENBQTNCO0FBQ0Q7O0FBRUQsY0FBTXpDLE1BQU0sR0FBRztBQUNiQyxVQUFBQSxJQUFJLEVBQUU7QUFDSm9GLFlBQUFBLG1CQUFtQixFQUFFLElBRGpCO0FBRUpoRSxZQUFBQSxPQUFPLEVBQUUsSUFGTDtBQUdKLGVBQUc2RCxtQkFIQztBQUlKcEQsWUFBQUEsS0FBSyxFQUFFO0FBQ0xDLGNBQUFBLElBQUksRUFBRTtBQUNKMkMsZ0JBQUFBLE1BREk7QUFFSjFDLGdCQUFBQSxJQUFJLEVBQUUyQztBQUZGO0FBREQsYUFKSDtBQVVKVyxZQUFBQSxZQUFZLEVBQUU7QUFDWkMsY0FBQUEsNkJBQTZCLEVBQUU7QUFDN0JDLGdCQUFBQSxNQUFNLEVBQUU7QUFDTkMsa0JBQUFBLElBQUksRUFBRTtBQURBLGlCQURxQjtBQUk3QnRELGdCQUFBQSxJQUFJLEVBQUU7QUFDSnVELGtCQUFBQSxXQUFXLEVBQUU7QUFDWHJELG9CQUFBQSxLQUFLLEVBQUU7QUFDTEMsc0JBQUFBLEtBQUssRUFBRTtBQURGO0FBREk7QUFEVDtBQUp1QjtBQURuQjtBQVZWO0FBRE8sU0FBZjtBQTRCQSxjQUFNO0FBQUVwQyxVQUFBQSxpQkFBaUIsRUFBRXlGO0FBQXJCLFlBQW1ELE1BQU0sS0FBSy9GLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBL0Q7QUFDQSxjQUFNbUIsV0FBVyxHQUFHLE1BQU0wRSx5QkFBeUIsQ0FBQyxzQkFBRCxFQUF5QjNGLE1BQXpCLENBQW5EOztBQUVBLGNBQU00RixhQUFhLEdBQUd6RSxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLGtCQUFuQixFQUF1QyxDQUF2QyxDQUF0Qjs7QUFDQSxjQUFNNEUscUJBQXFCLEdBQUcxRSxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFdBQW5CLEVBQWdDLEVBQWhDLEVBQW9DNkUsR0FBcEMsQ0FBeUNoRixNQUFELElBQVk7QUFDaEYsZ0JBQU07QUFDSitDLFlBQUFBLEdBQUcsRUFBRWxELEVBREQ7QUFFSmlELFlBQUFBLFFBQVEsRUFBRXZDLE9BRk47QUFHSjBFLFlBQUFBLE9BQU8sRUFBRXpFLE9BSEw7QUFJSjBFLFlBQUFBLGFBQWEsRUFBRXpFLGFBSlg7QUFLSjBFLFlBQUFBO0FBTEksY0FNRm5GLE1BTko7QUFPQSxnQkFBTUksT0FBTyxHQUFHK0UsT0FBTyxDQUFDL0UsT0FBUixHQUFrQitFLE9BQU8sQ0FBQy9FLE9BQTFCLEdBQW9DK0UsT0FBcEQ7QUFDQS9FLFVBQUFBLE9BQU8sQ0FBQyxXQUFELENBQVAsR0FBdUJBLE9BQU8sQ0FBQ2tDLGFBQVIsSUFBeUJsQyxPQUFPLENBQUNtQyxZQUF4RDtBQUNBLGdCQUFNO0FBQUU0QixZQUFBQSxJQUFGO0FBQVFGLFlBQUFBO0FBQVIsY0FBb0I3RCxPQUExQjtBQUNBLGlCQUFPLENBQUNQLEVBQUQsRUFBSztBQUFFQSxZQUFBQSxFQUFGO0FBQU1VLFlBQUFBLE9BQU47QUFBZUMsWUFBQUEsT0FBZjtBQUF3QkMsWUFBQUEsYUFBeEI7QUFBdUMwRCxZQUFBQSxJQUF2QztBQUE2Q0YsWUFBQUEsT0FBN0M7QUFBc0Q3RCxZQUFBQTtBQUF0RCxXQUFMLENBQVA7QUFDRCxTQVo2QixFQVkzQixFQVoyQixDQUE5Qjs7QUFhQSxjQUFNZ0YsVUFBVSxHQUFHLElBQUlDLEdBQUosQ0FBUU4scUJBQVIsQ0FBbkI7QUFDQSxjQUFNTyxrQ0FBa0MsR0FBRyxFQUEzQzs7QUFDQWpGLHdCQUFFQyxHQUFGLENBQ0VILFdBREYsRUFFRSxnRUFGRixFQUdFLEVBSEYsRUFJRW9GLE9BSkYsQ0FJVSxDQUFDO0FBQUVwRCxVQUFBQSxHQUFGO0FBQU9DLFVBQUFBO0FBQVAsU0FBRCxLQUF3QjtBQUNoQ2tELFVBQUFBLGtDQUFrQyxDQUFDbkQsR0FBRCxDQUFsQyxHQUEwQ0MsU0FBMUM7QUFDRCxTQU5EOztBQU9BLGNBQU1vRCxnQkFBZ0IsR0FBRyxDQUFDLEdBQUdKLFVBQVUsQ0FBQ0ssSUFBWCxFQUFKLENBQXpCO0FBRUEsY0FBTUMsYUFBYSxHQUFHLEVBQXRCO0FBQ0EsY0FBTUMsU0FBUyxHQUFHO0FBQ2hCQyxVQUFBQSxNQUFNLEVBQUUsUUFEUTtBQUVoQkMsVUFBQUEsWUFBWSxFQUFFLGNBRkU7QUFHaEJDLFVBQUFBLE1BQU0sRUFBRSxRQUhRO0FBSWhCQyxVQUFBQSxPQUFPLEVBQUUsU0FKTztBQUtoQkMsVUFBQUEsb0JBQW9CLEVBQUU7QUFMTixTQUFsQjs7QUFPQSxZQUFJTCxTQUFTLENBQUN6QyxTQUFELENBQWIsRUFBMEI7QUFDeEJ3QyxVQUFBQSxhQUFhLENBQUNPLEtBQWQsR0FBc0I7QUFBRSxhQUFDTixTQUFTLENBQUN6QyxTQUFELENBQVYsR0FBd0JEO0FBQTFCLFdBQXRCO0FBQ0Q7O0FBQ0QsY0FBTXRDLFVBQVUsR0FBRztBQUNqQkMsVUFBQUEsS0FBSyxFQUFFQyxpQkFBTUMsVUFESTtBQUVqQjNCLFVBQUFBLElBQUksRUFBRTtBQUNKNEIsWUFBQUEsSUFBSSxFQUFFLENBREY7QUFFSkMsWUFBQUEsS0FBSyxFQUFFO0FBQUVPLGNBQUFBLEtBQUssRUFBRTtBQUFFSCxnQkFBQUEsVUFBVSxFQUFFb0U7QUFBZDtBQUFULGFBRkg7QUFHSmhCLFlBQUFBLFlBQVksRUFBRTtBQUNaMEIsY0FBQUEsZ0JBQWdCLEVBQUU7QUFDaEIzRSxnQkFBQUEsS0FBSyxFQUFFO0FBQ0xDLGtCQUFBQSxLQUFLLEVBQUUsWUFERjtBQUVMLHFCQUFHa0UsYUFGRTtBQUdMM0Usa0JBQUFBLElBQUksRUFBRVksSUFBSSxHQUFHWjtBQUhSLGlCQURTO0FBTWhCeUQsZ0JBQUFBLFlBQVksRUFBRTtBQUNab0Isa0JBQUFBLE1BQU0sRUFBRTtBQUFFTyxvQkFBQUEsTUFBTSxFQUFFO0FBQUVoRixzQkFBQUEsSUFBSSxFQUFFO0FBQUVnQyx3QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUjtBQUFWLG1CQURJO0FBRVowQyxrQkFBQUEsWUFBWSxFQUFFO0FBQUVNLG9CQUFBQSxNQUFNLEVBQUU7QUFBRWhGLHNCQUFBQSxJQUFJLEVBQUU7QUFBRWdDLHdCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFSO0FBQVYsbUJBRkY7QUFHWjJDLGtCQUFBQSxNQUFNLEVBQUU7QUFBRUssb0JBQUFBLE1BQU0sRUFBRTtBQUFFaEYsc0JBQUFBLElBQUksRUFBRTtBQUFFZ0Msd0JBQUFBLEtBQUssRUFBRTtBQUFUO0FBQVI7QUFBVixtQkFISTtBQUlaNEMsa0JBQUFBLE9BQU8sRUFBRTtBQUNQSSxvQkFBQUEsTUFBTSxFQUFFO0FBQ05sRixzQkFBQUEsSUFBSSxFQUFFO0FBQ0prRix3QkFBQUEsTUFBTSxFQUFFO0FBQUVoRiwwQkFBQUEsSUFBSSxFQUFFO0FBQUVnQyw0QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUix5QkFESjtBQUVKaUQsd0JBQUFBLFFBQVEsRUFBRTtBQUFFQywwQkFBQUEsTUFBTSxFQUFFO0FBQUU3RSw0QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBVjtBQUZOO0FBREE7QUFERCxtQkFKRztBQVlaOEUsa0JBQUFBLHNCQUFzQixFQUFFO0FBQUVDLG9CQUFBQSxHQUFHLEVBQUU7QUFBRS9FLHNCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFQLG1CQVpaO0FBYVpnRixrQkFBQUEsWUFBWSxFQUFFO0FBQ1pDLG9CQUFBQSxRQUFRLEVBQUU7QUFDUjFGLHNCQUFBQSxJQUFJLEVBQUUsQ0FERTtBQUVSc0Qsc0JBQUFBLElBQUksRUFBRSxDQUFDO0FBQUVxQyx3QkFBQUEsVUFBVSxFQUFFO0FBQUVULDBCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFkLHVCQUFELENBRkU7QUFHUmQsc0JBQUFBLE9BQU8sRUFBRTtBQUNQd0Isd0JBQUFBLFFBQVEsRUFBRSxDQUFDLHdCQUFELEVBQTJCLGNBQTNCO0FBREg7QUFIRDtBQURFO0FBYkY7QUFORTtBQUROO0FBSFY7QUFGVyxTQUFuQjtBQXdDQSxjQUFNO0FBQUV2SCxVQUFBQTtBQUFGLFlBQXdCLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBOUI7QUFDQSxjQUFNNEgsY0FBYyxHQUFHLE1BQU14SCxpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QnVCLFVBQXpCLENBQTlDOztBQUNBLGNBQU1rRyxPQUFPLEdBQUd4RyxnQkFBRUMsR0FBRixDQUFNc0csY0FBTixFQUFzQix1Q0FBdEIsRUFBK0QsRUFBL0QsRUFBbUU1QixHQUFuRSxDQUNiOEIsTUFBRCxJQUFZO0FBQ1YsZ0JBQU07QUFDSjNFLFlBQUFBLEdBQUcsRUFBRXRDLEVBREQ7QUFFSnlHLFlBQUFBLHNCQUFzQixFQUFFO0FBQUVTLGNBQUFBLEtBQUssRUFBRWY7QUFBVCxhQUZwQjtBQUdKRCxZQUFBQSxPQUFPLEVBQUU7QUFBRTNELGNBQUFBLFNBQVMsRUFBRTJEO0FBQWIsYUFITDtBQUlKRixZQUFBQSxZQUFZLEVBQUU7QUFBRXpELGNBQUFBLFNBQVMsRUFBRXlEO0FBQWIsYUFKVjtBQUtKRCxZQUFBQSxNQUFNLEVBQUU7QUFBRXhELGNBQUFBLFNBQVMsRUFBRXdEO0FBQWIsYUFMSjtBQU1KRSxZQUFBQSxNQUFNLEVBQUU7QUFBRTFELGNBQUFBLFNBQVMsRUFBRTBEO0FBQWIsYUFOSjtBQU9KVSxZQUFBQSxZQUFZLEVBQUU7QUFDWlEsY0FBQUEsSUFBSSxFQUFFO0FBQ0pBLGdCQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFN0Isa0JBQUFBLE9BQU8sRUFBRTtBQUFFOEIsb0JBQUFBLFlBQVksRUFBRUM7QUFBaEI7QUFEWCxpQkFESTtBQURGO0FBRE07QUFQVixjQWdCRkosTUFoQko7QUFpQkEsZ0JBQU0xRyxPQUFPLEdBQUdnRixVQUFVLENBQUM5RSxHQUFYLENBQWVULEVBQWYsQ0FBaEI7QUFDQXVGLFVBQUFBLFVBQVUsQ0FBQytCLE1BQVgsQ0FBa0J0SCxFQUFsQjtBQUNBLGlCQUFPLEVBQ0wsR0FBR08sT0FERTtBQUVMUCxZQUFBQSxFQUZLO0FBR0xtRyxZQUFBQSxvQkFISztBQUlMRCxZQUFBQSxPQUpLO0FBS0xtQixZQUFBQSxXQUxLO0FBTUxyQixZQUFBQSxZQU5LO0FBT0xELFlBQUFBLE1BUEs7QUFRTEUsWUFBQUEsTUFSSztBQVNMc0IsWUFBQUEsV0FBVyxFQUFFQyxJQUFJLENBQUNDLEdBQUwsRUFUUjtBQVVMQyxZQUFBQSw2QkFBNkIsRUFBRWpDLGtDQUFrQyxDQUFDekYsRUFBRCxDQUFsQyxJQUEwQztBQVZwRSxXQUFQO0FBWUQsU0FqQ2EsQ0FBaEI7O0FBb0NBLGNBQU0ySCxjQUFjLEdBQUcsQ0FBQyxHQUFHcEMsVUFBVSxDQUFDcUMsTUFBWCxFQUFKLEVBQXlCekMsR0FBekIsQ0FBOEI1RSxPQUFELEtBQWMsRUFDaEUsR0FBR0EsT0FENkQ7QUFFaEU0RixVQUFBQSxvQkFBb0IsRUFBRSxJQUYwQztBQUdoRUQsVUFBQUEsT0FBTyxFQUFFLENBSHVEO0FBSWhFSCxVQUFBQSxNQUFNLEVBQUUsQ0FKd0Q7QUFLaEVDLFVBQUFBLFlBQVksRUFBRSxDQUxrRDtBQU1oRUMsVUFBQUEsTUFBTSxFQUFFLENBTndEO0FBT2hFb0IsVUFBQUEsV0FBVyxFQUFFLElBUG1EO0FBUWhFRSxVQUFBQSxXQUFXLEVBQUVDLElBQUksQ0FBQ0MsR0FBTCxFQVJtRDtBQVNoRUMsVUFBQUEsNkJBQTZCLEVBQUVqQyxrQ0FBa0MsQ0FBQ2xGLE9BQU8sQ0FBQ1AsRUFBVCxDQUFsQyxJQUFrRDtBQVRqQixTQUFkLENBQTdCLENBQXZCOztBQVlBLFlBQUk2SCxPQUFPLEdBQUdySCxnQkFBRXNILE9BQUYsQ0FBVWQsT0FBTyxDQUFDZSxNQUFSLENBQWVKLGNBQWYsQ0FBVixFQUEwQyxDQUFDdEUsU0FBRCxDQUExQyxFQUF1RCxDQUFDRCxhQUFELENBQXZELENBQWQsQ0E1TUUsQ0E2TUY7QUFDQTtBQUNBOzs7QUFDQSxZQUFJLENBQUNpQixZQUFZLENBQUNoQixTQUFELENBQWpCLEVBQThCO0FBQzVCd0UsVUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUNHLEtBQVIsQ0FBY2xHLElBQWQsRUFBb0JBLElBQUksR0FBR1osSUFBM0IsQ0FBVjtBQUNEOztBQUVELGVBQU85QixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSnVJLFlBQUFBLFFBQVEsRUFBRUosT0FGTjtBQUdKNUMsWUFBQUE7QUFISTtBQURNLFNBQVAsQ0FBUDtBQU9ELE9BM05ELENBMk5FLE9BQU9yRixHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMseUNBQWQsRUFBeURGLEdBQXpEOztBQUNBLFlBQUksbUNBQXFCQSxHQUFyQixDQUFKLEVBQStCO0FBQzdCLGlCQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFBRUksY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsY0FBQUEsSUFBSSxFQUFFO0FBQUVzRixnQkFBQUEsYUFBYSxFQUFFLENBQWpCO0FBQW9CZ0QsZ0JBQUFBLFFBQVEsRUFBRTtBQUE5QjtBQUFuQjtBQURNLFdBQVAsQ0FBUDtBQUdEOztBQUNELGVBQU83SSxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBdGVxQjs7QUFBQSwrQ0F3ZUYsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQy9DLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUNiWSxVQUFBQSxTQUFTLEVBQUVELEVBREU7QUFFYlYsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBRkcsU0FBZjtBQUlBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQTlCO0FBQ0EsY0FBTStJLG1CQUFtQixHQUFHLE1BQU0zSSxpQkFBaUIsQ0FBQyw0QkFBRCxFQUErQkYsTUFBL0IsQ0FBbkQ7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLENBQUN3SSxtQkFBbUIsQ0FBQ0MsTUFBcEIsQ0FBMkJDLE1BRDVCO0FBRUp6SSxZQUFBQSxJQUFJLEVBQUV1STtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FkRCxDQWNFLE9BQU90SSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsZ0RBQWQsRUFBZ0VGLEdBQWhFO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQWhnQnFCOztBQUFBLHNEQWtnQkssT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3RELFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUNiZ0IsVUFBQUEsVUFBVSxFQUFFTCxFQURDO0FBRWJWLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRztBQUZHLFNBQWY7QUFJQSxjQUFNO0FBQUVDLFVBQUFBO0FBQUYsWUFBd0IsS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUE5QjtBQUNBLGNBQU0rSSxtQkFBbUIsR0FBRyxNQUFNM0ksaUJBQWlCLENBQ2pELG1DQURpRCxFQUVqREYsTUFGaUQsQ0FBbkQ7QUFJQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLENBQUN3SSxtQkFBbUIsQ0FBQ0MsTUFBcEIsQ0FBMkJDLE1BRDVCO0FBRUp6SSxZQUFBQSxJQUFJLEVBQUV1STtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FqQkQsQ0FpQkUsT0FBT3RJLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyx1REFBZCxFQUF1RUYsR0FBdkU7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBN2hCcUI7O0FBQUEsNENBK2hCTCxPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDNUMsVUFBSTtBQUNGLGNBQU07QUFBRWlKLFVBQUFBLE1BQU0sR0FBRztBQUFYLFlBQXNCbEosR0FBRyxDQUFDZ0MsS0FBaEM7QUFDQSxjQUFNOUIsTUFBTSxHQUFHO0FBQ2JDLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRyxJQURHO0FBRWIrSSxVQUFBQTtBQUZhLFNBQWY7QUFJQSxjQUFNO0FBQUU5SSxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1tSixlQUFlLEdBQUcsTUFBTS9JLGlCQUFpQixDQUFDLHlCQUFELEVBQTRCRixNQUE1QixDQUEvQztBQUNBLGVBQU9ELEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUUySTtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FkRCxDQWNFLE9BQU8xSSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNkNBQWQsRUFBNkRGLEdBQTdEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXZqQnFCOztBQUFBLDRDQTBqQkwsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzVDLFVBQUk7QUFDRixjQUFNO0FBQUUrQixVQUFBQSxLQUFGO0FBQVNKLFVBQUFBLEtBQVQ7QUFBZ0JHLFVBQUFBO0FBQWhCLFlBQXlCL0IsR0FBRyxDQUFDRyxJQUFuQztBQUNBLGNBQU1ELE1BQU0sR0FBRztBQUFFMEIsVUFBQUEsS0FBRjtBQUFTRyxVQUFBQSxJQUFUO0FBQWU1QixVQUFBQSxJQUFJLEVBQUU2QjtBQUFyQixTQUFmO0FBRUEsY0FBTTtBQUFFNUIsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNMEksT0FBTyxHQUFHLE1BQU10SSxpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QkYsTUFBekIsQ0FBdkM7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFa0k7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BWkQsQ0FZRSxPQUFPakksR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDRDQUFkLEVBQTRERixHQUE1RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0FobEJxQjs7QUFDcEIsU0FBS2QsUUFBTCxHQUFnQkEsUUFBaEI7QUFDRDs7QUFIaUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5cbmltcG9ydCB7IElOREVYIH0gZnJvbSAnLi4vLi4vdXRpbHMvY29uc3RhbnRzJztcbmltcG9ydCB7IGlzSW5kZXhOb3RGb3VuZEVycm9yIH0gZnJvbSAnLi91dGlscy9oZWxwZXJzJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9uaXRvclNlcnZpY2Uge1xuICBjb25zdHJ1Y3Rvcihlc0RyaXZlcikge1xuICAgIHRoaXMuZXNEcml2ZXIgPSBlc0RyaXZlcjtcbiAgfVxuXG4gIGNyZWF0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGFyYW1zID0geyBib2R5OiByZXEuYm9keSB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgY3JlYXRlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuY3JlYXRlTW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IGNyZWF0ZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gY3JlYXRlTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgY3JlYXRlV29ya2Zsb3cgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGFyYW1zID0geyBib2R5OiByZXEuYm9keSB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgY3JlYXRlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuY3JlYXRlV29ya2Zsb3cnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiBjcmVhdGVSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGNyZWF0ZVdvcmtmbG93OicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBkZWxldGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IG1vbml0b3JJZDogaWQgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmRlbGV0ZU1vbml0b3InLCBwYXJhbXMpO1xuXG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiByZXNwb25zZS5yZXN1bHQgPT09ICdkZWxldGVkJyB8fCByZXNwb25zZS5yZXN1bHQgPT09IHVuZGVmaW5lZCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGRlbGV0ZU1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGRlbGV0ZVdvcmtmbG93ID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IHdvcmtmbG93SWQ6IGlkIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5kZWxldGVXb3JrZmxvdycsIHBhcmFtcyk7XG5cbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHJlc3BvbnNlLnJlc3VsdCA9PT0gJ2RlbGV0ZWQnIHx8IHJlc3BvbnNlLnJlc3VsdCA9PT0gdW5kZWZpbmVkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZGVsZXRlV29ya2Zsb3c6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldE1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZ2V0UmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICBsZXQgbW9uaXRvciA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnbW9uaXRvcicsIG51bGwpO1xuICAgICAgY29uc3QgdmVyc2lvbiA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnX3ZlcnNpb24nLCBudWxsKTtcbiAgICAgIGNvbnN0IGlmU2VxTm8gPSBfLmdldChnZXRSZXNwb25zZSwgJ19zZXFfbm8nLCBudWxsKTtcbiAgICAgIGNvbnN0IGlmUHJpbWFyeVRlcm0gPSBfLmdldChnZXRSZXNwb25zZSwgJ19wcmltYXJ5X3Rlcm0nLCBudWxsKTtcbiAgICAgIGNvbnN0IGFzc29jaWF0ZWRfd29ya2Zsb3dzID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdhc3NvY2lhdGVkX3dvcmtmbG93cycsIG51bGwpO1xuICAgICAgaWYgKG1vbml0b3IpIHtcbiAgICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgICBjb25zdCBhZ2dzUGFyYW1zID0ge1xuICAgICAgICAgIGluZGV4OiBJTkRFWC5BTExfQUxFUlRTLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgICAgbXVzdDoge1xuICAgICAgICAgICAgICAgICAgdGVybToge1xuICAgICAgICAgICAgICAgICAgICBtb25pdG9yX2lkOiBpZCxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBhZ2dzOiB7XG4gICAgICAgICAgICAgIGFjdGl2ZV9jb3VudDoge1xuICAgICAgICAgICAgICAgIHRlcm1zOiB7XG4gICAgICAgICAgICAgICAgICBmaWVsZDogJ3N0YXRlJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAnMjRfaG91cl9jb3VudCc6IHtcbiAgICAgICAgICAgICAgICBkYXRlX3JhbmdlOiB7XG4gICAgICAgICAgICAgICAgICBmaWVsZDogJ3N0YXJ0X3RpbWUnLFxuICAgICAgICAgICAgICAgICAgcmFuZ2VzOiBbeyBmcm9tOiAnbm93LTI0aC9oJyB9XSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBzZWFyY2hSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5nZXRNb25pdG9ycycsIGFnZ3NQYXJhbXMpO1xuICAgICAgICBjb25zdCBkYXlDb3VudCA9IF8uZ2V0KHNlYXJjaFJlc3BvbnNlLCAnYWdncmVnYXRpb25zLjI0X2hvdXJfY291bnQuYnVja2V0cy4wLmRvY19jb3VudCcsIDApO1xuICAgICAgICBjb25zdCBhY3RpdmVCdWNrZXRzID0gXy5nZXQoc2VhcmNoUmVzcG9uc2UsICdhZ2dyZWdhdGlvbnMuYWN0aXZlX2NvdW50LmJ1Y2tldHMnLCBbXSk7XG4gICAgICAgIGNvbnN0IGFjdGl2ZUNvdW50ID0gYWN0aXZlQnVja2V0cy5yZWR1Y2UoXG4gICAgICAgICAgKGFjYywgY3VycikgPT4gKGN1cnIua2V5ID09PSAnQUNUSVZFJyA/IGN1cnIuZG9jX2NvdW50IDogYWNjKSxcbiAgICAgICAgICAwXG4gICAgICAgICk7XG4gICAgICAgIGlmIChhc3NvY2lhdGVkX3dvcmtmbG93cykge1xuICAgICAgICAgIG1vbml0b3IgPSB7XG4gICAgICAgICAgICAuLi5tb25pdG9yLFxuICAgICAgICAgICAgYXNzb2NpYXRlZF93b3JrZmxvd3MsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBtb25pdG9yID0ge1xuICAgICAgICAgIC4uLm1vbml0b3IsXG4gICAgICAgICAgaXRlbV90eXBlOiBtb25pdG9yLndvcmtmbG93X3R5cGUgfHwgbW9uaXRvci5tb25pdG9yX3R5cGUsXG4gICAgICAgICAgaWQsXG4gICAgICAgICAgdmVyc2lvbixcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBvazogdHJ1ZSwgcmVzcDogbW9uaXRvciwgYWN0aXZlQ291bnQsIGRheUNvdW50LCB2ZXJzaW9uLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGdldE1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldFdvcmtmbG93ID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IG1vbml0b3JJZDogaWQgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGdldFJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldFdvcmtmbG93JywgcGFyYW1zKTtcbiAgICAgIGxldCB3b3JrZmxvdyA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnd29ya2Zsb3cnLCBudWxsKTtcbiAgICAgIGNvbnN0IHZlcnNpb24gPSBfLmdldChnZXRSZXNwb25zZSwgJ192ZXJzaW9uJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlNlcU5vID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfc2VxX25vJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlByaW1hcnlUZXJtID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfcHJpbWFyeV90ZXJtJywgbnVsbCk7XG4gICAgICB3b3JrZmxvdy5tb25pdG9yX3R5cGUgPSB3b3JrZmxvdy53b3JrZmxvd190eXBlO1xuICAgICAgd29ya2Zsb3cgPSB7XG4gICAgICAgIC4uLndvcmtmbG93LFxuICAgICAgICBpdGVtX3R5cGU6IHdvcmtmbG93LndvcmtmbG93X3R5cGUsXG4gICAgICAgIGlkLFxuICAgICAgICB2ZXJzaW9uLFxuICAgICAgfTtcblxuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiB3b3JrZmxvdyxcbiAgICAgICAgICBhY3RpdmVDb3VudDogMCxcbiAgICAgICAgICBkYXlDb3VudDogMCxcbiAgICAgICAgICB2ZXJzaW9uLFxuICAgICAgICAgIGlmU2VxTm8sXG4gICAgICAgICAgaWZQcmltYXJ5VGVybSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGdldFdvcmtmbG93OicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICB1cGRhdGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IG1vbml0b3JJZDogaWQsIGJvZHk6IHJlcS5ib2R5LCByZWZyZXNoOiAnd2FpdF9mb3InIH07XG4gICAgICBjb25zdCB7IHR5cGUgfSA9IHJlcS5ib2R5O1xuXG4gICAgICAvLyBUT0RPIERSQUZUOiBBcmUgd2Ugc3VyZSB3ZSBuZWVkIHRvIGluY2x1ZGUgaWZTZXFObyBhbmQgaWZQcmltYXJ5VGVybSBmcm9tIHRoZSBVSSBzaWRlIHdoZW4gdXBkYXRpbmcgbW9uaXRvcnM/XG4gICAgICBjb25zdCB7IGlmU2VxTm8sIGlmUHJpbWFyeVRlcm0gfSA9IHJlcS5xdWVyeTtcbiAgICAgIGlmIChpZlNlcU5vICYmIGlmUHJpbWFyeVRlcm0pIHtcbiAgICAgICAgcGFyYW1zLmlmX3NlcV9ubyA9IGlmU2VxTm87XG4gICAgICAgIHBhcmFtcy5pZl9wcmltYXJ5X3Rlcm0gPSBpZlByaW1hcnlUZXJtO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCB1cGRhdGVSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKFxuICAgICAgICBgYWxlcnRpbmcuJHt0eXBlID09PSAnd29ya2Zsb3cnID8gJ3VwZGF0ZVdvcmtmbG93JyA6ICd1cGRhdGVNb25pdG9yJ31gLFxuICAgICAgICBwYXJhbXNcbiAgICAgICk7XG4gICAgICBjb25zdCB7IF92ZXJzaW9uLCBfaWQgfSA9IHVwZGF0ZVJlc3BvbnNlO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICB2ZXJzaW9uOiBfdmVyc2lvbixcbiAgICAgICAgICBpZDogX2lkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gdXBkYXRlTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZ2V0TW9uaXRvcnMgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBmcm9tLCBzaXplLCBzZWFyY2gsIHNvcnREaXJlY3Rpb24sIHNvcnRGaWVsZCwgc3RhdGUsIG1vbml0b3JJZHMgfSA9IHJlcS5xdWVyeTtcblxuICAgICAgbGV0IG11c3QgPSB7IG1hdGNoX2FsbDoge30gfTtcbiAgICAgIGlmIChzZWFyY2gudHJpbSgpKSB7XG4gICAgICAgIC8vIFRoaXMgaXMgYW4gZXhwZW5zaXZlIHdpbGRjYXJkIHF1ZXJ5IHRvIG1hdGNoIG1vbml0b3IgbmFtZXMgc3VjaCBhczogXCJUaGlzIGlzIGEgbG9uZyBtb25pdG9yIG5hbWVcIlxuICAgICAgICAvLyBzZWFyY2ggcXVlcnkgPT4gXCJsb25nIG1vbml0XCJcbiAgICAgICAgLy8gVGhpcyBpcyBhY2NlcHRhYmxlIGJlY2F1c2Ugd2Ugd2lsbCBuZXZlciBhbGxvdyBtb3JlIHRoYW4gMSwwMDAgbW9uaXRvcnNcbiAgICAgICAgbXVzdCA9IHtcbiAgICAgICAgICBxdWVyeV9zdHJpbmc6IHtcbiAgICAgICAgICAgIGRlZmF1bHRfZmllbGQ6ICdtb25pdG9yLm5hbWUnLFxuICAgICAgICAgICAgZGVmYXVsdF9vcGVyYXRvcjogJ0FORCcsXG4gICAgICAgICAgICBxdWVyeTogYCoke3NlYXJjaC50cmltKCkuc3BsaXQoJyAnKS5qb2luKCcqIConKX0qYCxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICBjb25zdCBzaG91bGQgPSBbXTtcbiAgICAgIGNvbnN0IG11c3RMaXN0ID0gW211c3RdO1xuICAgICAgaWYgKG1vbml0b3JJZHMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBtdXN0TGlzdC5wdXNoKHtcbiAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgX2lkOiBBcnJheS5pc0FycmF5KG1vbml0b3JJZHMpID8gbW9uaXRvcklkcyA6IFttb25pdG9ySWRzXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAobW9uaXRvcklkcyA9PT0gJ2VtcHR5Jykge1xuICAgICAgICBtdXN0TGlzdC5wdXNoKHtcbiAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgX2lkOiBbXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgaWYgKHN0YXRlICE9PSAnYWxsJykge1xuICAgICAgICBjb25zdCBlbmFibGVkID0gc3RhdGUgPT09ICdlbmFibGVkJztcbiAgICAgICAgc2hvdWxkLnB1c2goeyB0ZXJtOiB7ICdtb25pdG9yLmVuYWJsZWQnOiBlbmFibGVkIH0gfSk7XG4gICAgICAgIHNob3VsZC5wdXNoKHsgdGVybTogeyAnd29ya2Zsb3cuZW5hYmxlZCc6IGVuYWJsZWQgfSB9KTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgbW9uaXRvclNvcnRzID0geyBuYW1lOiAnbW9uaXRvci5uYW1lLmtleXdvcmQnIH07XG4gICAgICBjb25zdCBtb25pdG9yU29ydFBhZ2VEYXRhID0geyBzaXplOiAxMDAwIH07XG4gICAgICBpZiAobW9uaXRvclNvcnRzW3NvcnRGaWVsZF0pIHtcbiAgICAgICAgbW9uaXRvclNvcnRQYWdlRGF0YS5zb3J0ID0gW3sgW21vbml0b3JTb3J0c1tzb3J0RmllbGRdXTogc29ydERpcmVjdGlvbiB9XTtcbiAgICAgICAgbW9uaXRvclNvcnRQYWdlRGF0YS5zaXplID0gXy5kZWZhdWx0VG8oc2l6ZSwgMTAwMCk7XG4gICAgICAgIG1vbml0b3JTb3J0UGFnZURhdGEuZnJvbSA9IF8uZGVmYXVsdFRvKGZyb20sIDApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzZXFfbm9fcHJpbWFyeV90ZXJtOiB0cnVlLFxuICAgICAgICAgIHZlcnNpb246IHRydWUsXG4gICAgICAgICAgLi4ubW9uaXRvclNvcnRQYWdlRGF0YSxcbiAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICBzaG91bGQsXG4gICAgICAgICAgICAgIG11c3Q6IG11c3RMaXN0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGFnZ3JlZ2F0aW9uczoge1xuICAgICAgICAgICAgYXNzb2NpYXRlZF9jb21wb3NpdGVfbW9uaXRvcnM6IHtcbiAgICAgICAgICAgICAgbmVzdGVkOiB7XG4gICAgICAgICAgICAgICAgcGF0aDogJ3dvcmtmbG93LmlucHV0cy5jb21wb3NpdGVfaW5wdXQuc2VxdWVuY2UuZGVsZWdhdGVzJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgICAgIG1vbml0b3JfaWRzOiB7XG4gICAgICAgICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZDogJ3dvcmtmbG93LmlucHV0cy5jb21wb3NpdGVfaW5wdXQuc2VxdWVuY2UuZGVsZWdhdGVzLm1vbml0b3JfaWQnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfTtcblxuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlcjogYWxlcnRpbmdDYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZ2V0UmVzcG9uc2UgPSBhd2FpdCBhbGVydGluZ0NhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5nZXRNb25pdG9ycycsIHBhcmFtcyk7XG5cbiAgICAgIGNvbnN0IHRvdGFsTW9uaXRvcnMgPSBfLmdldChnZXRSZXNwb25zZSwgJ2hpdHMudG90YWwudmFsdWUnLCAwKTtcbiAgICAgIGNvbnN0IG1vbml0b3JLZXlWYWx1ZVR1cGxlcyA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnaGl0cy5oaXRzJywgW10pLm1hcCgocmVzdWx0KSA9PiB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBfaWQ6IGlkLFxuICAgICAgICAgIF92ZXJzaW9uOiB2ZXJzaW9uLFxuICAgICAgICAgIF9zZXFfbm86IGlmU2VxTm8sXG4gICAgICAgICAgX3ByaW1hcnlfdGVybTogaWZQcmltYXJ5VGVybSxcbiAgICAgICAgICBfc291cmNlLFxuICAgICAgICB9ID0gcmVzdWx0O1xuICAgICAgICBjb25zdCBtb25pdG9yID0gX3NvdXJjZS5tb25pdG9yID8gX3NvdXJjZS5tb25pdG9yIDogX3NvdXJjZTtcbiAgICAgICAgbW9uaXRvclsnaXRlbV90eXBlJ10gPSBtb25pdG9yLndvcmtmbG93X3R5cGUgfHwgbW9uaXRvci5tb25pdG9yX3R5cGU7XG4gICAgICAgIGNvbnN0IHsgbmFtZSwgZW5hYmxlZCB9ID0gbW9uaXRvcjtcbiAgICAgICAgcmV0dXJuIFtpZCwgeyBpZCwgdmVyc2lvbiwgaWZTZXFObywgaWZQcmltYXJ5VGVybSwgbmFtZSwgZW5hYmxlZCwgbW9uaXRvciB9XTtcbiAgICAgIH0sIHt9KTtcbiAgICAgIGNvbnN0IG1vbml0b3JNYXAgPSBuZXcgTWFwKG1vbml0b3JLZXlWYWx1ZVR1cGxlcyk7XG4gICAgICBjb25zdCBhc3NvY2lhdGVkQ29tcG9zaXRlTW9uaXRvckNvdW50TWFwID0ge307XG4gICAgICBfLmdldChcbiAgICAgICAgZ2V0UmVzcG9uc2UsXG4gICAgICAgICdhZ2dyZWdhdGlvbnMuYXNzb2NpYXRlZF9jb21wb3NpdGVfbW9uaXRvcnMubW9uaXRvcl9pZHMuYnVja2V0cycsXG4gICAgICAgIFtdXG4gICAgICApLmZvckVhY2goKHsga2V5LCBkb2NfY291bnQgfSkgPT4ge1xuICAgICAgICBhc3NvY2lhdGVkQ29tcG9zaXRlTW9uaXRvckNvdW50TWFwW2tleV0gPSBkb2NfY291bnQ7XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG1vbml0b3JJZHNPdXRwdXQgPSBbLi4ubW9uaXRvck1hcC5rZXlzKCldO1xuXG4gICAgICBjb25zdCBhZ2dzT3JkZXJEYXRhID0ge307XG4gICAgICBjb25zdCBhZ2dzU29ydHMgPSB7XG4gICAgICAgIGFjdGl2ZTogJ2FjdGl2ZScsXG4gICAgICAgIGFja25vd2xlZGdlZDogJ2Fja25vd2xlZGdlZCcsXG4gICAgICAgIGVycm9yczogJ2Vycm9ycycsXG4gICAgICAgIGlnbm9yZWQ6ICdpZ25vcmVkJyxcbiAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWU6ICdsYXN0X25vdGlmaWNhdGlvbl90aW1lJyxcbiAgICAgIH07XG4gICAgICBpZiAoYWdnc1NvcnRzW3NvcnRGaWVsZF0pIHtcbiAgICAgICAgYWdnc09yZGVyRGF0YS5vcmRlciA9IHsgW2FnZ3NTb3J0c1tzb3J0RmllbGRdXTogc29ydERpcmVjdGlvbiB9O1xuICAgICAgfVxuICAgICAgY29uc3QgYWdnc1BhcmFtcyA9IHtcbiAgICAgICAgaW5kZXg6IElOREVYLkFMTF9BTEVSVFMsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgIHF1ZXJ5OiB7IHRlcm1zOiB7IG1vbml0b3JfaWQ6IG1vbml0b3JJZHNPdXRwdXQgfSB9LFxuICAgICAgICAgIGFnZ3JlZ2F0aW9uczoge1xuICAgICAgICAgICAgdW5pcV9tb25pdG9yX2lkczoge1xuICAgICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICAgIGZpZWxkOiAnbW9uaXRvcl9pZCcsXG4gICAgICAgICAgICAgICAgLi4uYWdnc09yZGVyRGF0YSxcbiAgICAgICAgICAgICAgICBzaXplOiBmcm9tICsgc2l6ZSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgYWdncmVnYXRpb25zOiB7XG4gICAgICAgICAgICAgICAgYWN0aXZlOiB7IGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnQUNUSVZFJyB9IH0gfSxcbiAgICAgICAgICAgICAgICBhY2tub3dsZWRnZWQ6IHsgZmlsdGVyOiB7IHRlcm06IHsgc3RhdGU6ICdBQ0tOT1dMRURHRUQnIH0gfSB9LFxuICAgICAgICAgICAgICAgIGVycm9yczogeyBmaWx0ZXI6IHsgdGVybTogeyBzdGF0ZTogJ0VSUk9SJyB9IH0gfSxcbiAgICAgICAgICAgICAgICBpZ25vcmVkOiB7XG4gICAgICAgICAgICAgICAgICBmaWx0ZXI6IHtcbiAgICAgICAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnQ09NUExFVEVEJyB9IH0sXG4gICAgICAgICAgICAgICAgICAgICAgbXVzdF9ub3Q6IHsgZXhpc3RzOiB7IGZpZWxkOiAnYWNrbm93bGVkZ2VkX3RpbWUnIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBsYXN0X25vdGlmaWNhdGlvbl90aW1lOiB7IG1heDogeyBmaWVsZDogJ2xhc3Rfbm90aWZpY2F0aW9uX3RpbWUnIH0gfSxcbiAgICAgICAgICAgICAgICBsYXRlc3RfYWxlcnQ6IHtcbiAgICAgICAgICAgICAgICAgIHRvcF9oaXRzOiB7XG4gICAgICAgICAgICAgICAgICAgIHNpemU6IDEsXG4gICAgICAgICAgICAgICAgICAgIHNvcnQ6IFt7IHN0YXJ0X3RpbWU6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgICAgICAgICAgICBfc291cmNlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgaW5jbHVkZXM6IFsnbGFzdF9ub3RpZmljYXRpb25fdGltZScsICd0cmlnZ2VyX25hbWUnXSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGVzQWdnc1Jlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldE1vbml0b3JzJywgYWdnc1BhcmFtcyk7XG4gICAgICBjb25zdCBidWNrZXRzID0gXy5nZXQoZXNBZ2dzUmVzcG9uc2UsICdhZ2dyZWdhdGlvbnMudW5pcV9tb25pdG9yX2lkcy5idWNrZXRzJywgW10pLm1hcChcbiAgICAgICAgKGJ1Y2tldCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGtleTogaWQsXG4gICAgICAgICAgICBsYXN0X25vdGlmaWNhdGlvbl90aW1lOiB7IHZhbHVlOiBsYXN0Tm90aWZpY2F0aW9uVGltZSB9LFxuICAgICAgICAgICAgaWdub3JlZDogeyBkb2NfY291bnQ6IGlnbm9yZWQgfSxcbiAgICAgICAgICAgIGFja25vd2xlZGdlZDogeyBkb2NfY291bnQ6IGFja25vd2xlZGdlZCB9LFxuICAgICAgICAgICAgYWN0aXZlOiB7IGRvY19jb3VudDogYWN0aXZlIH0sXG4gICAgICAgICAgICBlcnJvcnM6IHsgZG9jX2NvdW50OiBlcnJvcnMgfSxcbiAgICAgICAgICAgIGxhdGVzdF9hbGVydDoge1xuICAgICAgICAgICAgICBoaXRzOiB7XG4gICAgICAgICAgICAgICAgaGl0czogW1xuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBfc291cmNlOiB7IHRyaWdnZXJfbmFtZTogbGF0ZXN0QWxlcnQgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSA9IGJ1Y2tldDtcbiAgICAgICAgICBjb25zdCBtb25pdG9yID0gbW9uaXRvck1hcC5nZXQoaWQpO1xuICAgICAgICAgIG1vbml0b3JNYXAuZGVsZXRlKGlkKTtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4ubW9uaXRvcixcbiAgICAgICAgICAgIGlkLFxuICAgICAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWUsXG4gICAgICAgICAgICBpZ25vcmVkLFxuICAgICAgICAgICAgbGF0ZXN0QWxlcnQsXG4gICAgICAgICAgICBhY2tub3dsZWRnZWQsXG4gICAgICAgICAgICBhY3RpdmUsXG4gICAgICAgICAgICBlcnJvcnMsXG4gICAgICAgICAgICBjdXJyZW50VGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgIGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ250OiBhc3NvY2lhdGVkQ29tcG9zaXRlTW9uaXRvckNvdW50TWFwW2lkXSB8fCAwLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IHVudXNlZE1vbml0b3JzID0gWy4uLm1vbml0b3JNYXAudmFsdWVzKCldLm1hcCgobW9uaXRvcikgPT4gKHtcbiAgICAgICAgLi4ubW9uaXRvcixcbiAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWU6IG51bGwsXG4gICAgICAgIGlnbm9yZWQ6IDAsXG4gICAgICAgIGFjdGl2ZTogMCxcbiAgICAgICAgYWNrbm93bGVkZ2VkOiAwLFxuICAgICAgICBlcnJvcnM6IDAsXG4gICAgICAgIGxhdGVzdEFsZXJ0OiAnLS0nLFxuICAgICAgICBjdXJyZW50VGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDbnQ6IGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ291bnRNYXBbbW9uaXRvci5pZF0gfHwgMCxcbiAgICAgIH0pKTtcblxuICAgICAgbGV0IHJlc3VsdHMgPSBfLm9yZGVyQnkoYnVja2V0cy5jb25jYXQodW51c2VkTW9uaXRvcnMpLCBbc29ydEZpZWxkXSwgW3NvcnREaXJlY3Rpb25dKTtcbiAgICAgIC8vIElmIHdlIHNvcnRlZCBvbiBtb25pdG9yIG5hbWUgdGhlbiB3ZSBhbHJlYWR5IGFwcGxpZWQgZnJvbS9zaXplIHRvIHRoZSBmaXJzdCBxdWVyeSB0byBsaW1pdCB3aGF0IHdlJ3JlIGFnZ3JlZ2F0aW5nIG92ZXJcbiAgICAgIC8vIFRoZXJlZm9yZSB3ZSBkbyBub3QgbmVlZCB0byBhcHBseSBmcm9tL3NpemUgdG8gdGhpcyByZXN1bHQgc2V0XG4gICAgICAvLyBJZiB3ZSBzb3J0ZWQgb24gYWdncmVnYXRpb25zLCB0aGVuIHRoaXMgaXMgb3VyIGluIG1lbW9yeSBwYWdpbmF0aW9uXG4gICAgICBpZiAoIW1vbml0b3JTb3J0c1tzb3J0RmllbGRdKSB7XG4gICAgICAgIHJlc3VsdHMgPSByZXN1bHRzLnNsaWNlKGZyb20sIGZyb20gKyBzaXplKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICBtb25pdG9yczogcmVzdWx0cyxcbiAgICAgICAgICB0b3RhbE1vbml0b3JzLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZ2V0TW9uaXRvcnMnLCBlcnIpO1xuICAgICAgaWYgKGlzSW5kZXhOb3RGb3VuZEVycm9yKGVycikpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBvazogZmFsc2UsIHJlc3A6IHsgdG90YWxNb25pdG9yczogMCwgbW9uaXRvcnM6IFtdIH0gfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBhY2tub3dsZWRnZUFsZXJ0cyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICBtb25pdG9ySWQ6IGlkLFxuICAgICAgICBib2R5OiByZXEuYm9keSxcbiAgICAgIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBhY2tub3dsZWRnZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmFja25vd2xlZGdlQWxlcnRzJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6ICFhY2tub3dsZWRnZVJlc3BvbnNlLmZhaWxlZC5sZW5ndGgsXG4gICAgICAgICAgcmVzcDogYWNrbm93bGVkZ2VSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGFja25vd2xlZGdlQWxlcnRzOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBhY2tub3dsZWRnZUNoYWluZWRBbGVydHMgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgICAgd29ya2Zsb3dJZDogaWQsXG4gICAgICAgIGJvZHk6IHJlcS5ib2R5LFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGFja25vd2xlZGdlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcihcbiAgICAgICAgJ2FsZXJ0aW5nLmFja25vd2xlZGdlQ2hhaW5lZEFsZXJ0cycsXG4gICAgICAgIHBhcmFtc1xuICAgICAgKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6ICFhY2tub3dsZWRnZVJlc3BvbnNlLmZhaWxlZC5sZW5ndGgsXG4gICAgICAgICAgcmVzcDogYWNrbm93bGVkZ2VSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGFja25vd2xlZGdlQ2hhaW5lZEFsZXJ0czonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZXhlY3V0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBkcnlydW4gPSAndHJ1ZScgfSA9IHJlcS5xdWVyeTtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgICAgYm9keTogcmVxLmJvZHksXG4gICAgICAgIGRyeXJ1bixcbiAgICAgIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBleGVjdXRlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZXhlY3V0ZU1vbml0b3InLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiBleGVjdXRlUmVzcG9uc2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBleGVjdXRlTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgLy9UT0RPOiBUaGlzIGlzIHRlbXBvcmFyaWx5IGEgcGFzcyB0aHJvdWdoIGNhbGwgd2hpY2ggbmVlZHMgdG8gYmUgZGVwcmVjYXRlZFxuICBzZWFyY2hNb25pdG9ycyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IHF1ZXJ5LCBpbmRleCwgc2l6ZSB9ID0gcmVxLmJvZHk7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IGluZGV4LCBzaXplLCBib2R5OiBxdWVyeSB9O1xuXG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldE1vbml0b3JzJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogcmVzdWx0cyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIHNlYXJjaE1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xufVxuIl19