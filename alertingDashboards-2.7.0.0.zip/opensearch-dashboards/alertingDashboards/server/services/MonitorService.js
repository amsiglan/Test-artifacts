"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _lodash = _interopRequireDefault(require("lodash"));

var _constants = require("../../utils/constants");

var _helpers = require("./utils/helpers");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class MonitorService {
  constructor(esDriver) {
    _defineProperty(this, "createMonitor", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "createWorkflow", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createWorkflow', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteMonitor', params);
        return res.ok({
          body: {
            ok: response.result === 'deleted'
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteWorkflow", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          workflowId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteWorkflow', params);
        console.log('delete workflow response ^*^*^*^*^*');
        console.log(JSON.stringify(response));
        return res.ok({
          body: {
            ok: response.result === 'deleted' || response.result === undefined
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitor", async (context, req, res) => {
      console.log('****** GET MONITOR *****');

      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getMonitor', params);
        console.log('Get monitor complete response ^^^^^^^^^');
        console.log(JSON.stringify(getResponse));

        let monitor = _lodash.default.get(getResponse, 'monitor', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        const associated_workflows = _lodash.default.get(getResponse, 'associated_workflows', null);

        if (monitor) {
          const {
            callAsCurrentUser
          } = this.esDriver.asScoped(req);
          const aggsParams = {
            index: _constants.INDEX.ALL_ALERTS,
            body: {
              size: 0,
              query: {
                bool: {
                  must: {
                    term: {
                      monitor_id: id
                    }
                  }
                }
              },
              aggs: {
                active_count: {
                  terms: {
                    field: 'state'
                  }
                },
                '24_hour_count': {
                  date_range: {
                    field: 'start_time',
                    ranges: [{
                      from: 'now-24h/h'
                    }]
                  }
                }
              }
            }
          };
          const searchResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

          const dayCount = _lodash.default.get(searchResponse, 'aggregations.24_hour_count.buckets.0.doc_count', 0);

          const activeBuckets = _lodash.default.get(searchResponse, 'aggregations.active_count.buckets', []);

          const activeCount = activeBuckets.reduce((acc, curr) => curr.key === 'ACTIVE' ? curr.doc_count : acc, 0);

          if (associated_workflows) {
            monitor = { ...monitor,
              associated_workflows
            };
          }

          return res.ok({
            body: {
              ok: true,
              resp: monitor,
              activeCount,
              dayCount,
              version,
              ifSeqNo,
              ifPrimaryTerm
            }
          });
        } else {
          return res.ok({
            body: {
              ok: false
            }
          });
        }
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getWorkflow", async (context, req, res) => {
      console.log('****** GET WORKFLOW *****');

      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getWorkflow', params);

        const monitor = _lodash.default.get(getResponse, 'workflow', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        monitor.monitor_type = monitor.workflow_type;
        return res.ok({
          body: {
            ok: true,
            resp: monitor,
            activeCount: 0,
            dayCount: 0,
            version,
            ifSeqNo,
            ifPrimaryTerm
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "updateMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body,
          refresh: 'wait_for'
        };
        const {
          type
        } = req.body; // TODO DRAFT: Are we sure we need to include ifSeqNo and ifPrimaryTerm from the UI side when updating monitors?

        const {
          ifSeqNo,
          ifPrimaryTerm
        } = req.query;

        if (ifSeqNo && ifPrimaryTerm) {
          params.if_seq_no = ifSeqNo;
          params.if_primary_term = ifPrimaryTerm;
        }

        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const updateResponse = await callAsCurrentUser(`alerting.${type === 'workflow' ? 'updateWorkflow' : 'updateMonitor'}`, params);
        const {
          _version,
          _id
        } = updateResponse;
        return res.ok({
          body: {
            ok: true,
            version: _version,
            id: _id
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - updateMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitors", async (context, req, res) => {
      console.log('****** GET MONITORS *****');

      try {
        const {
          from,
          size,
          search,
          sortDirection,
          sortField,
          state
        } = req.query;
        let must = {
          match_all: {}
        };

        if (search.trim()) {
          // This is an expensive wildcard query to match monitor names such as: "This is a long monitor name"
          // search query => "long monit"
          // This is acceptable because we will never allow more than 1,000 monitors
          must = {
            query_string: {
              default_field: 'monitor.name',
              default_operator: 'AND',
              query: `*${search.trim().split(' ').join('* *')}*`
            }
          };
        }

        const should = [];

        if (state !== 'all') {
          const enabled = state === 'enabled';
          should.push({
            term: {
              'monitor.enabled': enabled
            }
          });
          should.push({
            term: {
              'workflow.enabled': enabled
            }
          });
        }

        const monitorSorts = {
          name: 'monitor.name.keyword'
        };
        const monitorSortPageData = {
          size: 1000
        };

        if (monitorSorts[sortField]) {
          monitorSortPageData.sort = [{
            [monitorSorts[sortField]]: sortDirection
          }];
          monitorSortPageData.size = _lodash.default.defaultTo(size, 1000);
          monitorSortPageData.from = _lodash.default.defaultTo(from, 0);
        }

        const params = {
          body: {
            seq_no_primary_term: true,
            version: true,
            ...monitorSortPageData,
            query: {
              bool: {
                should
              }
            },
            aggregations: {
              associated_composite_monitors: {
                nested: {
                  path: 'workflow.inputs.composite_input.sequence.delegates'
                },
                aggs: {
                  monitor_ids: {
                    terms: {
                      field: 'workflow.inputs.composite_input.sequence.delegates.monitor_id'
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser: alertingCallAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await alertingCallAsCurrentUser('alerting.getMonitors', params);

        const totalMonitors = _lodash.default.get(getResponse, 'hits.total.value', 0);

        const monitorKeyValueTuples = _lodash.default.get(getResponse, 'hits.hits', []).map(result => {
          const {
            _id: id,
            _version: version,
            _seq_no: ifSeqNo,
            _primary_term: ifPrimaryTerm,
            _source: monitor
          } = result;
          const {
            name,
            enabled
          } = monitor;
          return [id, {
            id,
            version,
            ifSeqNo,
            ifPrimaryTerm,
            name,
            enabled,
            monitor
          }];
        }, {});

        const monitorMap = new Map(monitorKeyValueTuples);
        const monitorIds = [...monitorMap.keys()];
        const associatedCompositeMonitorCountMap = {};

        _lodash.default.get(getResponse, 'aggregations.associated_composite_monitors.monitor_ids.buckets', []).forEach(({
          key,
          doc_count
        }) => {
          associatedCompositeMonitorCountMap[key] = doc_count;
        });

        const aggsOrderData = {};
        const aggsSorts = {
          active: 'active',
          acknowledged: 'acknowledged',
          errors: 'errors',
          ignored: 'ignored',
          lastNotificationTime: 'last_notification_time'
        };

        if (aggsSorts[sortField]) {
          aggsOrderData.order = {
            [aggsSorts[sortField]]: sortDirection
          };
        }

        const aggsParams = {
          index: _constants.INDEX.ALL_ALERTS,
          body: {
            size: 0,
            query: {
              terms: {
                monitor_id: monitorIds
              }
            },
            aggregations: {
              uniq_monitor_ids: {
                terms: {
                  field: 'monitor_id',
                  ...aggsOrderData,
                  size: from + size
                },
                aggregations: {
                  active: {
                    filter: {
                      term: {
                        state: 'ACTIVE'
                      }
                    }
                  },
                  acknowledged: {
                    filter: {
                      term: {
                        state: 'ACKNOWLEDGED'
                      }
                    }
                  },
                  errors: {
                    filter: {
                      term: {
                        state: 'ERROR'
                      }
                    }
                  },
                  ignored: {
                    filter: {
                      bool: {
                        filter: {
                          term: {
                            state: 'COMPLETED'
                          }
                        },
                        must_not: {
                          exists: {
                            field: 'acknowledged_time'
                          }
                        }
                      }
                    }
                  },
                  last_notification_time: {
                    max: {
                      field: 'last_notification_time'
                    }
                  },
                  latest_alert: {
                    top_hits: {
                      size: 1,
                      sort: [{
                        start_time: {
                          order: 'desc'
                        }
                      }],
                      _source: {
                        includes: ['last_notification_time', 'trigger_name']
                      }
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const esAggsResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

        const buckets = _lodash.default.get(esAggsResponse, 'aggregations.uniq_monitor_ids.buckets', []).map(bucket => {
          const {
            key: id,
            last_notification_time: {
              value: lastNotificationTime
            },
            ignored: {
              doc_count: ignored
            },
            acknowledged: {
              doc_count: acknowledged
            },
            active: {
              doc_count: active
            },
            errors: {
              doc_count: errors
            },
            latest_alert: {
              hits: {
                hits: [{
                  _source: {
                    trigger_name: latestAlert
                  }
                }]
              }
            }
          } = bucket;
          const monitor = monitorMap.get(id);
          monitorMap.delete(id);
          return { ...monitor,
            id,
            lastNotificationTime,
            ignored,
            latestAlert,
            acknowledged,
            active,
            errors,
            currentTime: Date.now(),
            associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[id] || 0
          };
        });

        const unusedMonitors = [...monitorMap.values()].map(monitor => ({ ...monitor,
          lastNotificationTime: null,
          ignored: 0,
          active: 0,
          acknowledged: 0,
          errors: 0,
          latestAlert: '--',
          currentTime: Date.now(),
          associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[monitor.id] || 0
        }));

        let results = _lodash.default.orderBy(buckets.concat(unusedMonitors), [sortField], [sortDirection]); // If we sorted on monitor name then we already applied from/size to the first query to limit what we're aggregating over
        // Therefore we do not need to apply from/size to this result set
        // If we sorted on aggregations, then this is our in memory pagination


        if (!monitorSorts[sortField]) {
          results = results.slice(from, from + size);
        }

        return res.ok({
          body: {
            ok: true,
            monitors: results,
            totalMonitors
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitors', err);

        if ((0, _helpers.isIndexNotFoundError)(err)) {
          return res.ok({
            body: {
              ok: false,
              resp: {
                totalMonitors: 0,
                monitors: []
              }
            }
          });
        }

        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "acknowledgeAlerts", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const acknowledgeResponse = await callAsCurrentUser('alerting.acknowledgeAlerts', params);
        return res.ok({
          body: {
            ok: !acknowledgeResponse.failed.length,
            resp: acknowledgeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - acknowledgeAlerts:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "executeMonitor", async (context, req, res) => {
      try {
        const {
          dryrun = 'true'
        } = req.query;
        const params = {
          body: req.body,
          dryrun
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const executeResponse = await callAsCurrentUser('alerting.executeMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: executeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - executeMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "searchMonitors", async (context, req, res) => {
      try {
        const {
          query,
          index,
          size
        } = req.body;
        const params = {
          index,
          size,
          body: query
        };
        console.log('Search monitors ******* ');
        console.log(JSON.stringify(params));
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const results = await callAsCurrentUser('alerting.getMonitors', params);
        return res.ok({
          body: {
            ok: true,
            resp: results
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - searchMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    this.esDriver = esDriver;
  }

}

exports.default = MonitorService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk1vbml0b3JTZXJ2aWNlLmpzIl0sIm5hbWVzIjpbIk1vbml0b3JTZXJ2aWNlIiwiY29uc3RydWN0b3IiLCJlc0RyaXZlciIsImNvbnRleHQiLCJyZXEiLCJyZXMiLCJwYXJhbXMiLCJib2R5IiwiY2FsbEFzQ3VycmVudFVzZXIiLCJhc1Njb3BlZCIsImNyZWF0ZVJlc3BvbnNlIiwib2siLCJyZXNwIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibWVzc2FnZSIsImlkIiwibW9uaXRvcklkIiwicmVzcG9uc2UiLCJyZXN1bHQiLCJ3b3JrZmxvd0lkIiwibG9nIiwiSlNPTiIsInN0cmluZ2lmeSIsInVuZGVmaW5lZCIsImdldFJlc3BvbnNlIiwibW9uaXRvciIsIl8iLCJnZXQiLCJ2ZXJzaW9uIiwiaWZTZXFObyIsImlmUHJpbWFyeVRlcm0iLCJhc3NvY2lhdGVkX3dvcmtmbG93cyIsImFnZ3NQYXJhbXMiLCJpbmRleCIsIklOREVYIiwiQUxMX0FMRVJUUyIsInNpemUiLCJxdWVyeSIsImJvb2wiLCJtdXN0IiwidGVybSIsIm1vbml0b3JfaWQiLCJhZ2dzIiwiYWN0aXZlX2NvdW50IiwidGVybXMiLCJmaWVsZCIsImRhdGVfcmFuZ2UiLCJyYW5nZXMiLCJmcm9tIiwic2VhcmNoUmVzcG9uc2UiLCJkYXlDb3VudCIsImFjdGl2ZUJ1Y2tldHMiLCJhY3RpdmVDb3VudCIsInJlZHVjZSIsImFjYyIsImN1cnIiLCJrZXkiLCJkb2NfY291bnQiLCJtb25pdG9yX3R5cGUiLCJ3b3JrZmxvd190eXBlIiwicmVmcmVzaCIsInR5cGUiLCJpZl9zZXFfbm8iLCJpZl9wcmltYXJ5X3Rlcm0iLCJ1cGRhdGVSZXNwb25zZSIsIl92ZXJzaW9uIiwiX2lkIiwic2VhcmNoIiwic29ydERpcmVjdGlvbiIsInNvcnRGaWVsZCIsInN0YXRlIiwibWF0Y2hfYWxsIiwidHJpbSIsInF1ZXJ5X3N0cmluZyIsImRlZmF1bHRfZmllbGQiLCJkZWZhdWx0X29wZXJhdG9yIiwic3BsaXQiLCJqb2luIiwic2hvdWxkIiwiZW5hYmxlZCIsInB1c2giLCJtb25pdG9yU29ydHMiLCJuYW1lIiwibW9uaXRvclNvcnRQYWdlRGF0YSIsInNvcnQiLCJkZWZhdWx0VG8iLCJzZXFfbm9fcHJpbWFyeV90ZXJtIiwiYWdncmVnYXRpb25zIiwiYXNzb2NpYXRlZF9jb21wb3NpdGVfbW9uaXRvcnMiLCJuZXN0ZWQiLCJwYXRoIiwibW9uaXRvcl9pZHMiLCJhbGVydGluZ0NhbGxBc0N1cnJlbnRVc2VyIiwidG90YWxNb25pdG9ycyIsIm1vbml0b3JLZXlWYWx1ZVR1cGxlcyIsIm1hcCIsIl9zZXFfbm8iLCJfcHJpbWFyeV90ZXJtIiwiX3NvdXJjZSIsIm1vbml0b3JNYXAiLCJNYXAiLCJtb25pdG9ySWRzIiwia2V5cyIsImFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ291bnRNYXAiLCJmb3JFYWNoIiwiYWdnc09yZGVyRGF0YSIsImFnZ3NTb3J0cyIsImFjdGl2ZSIsImFja25vd2xlZGdlZCIsImVycm9ycyIsImlnbm9yZWQiLCJsYXN0Tm90aWZpY2F0aW9uVGltZSIsIm9yZGVyIiwidW5pcV9tb25pdG9yX2lkcyIsImZpbHRlciIsIm11c3Rfbm90IiwiZXhpc3RzIiwibGFzdF9ub3RpZmljYXRpb25fdGltZSIsIm1heCIsImxhdGVzdF9hbGVydCIsInRvcF9oaXRzIiwic3RhcnRfdGltZSIsImluY2x1ZGVzIiwiZXNBZ2dzUmVzcG9uc2UiLCJidWNrZXRzIiwiYnVja2V0IiwidmFsdWUiLCJoaXRzIiwidHJpZ2dlcl9uYW1lIiwibGF0ZXN0QWxlcnQiLCJkZWxldGUiLCJjdXJyZW50VGltZSIsIkRhdGUiLCJub3ciLCJhc3NvY2lhdGVkQ29tcG9zaXRlTW9uaXRvckNudCIsInVudXNlZE1vbml0b3JzIiwidmFsdWVzIiwicmVzdWx0cyIsIm9yZGVyQnkiLCJjb25jYXQiLCJzbGljZSIsIm1vbml0b3JzIiwiYWNrbm93bGVkZ2VSZXNwb25zZSIsImZhaWxlZCIsImxlbmd0aCIsImRyeXJ1biIsImV4ZWN1dGVSZXNwb25zZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUtBOztBQUVBOztBQUNBOzs7Ozs7QUFFZSxNQUFNQSxjQUFOLENBQXFCO0FBQ2xDQyxFQUFBQSxXQUFXLENBQUNDLFFBQUQsRUFBVztBQUFBLDJDQUlOLE9BQU9DLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUMzQyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxHQUFHO0FBQUVDLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRztBQUFaLFNBQWY7QUFDQSxjQUFNO0FBQUVDLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTU0sY0FBYyxHQUFHLE1BQU1GLGlCQUFpQixDQUFDLHdCQUFELEVBQTJCRixNQUEzQixDQUE5QztBQUNBLGVBQU9ELEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVGO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQVZELENBVUUsT0FBT0csR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDRDQUFkLEVBQTRERixHQUE1RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0F4QnFCOztBQUFBLDRDQTBCTCxPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDNUMsVUFBSTtBQUNGLGNBQU1DLE1BQU0sR0FBRztBQUFFQyxVQUFBQSxJQUFJLEVBQUVILEdBQUcsQ0FBQ0c7QUFBWixTQUFmO0FBQ0EsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1NLGNBQWMsR0FBRyxNQUFNRixpQkFBaUIsQ0FBQyx5QkFBRCxFQUE0QkYsTUFBNUIsQ0FBOUM7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFRjtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FWRCxDQVVFLE9BQU9HLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw2Q0FBZCxFQUE2REYsR0FBN0Q7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBOUNxQjs7QUFBQSwyQ0FnRE4sT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUFFWSxVQUFBQSxTQUFTLEVBQUVEO0FBQWIsU0FBZjtBQUNBLGNBQU07QUFBRVQsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNZSxRQUFRLEdBQUcsTUFBTVgsaUJBQWlCLENBQUMsd0JBQUQsRUFBMkJGLE1BQTNCLENBQXhDO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRVEsUUFBUSxDQUFDQyxNQUFULEtBQW9CO0FBRHBCO0FBRE0sU0FBUCxDQUFQO0FBS0QsT0FWRCxDQVVFLE9BQU9QLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw0Q0FBZCxFQUE0REYsR0FBNUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBcEVxQjs7QUFBQSw0Q0FzRUwsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzVDLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUFFZSxVQUFBQSxVQUFVLEVBQUVKO0FBQWQsU0FBZjtBQUNBLGNBQU07QUFBRVQsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNZSxRQUFRLEdBQUcsTUFBTVgsaUJBQWlCLENBQUMseUJBQUQsRUFBNEJGLE1BQTVCLENBQXhDO0FBQ0FRLFFBQUFBLE9BQU8sQ0FBQ1EsR0FBUixDQUFZLHFDQUFaO0FBQ0FSLFFBQUFBLE9BQU8sQ0FBQ1EsR0FBUixDQUFZQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUwsUUFBZixDQUFaO0FBQ0EsZUFBT2QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRVEsUUFBUSxDQUFDQyxNQUFULEtBQW9CLFNBQXBCLElBQWlDRCxRQUFRLENBQUNDLE1BQVQsS0FBb0JLO0FBRHJEO0FBRE0sU0FBUCxDQUFQO0FBS0QsT0FaRCxDQVlFLE9BQU9aLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw2Q0FBZCxFQUE2REYsR0FBN0Q7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBNUZxQjs7QUFBQSx3Q0E4RlQsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3hDUyxNQUFBQSxPQUFPLENBQUNRLEdBQVIsQ0FBWSwwQkFBWjs7QUFDQSxVQUFJO0FBQ0YsY0FBTTtBQUFFTCxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRVksVUFBQUEsU0FBUyxFQUFFRDtBQUFiLFNBQWY7QUFDQSxjQUFNO0FBQUVULFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTXNCLFdBQVcsR0FBRyxNQUFNbEIsaUJBQWlCLENBQUMscUJBQUQsRUFBd0JGLE1BQXhCLENBQTNDO0FBQ0FRLFFBQUFBLE9BQU8sQ0FBQ1EsR0FBUixDQUFZLHlDQUFaO0FBQ0FSLFFBQUFBLE9BQU8sQ0FBQ1EsR0FBUixDQUFZQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUUsV0FBZixDQUFaOztBQUNBLFlBQUlDLE9BQU8sR0FBR0MsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixTQUFuQixFQUE4QixJQUE5QixDQUFkOztBQUNBLGNBQU1JLE9BQU8sR0FBR0YsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixVQUFuQixFQUErQixJQUEvQixDQUFoQjs7QUFDQSxjQUFNSyxPQUFPLEdBQUdILGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsU0FBbkIsRUFBOEIsSUFBOUIsQ0FBaEI7O0FBQ0EsY0FBTU0sYUFBYSxHQUFHSixnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLGVBQW5CLEVBQW9DLElBQXBDLENBQXRCOztBQUNBLGNBQU1PLG9CQUFvQixHQUFHTCxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLHNCQUFuQixFQUEyQyxJQUEzQyxDQUE3Qjs7QUFDQSxZQUFJQyxPQUFKLEVBQWE7QUFDWCxnQkFBTTtBQUFFbkIsWUFBQUE7QUFBRixjQUF3QixLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQTlCO0FBQ0EsZ0JBQU04QixVQUFVLEdBQUc7QUFDakJDLFlBQUFBLEtBQUssRUFBRUMsaUJBQU1DLFVBREk7QUFFakI5QixZQUFBQSxJQUFJLEVBQUU7QUFDSitCLGNBQUFBLElBQUksRUFBRSxDQURGO0FBRUpDLGNBQUFBLEtBQUssRUFBRTtBQUNMQyxnQkFBQUEsSUFBSSxFQUFFO0FBQ0pDLGtCQUFBQSxJQUFJLEVBQUU7QUFDSkMsb0JBQUFBLElBQUksRUFBRTtBQUNKQyxzQkFBQUEsVUFBVSxFQUFFMUI7QUFEUjtBQURGO0FBREY7QUFERCxlQUZIO0FBV0oyQixjQUFBQSxJQUFJLEVBQUU7QUFDSkMsZ0JBQUFBLFlBQVksRUFBRTtBQUNaQyxrQkFBQUEsS0FBSyxFQUFFO0FBQ0xDLG9CQUFBQSxLQUFLLEVBQUU7QUFERjtBQURLLGlCQURWO0FBTUosaUNBQWlCO0FBQ2ZDLGtCQUFBQSxVQUFVLEVBQUU7QUFDVkQsb0JBQUFBLEtBQUssRUFBRSxZQURHO0FBRVZFLG9CQUFBQSxNQUFNLEVBQUUsQ0FBQztBQUFFQyxzQkFBQUEsSUFBSSxFQUFFO0FBQVIscUJBQUQ7QUFGRTtBQURHO0FBTmI7QUFYRjtBQUZXLFdBQW5CO0FBNEJBLGdCQUFNQyxjQUFjLEdBQUcsTUFBTTNDLGlCQUFpQixDQUFDLHNCQUFELEVBQXlCMEIsVUFBekIsQ0FBOUM7O0FBQ0EsZ0JBQU1rQixRQUFRLEdBQUd4QixnQkFBRUMsR0FBRixDQUFNc0IsY0FBTixFQUFzQixnREFBdEIsRUFBd0UsQ0FBeEUsQ0FBakI7O0FBQ0EsZ0JBQU1FLGFBQWEsR0FBR3pCLGdCQUFFQyxHQUFGLENBQU1zQixjQUFOLEVBQXNCLG1DQUF0QixFQUEyRCxFQUEzRCxDQUF0Qjs7QUFDQSxnQkFBTUcsV0FBVyxHQUFHRCxhQUFhLENBQUNFLE1BQWQsQ0FDbEIsQ0FBQ0MsR0FBRCxFQUFNQyxJQUFOLEtBQWdCQSxJQUFJLENBQUNDLEdBQUwsS0FBYSxRQUFiLEdBQXdCRCxJQUFJLENBQUNFLFNBQTdCLEdBQXlDSCxHQUR2QyxFQUVsQixDQUZrQixDQUFwQjs7QUFJQSxjQUFJdkIsb0JBQUosRUFBMEI7QUFDeEJOLFlBQUFBLE9BQU8sR0FBRyxFQUNSLEdBQUdBLE9BREs7QUFFUk0sY0FBQUE7QUFGUSxhQUFWO0FBSUQ7O0FBQ0QsaUJBQU81QixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFBRUksY0FBQUEsRUFBRSxFQUFFLElBQU47QUFBWUMsY0FBQUEsSUFBSSxFQUFFZSxPQUFsQjtBQUEyQjJCLGNBQUFBLFdBQTNCO0FBQXdDRixjQUFBQSxRQUF4QztBQUFrRHRCLGNBQUFBLE9BQWxEO0FBQTJEQyxjQUFBQSxPQUEzRDtBQUFvRUMsY0FBQUE7QUFBcEU7QUFETSxXQUFQLENBQVA7QUFHRCxTQTlDRCxNQThDTztBQUNMLGlCQUFPM0IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosWUFBQUEsSUFBSSxFQUFFO0FBQ0pJLGNBQUFBLEVBQUUsRUFBRTtBQURBO0FBRE0sV0FBUCxDQUFQO0FBS0Q7QUFDRixPQWpFRCxDQWlFRSxPQUFPRSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMseUNBQWQsRUFBeURGLEdBQXpEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQTFLcUI7O0FBQUEseUNBNEtSLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUN6Q1MsTUFBQUEsT0FBTyxDQUFDUSxHQUFSLENBQVksMkJBQVo7O0FBQ0EsVUFBSTtBQUNGLGNBQU07QUFBRUwsVUFBQUE7QUFBRixZQUFTYixHQUFHLENBQUNFLE1BQW5CO0FBQ0EsY0FBTUEsTUFBTSxHQUFHO0FBQUVZLFVBQUFBLFNBQVMsRUFBRUQ7QUFBYixTQUFmO0FBQ0EsY0FBTTtBQUFFVCxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1zQixXQUFXLEdBQUcsTUFBTWxCLGlCQUFpQixDQUFDLHNCQUFELEVBQXlCRixNQUF6QixDQUEzQzs7QUFDQSxjQUFNcUIsT0FBTyxHQUFHQyxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFVBQW5CLEVBQStCLElBQS9CLENBQWhCOztBQUNBLGNBQU1JLE9BQU8sR0FBR0YsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixVQUFuQixFQUErQixJQUEvQixDQUFoQjs7QUFDQSxjQUFNSyxPQUFPLEdBQUdILGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsU0FBbkIsRUFBOEIsSUFBOUIsQ0FBaEI7O0FBQ0EsY0FBTU0sYUFBYSxHQUFHSixnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLGVBQW5CLEVBQW9DLElBQXBDLENBQXRCOztBQUNBQyxRQUFBQSxPQUFPLENBQUNpQyxZQUFSLEdBQXVCakMsT0FBTyxDQUFDa0MsYUFBL0I7QUFFQSxlQUFPeEQsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRWUsT0FGRjtBQUdKMkIsWUFBQUEsV0FBVyxFQUFFLENBSFQ7QUFJSkYsWUFBQUEsUUFBUSxFQUFFLENBSk47QUFLSnRCLFlBQUFBLE9BTEk7QUFNSkMsWUFBQUEsT0FOSTtBQU9KQyxZQUFBQTtBQVBJO0FBRE0sU0FBUCxDQUFQO0FBV0QsT0F0QkQsQ0FzQkUsT0FBT25CLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYywwQ0FBZCxFQUEwREYsR0FBMUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBN01xQjs7QUFBQSwyQ0ErTU4sT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUFFWSxVQUFBQSxTQUFTLEVBQUVELEVBQWI7QUFBaUJWLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRyxJQUEzQjtBQUFpQ3VELFVBQUFBLE9BQU8sRUFBRTtBQUExQyxTQUFmO0FBQ0EsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQVczRCxHQUFHLENBQUNHLElBQXJCLENBSEUsQ0FLRjs7QUFDQSxjQUFNO0FBQUV3QixVQUFBQSxPQUFGO0FBQVdDLFVBQUFBO0FBQVgsWUFBNkI1QixHQUFHLENBQUNtQyxLQUF2Qzs7QUFDQSxZQUFJUixPQUFPLElBQUlDLGFBQWYsRUFBOEI7QUFDNUIxQixVQUFBQSxNQUFNLENBQUMwRCxTQUFQLEdBQW1CakMsT0FBbkI7QUFDQXpCLFVBQUFBLE1BQU0sQ0FBQzJELGVBQVAsR0FBeUJqQyxhQUF6QjtBQUNEOztBQUVELGNBQU07QUFBRXhCLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTThELGNBQWMsR0FBRyxNQUFNMUQsaUJBQWlCLENBQzNDLFlBQVd1RCxJQUFJLEtBQUssVUFBVCxHQUFzQixnQkFBdEIsR0FBeUMsZUFBZ0IsRUFEekIsRUFFNUN6RCxNQUY0QyxDQUE5QztBQUlBLGNBQU07QUFBRTZELFVBQUFBLFFBQUY7QUFBWUMsVUFBQUE7QUFBWixZQUFvQkYsY0FBMUI7QUFDQSxlQUFPN0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUptQixZQUFBQSxPQUFPLEVBQUVxQyxRQUZMO0FBR0psRCxZQUFBQSxFQUFFLEVBQUVtRDtBQUhBO0FBRE0sU0FBUCxDQUFQO0FBT0QsT0F6QkQsQ0F5QkUsT0FBT3ZELEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw0Q0FBZCxFQUE0REYsR0FBNUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBbFBxQjs7QUFBQSx5Q0FvUFIsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3pDUyxNQUFBQSxPQUFPLENBQUNRLEdBQVIsQ0FBWSwyQkFBWjs7QUFDQSxVQUFJO0FBQ0YsY0FBTTtBQUFFNEIsVUFBQUEsSUFBRjtBQUFRWixVQUFBQSxJQUFSO0FBQWMrQixVQUFBQSxNQUFkO0FBQXNCQyxVQUFBQSxhQUF0QjtBQUFxQ0MsVUFBQUEsU0FBckM7QUFBZ0RDLFVBQUFBO0FBQWhELFlBQTBEcEUsR0FBRyxDQUFDbUMsS0FBcEU7QUFFQSxZQUFJRSxJQUFJLEdBQUc7QUFBRWdDLFVBQUFBLFNBQVMsRUFBRTtBQUFiLFNBQVg7O0FBQ0EsWUFBSUosTUFBTSxDQUFDSyxJQUFQLEVBQUosRUFBbUI7QUFDakI7QUFDQTtBQUNBO0FBQ0FqQyxVQUFBQSxJQUFJLEdBQUc7QUFDTGtDLFlBQUFBLFlBQVksRUFBRTtBQUNaQyxjQUFBQSxhQUFhLEVBQUUsY0FESDtBQUVaQyxjQUFBQSxnQkFBZ0IsRUFBRSxLQUZOO0FBR1p0QyxjQUFBQSxLQUFLLEVBQUcsSUFBRzhCLE1BQU0sQ0FBQ0ssSUFBUCxHQUFjSSxLQUFkLENBQW9CLEdBQXBCLEVBQXlCQyxJQUF6QixDQUE4QixLQUE5QixDQUFxQztBQUhwQztBQURULFdBQVA7QUFPRDs7QUFFRCxjQUFNQyxNQUFNLEdBQUcsRUFBZjs7QUFDQSxZQUFJUixLQUFLLEtBQUssS0FBZCxFQUFxQjtBQUNuQixnQkFBTVMsT0FBTyxHQUFHVCxLQUFLLEtBQUssU0FBMUI7QUFDQVEsVUFBQUEsTUFBTSxDQUFDRSxJQUFQLENBQVk7QUFBRXhDLFlBQUFBLElBQUksRUFBRTtBQUFFLGlDQUFtQnVDO0FBQXJCO0FBQVIsV0FBWjtBQUNBRCxVQUFBQSxNQUFNLENBQUNFLElBQVAsQ0FBWTtBQUFFeEMsWUFBQUEsSUFBSSxFQUFFO0FBQUUsa0NBQW9CdUM7QUFBdEI7QUFBUixXQUFaO0FBQ0Q7O0FBRUQsY0FBTUUsWUFBWSxHQUFHO0FBQUVDLFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQXJCO0FBQ0EsY0FBTUMsbUJBQW1CLEdBQUc7QUFBRS9DLFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQTVCOztBQUNBLFlBQUk2QyxZQUFZLENBQUNaLFNBQUQsQ0FBaEIsRUFBNkI7QUFDM0JjLFVBQUFBLG1CQUFtQixDQUFDQyxJQUFwQixHQUEyQixDQUFDO0FBQUUsYUFBQ0gsWUFBWSxDQUFDWixTQUFELENBQWIsR0FBMkJEO0FBQTdCLFdBQUQsQ0FBM0I7QUFDQWUsVUFBQUEsbUJBQW1CLENBQUMvQyxJQUFwQixHQUEyQlYsZ0JBQUUyRCxTQUFGLENBQVlqRCxJQUFaLEVBQWtCLElBQWxCLENBQTNCO0FBQ0ErQyxVQUFBQSxtQkFBbUIsQ0FBQ25DLElBQXBCLEdBQTJCdEIsZ0JBQUUyRCxTQUFGLENBQVlyQyxJQUFaLEVBQWtCLENBQWxCLENBQTNCO0FBQ0Q7O0FBRUQsY0FBTTVDLE1BQU0sR0FBRztBQUNiQyxVQUFBQSxJQUFJLEVBQUU7QUFDSmlGLFlBQUFBLG1CQUFtQixFQUFFLElBRGpCO0FBRUoxRCxZQUFBQSxPQUFPLEVBQUUsSUFGTDtBQUdKLGVBQUd1RCxtQkFIQztBQUlKOUMsWUFBQUEsS0FBSyxFQUFFO0FBQ0xDLGNBQUFBLElBQUksRUFBRTtBQUNKd0MsZ0JBQUFBO0FBREk7QUFERCxhQUpIO0FBU0pTLFlBQUFBLFlBQVksRUFBRTtBQUNaQyxjQUFBQSw2QkFBNkIsRUFBRTtBQUM3QkMsZ0JBQUFBLE1BQU0sRUFBRTtBQUNOQyxrQkFBQUEsSUFBSSxFQUFFO0FBREEsaUJBRHFCO0FBSTdCaEQsZ0JBQUFBLElBQUksRUFBRTtBQUNKaUQsa0JBQUFBLFdBQVcsRUFBRTtBQUNYL0Msb0JBQUFBLEtBQUssRUFBRTtBQUNMQyxzQkFBQUEsS0FBSyxFQUFFO0FBREY7QUFESTtBQURUO0FBSnVCO0FBRG5CO0FBVFY7QUFETyxTQUFmO0FBMkJBLGNBQU07QUFBRXZDLFVBQUFBLGlCQUFpQixFQUFFc0Y7QUFBckIsWUFBbUQsTUFBTSxLQUFLNUYsUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUEvRDtBQUNBLGNBQU1zQixXQUFXLEdBQUcsTUFBTW9FLHlCQUF5QixDQUFDLHNCQUFELEVBQXlCeEYsTUFBekIsQ0FBbkQ7O0FBRUEsY0FBTXlGLGFBQWEsR0FBR25FLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsa0JBQW5CLEVBQXVDLENBQXZDLENBQXRCOztBQUNBLGNBQU1zRSxxQkFBcUIsR0FBR3BFLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsV0FBbkIsRUFBZ0MsRUFBaEMsRUFBb0N1RSxHQUFwQyxDQUF5QzdFLE1BQUQsSUFBWTtBQUNoRixnQkFBTTtBQUNKZ0QsWUFBQUEsR0FBRyxFQUFFbkQsRUFERDtBQUVKa0QsWUFBQUEsUUFBUSxFQUFFckMsT0FGTjtBQUdKb0UsWUFBQUEsT0FBTyxFQUFFbkUsT0FITDtBQUlKb0UsWUFBQUEsYUFBYSxFQUFFbkUsYUFKWDtBQUtKb0UsWUFBQUEsT0FBTyxFQUFFekU7QUFMTCxjQU1GUCxNQU5KO0FBT0EsZ0JBQU07QUFBRWdFLFlBQUFBLElBQUY7QUFBUUgsWUFBQUE7QUFBUixjQUFvQnRELE9BQTFCO0FBQ0EsaUJBQU8sQ0FBQ1YsRUFBRCxFQUFLO0FBQUVBLFlBQUFBLEVBQUY7QUFBTWEsWUFBQUEsT0FBTjtBQUFlQyxZQUFBQSxPQUFmO0FBQXdCQyxZQUFBQSxhQUF4QjtBQUF1Q29ELFlBQUFBLElBQXZDO0FBQTZDSCxZQUFBQSxPQUE3QztBQUFzRHRELFlBQUFBO0FBQXRELFdBQUwsQ0FBUDtBQUNELFNBVjZCLEVBVTNCLEVBVjJCLENBQTlCOztBQVdBLGNBQU0wRSxVQUFVLEdBQUcsSUFBSUMsR0FBSixDQUFRTixxQkFBUixDQUFuQjtBQUNBLGNBQU1PLFVBQVUsR0FBRyxDQUFDLEdBQUdGLFVBQVUsQ0FBQ0csSUFBWCxFQUFKLENBQW5CO0FBQ0EsY0FBTUMsa0NBQWtDLEdBQUcsRUFBM0M7O0FBQ0E3RSx3QkFBRUMsR0FBRixDQUNFSCxXQURGLEVBRUUsZ0VBRkYsRUFHRSxFQUhGLEVBSUVnRixPQUpGLENBSVUsQ0FBQztBQUFFaEQsVUFBQUEsR0FBRjtBQUFPQyxVQUFBQTtBQUFQLFNBQUQsS0FBd0I7QUFDaEM4QyxVQUFBQSxrQ0FBa0MsQ0FBQy9DLEdBQUQsQ0FBbEMsR0FBMENDLFNBQTFDO0FBQ0QsU0FORDs7QUFRQSxjQUFNZ0QsYUFBYSxHQUFHLEVBQXRCO0FBQ0EsY0FBTUMsU0FBUyxHQUFHO0FBQ2hCQyxVQUFBQSxNQUFNLEVBQUUsUUFEUTtBQUVoQkMsVUFBQUEsWUFBWSxFQUFFLGNBRkU7QUFHaEJDLFVBQUFBLE1BQU0sRUFBRSxRQUhRO0FBSWhCQyxVQUFBQSxPQUFPLEVBQUUsU0FKTztBQUtoQkMsVUFBQUEsb0JBQW9CLEVBQUU7QUFMTixTQUFsQjs7QUFPQSxZQUFJTCxTQUFTLENBQUNyQyxTQUFELENBQWIsRUFBMEI7QUFDeEJvQyxVQUFBQSxhQUFhLENBQUNPLEtBQWQsR0FBc0I7QUFBRSxhQUFDTixTQUFTLENBQUNyQyxTQUFELENBQVYsR0FBd0JEO0FBQTFCLFdBQXRCO0FBQ0Q7O0FBQ0QsY0FBTXBDLFVBQVUsR0FBRztBQUNqQkMsVUFBQUEsS0FBSyxFQUFFQyxpQkFBTUMsVUFESTtBQUVqQjlCLFVBQUFBLElBQUksRUFBRTtBQUNKK0IsWUFBQUEsSUFBSSxFQUFFLENBREY7QUFFSkMsWUFBQUEsS0FBSyxFQUFFO0FBQUVPLGNBQUFBLEtBQUssRUFBRTtBQUFFSCxnQkFBQUEsVUFBVSxFQUFFNEQ7QUFBZDtBQUFULGFBRkg7QUFHSmQsWUFBQUEsWUFBWSxFQUFFO0FBQ1owQixjQUFBQSxnQkFBZ0IsRUFBRTtBQUNoQnJFLGdCQUFBQSxLQUFLLEVBQUU7QUFDTEMsa0JBQUFBLEtBQUssRUFBRSxZQURGO0FBRUwscUJBQUc0RCxhQUZFO0FBR0xyRSxrQkFBQUEsSUFBSSxFQUFFWSxJQUFJLEdBQUdaO0FBSFIsaUJBRFM7QUFNaEJtRCxnQkFBQUEsWUFBWSxFQUFFO0FBQ1pvQixrQkFBQUEsTUFBTSxFQUFFO0FBQUVPLG9CQUFBQSxNQUFNLEVBQUU7QUFBRTFFLHNCQUFBQSxJQUFJLEVBQUU7QUFBRThCLHdCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFSO0FBQVYsbUJBREk7QUFFWnNDLGtCQUFBQSxZQUFZLEVBQUU7QUFBRU0sb0JBQUFBLE1BQU0sRUFBRTtBQUFFMUUsc0JBQUFBLElBQUksRUFBRTtBQUFFOEIsd0JBQUFBLEtBQUssRUFBRTtBQUFUO0FBQVI7QUFBVixtQkFGRjtBQUdadUMsa0JBQUFBLE1BQU0sRUFBRTtBQUFFSyxvQkFBQUEsTUFBTSxFQUFFO0FBQUUxRSxzQkFBQUEsSUFBSSxFQUFFO0FBQUU4Qix3QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUjtBQUFWLG1CQUhJO0FBSVp3QyxrQkFBQUEsT0FBTyxFQUFFO0FBQ1BJLG9CQUFBQSxNQUFNLEVBQUU7QUFDTjVFLHNCQUFBQSxJQUFJLEVBQUU7QUFDSjRFLHdCQUFBQSxNQUFNLEVBQUU7QUFBRTFFLDBCQUFBQSxJQUFJLEVBQUU7QUFBRThCLDRCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFSLHlCQURKO0FBRUo2Qyx3QkFBQUEsUUFBUSxFQUFFO0FBQUVDLDBCQUFBQSxNQUFNLEVBQUU7QUFBRXZFLDRCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFWO0FBRk47QUFEQTtBQURELG1CQUpHO0FBWVp3RSxrQkFBQUEsc0JBQXNCLEVBQUU7QUFBRUMsb0JBQUFBLEdBQUcsRUFBRTtBQUFFekUsc0JBQUFBLEtBQUssRUFBRTtBQUFUO0FBQVAsbUJBWlo7QUFhWjBFLGtCQUFBQSxZQUFZLEVBQUU7QUFDWkMsb0JBQUFBLFFBQVEsRUFBRTtBQUNScEYsc0JBQUFBLElBQUksRUFBRSxDQURFO0FBRVJnRCxzQkFBQUEsSUFBSSxFQUFFLENBQUM7QUFBRXFDLHdCQUFBQSxVQUFVLEVBQUU7QUFBRVQsMEJBQUFBLEtBQUssRUFBRTtBQUFUO0FBQWQsdUJBQUQsQ0FGRTtBQUdSZCxzQkFBQUEsT0FBTyxFQUFFO0FBQ1B3Qix3QkFBQUEsUUFBUSxFQUFFLENBQUMsd0JBQUQsRUFBMkIsY0FBM0I7QUFESDtBQUhEO0FBREU7QUFiRjtBQU5FO0FBRE47QUFIVjtBQUZXLFNBQW5CO0FBd0NBLGNBQU07QUFBRXBILFVBQUFBO0FBQUYsWUFBd0IsS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUE5QjtBQUNBLGNBQU15SCxjQUFjLEdBQUcsTUFBTXJILGlCQUFpQixDQUFDLHNCQUFELEVBQXlCMEIsVUFBekIsQ0FBOUM7O0FBQ0EsY0FBTTRGLE9BQU8sR0FBR2xHLGdCQUFFQyxHQUFGLENBQU1nRyxjQUFOLEVBQXNCLHVDQUF0QixFQUErRCxFQUEvRCxFQUFtRTVCLEdBQW5FLENBQ2I4QixNQUFELElBQVk7QUFDVixnQkFBTTtBQUNKckUsWUFBQUEsR0FBRyxFQUFFekMsRUFERDtBQUVKc0csWUFBQUEsc0JBQXNCLEVBQUU7QUFBRVMsY0FBQUEsS0FBSyxFQUFFZjtBQUFULGFBRnBCO0FBR0pELFlBQUFBLE9BQU8sRUFBRTtBQUFFckQsY0FBQUEsU0FBUyxFQUFFcUQ7QUFBYixhQUhMO0FBSUpGLFlBQUFBLFlBQVksRUFBRTtBQUFFbkQsY0FBQUEsU0FBUyxFQUFFbUQ7QUFBYixhQUpWO0FBS0pELFlBQUFBLE1BQU0sRUFBRTtBQUFFbEQsY0FBQUEsU0FBUyxFQUFFa0Q7QUFBYixhQUxKO0FBTUpFLFlBQUFBLE1BQU0sRUFBRTtBQUFFcEQsY0FBQUEsU0FBUyxFQUFFb0Q7QUFBYixhQU5KO0FBT0pVLFlBQUFBLFlBQVksRUFBRTtBQUNaUSxjQUFBQSxJQUFJLEVBQUU7QUFDSkEsZ0JBQUFBLElBQUksRUFBRSxDQUNKO0FBQ0U3QixrQkFBQUEsT0FBTyxFQUFFO0FBQUU4QixvQkFBQUEsWUFBWSxFQUFFQztBQUFoQjtBQURYLGlCQURJO0FBREY7QUFETTtBQVBWLGNBZ0JGSixNQWhCSjtBQWlCQSxnQkFBTXBHLE9BQU8sR0FBRzBFLFVBQVUsQ0FBQ3hFLEdBQVgsQ0FBZVosRUFBZixDQUFoQjtBQUNBb0YsVUFBQUEsVUFBVSxDQUFDK0IsTUFBWCxDQUFrQm5ILEVBQWxCO0FBQ0EsaUJBQU8sRUFDTCxHQUFHVSxPQURFO0FBRUxWLFlBQUFBLEVBRks7QUFHTGdHLFlBQUFBLG9CQUhLO0FBSUxELFlBQUFBLE9BSks7QUFLTG1CLFlBQUFBLFdBTEs7QUFNTHJCLFlBQUFBLFlBTks7QUFPTEQsWUFBQUEsTUFQSztBQVFMRSxZQUFBQSxNQVJLO0FBU0xzQixZQUFBQSxXQUFXLEVBQUVDLElBQUksQ0FBQ0MsR0FBTCxFQVRSO0FBVUxDLFlBQUFBLDZCQUE2QixFQUFFL0Isa0NBQWtDLENBQUN4RixFQUFELENBQWxDLElBQTBDO0FBVnBFLFdBQVA7QUFZRCxTQWpDYSxDQUFoQjs7QUFvQ0EsY0FBTXdILGNBQWMsR0FBRyxDQUFDLEdBQUdwQyxVQUFVLENBQUNxQyxNQUFYLEVBQUosRUFBeUJ6QyxHQUF6QixDQUE4QnRFLE9BQUQsS0FBYyxFQUNoRSxHQUFHQSxPQUQ2RDtBQUVoRXNGLFVBQUFBLG9CQUFvQixFQUFFLElBRjBDO0FBR2hFRCxVQUFBQSxPQUFPLEVBQUUsQ0FIdUQ7QUFJaEVILFVBQUFBLE1BQU0sRUFBRSxDQUp3RDtBQUtoRUMsVUFBQUEsWUFBWSxFQUFFLENBTGtEO0FBTWhFQyxVQUFBQSxNQUFNLEVBQUUsQ0FOd0Q7QUFPaEVvQixVQUFBQSxXQUFXLEVBQUUsSUFQbUQ7QUFRaEVFLFVBQUFBLFdBQVcsRUFBRUMsSUFBSSxDQUFDQyxHQUFMLEVBUm1EO0FBU2hFQyxVQUFBQSw2QkFBNkIsRUFBRS9CLGtDQUFrQyxDQUFDOUUsT0FBTyxDQUFDVixFQUFULENBQWxDLElBQWtEO0FBVGpCLFNBQWQsQ0FBN0IsQ0FBdkI7O0FBWUEsWUFBSTBILE9BQU8sR0FBRy9HLGdCQUFFZ0gsT0FBRixDQUFVZCxPQUFPLENBQUNlLE1BQVIsQ0FBZUosY0FBZixDQUFWLEVBQTBDLENBQUNsRSxTQUFELENBQTFDLEVBQXVELENBQUNELGFBQUQsQ0FBdkQsQ0FBZCxDQTFMRSxDQTJMRjtBQUNBO0FBQ0E7OztBQUNBLFlBQUksQ0FBQ2EsWUFBWSxDQUFDWixTQUFELENBQWpCLEVBQThCO0FBQzVCb0UsVUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUNHLEtBQVIsQ0FBYzVGLElBQWQsRUFBb0JBLElBQUksR0FBR1osSUFBM0IsQ0FBVjtBQUNEOztBQUVELGVBQU9qQyxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSm9JLFlBQUFBLFFBQVEsRUFBRUosT0FGTjtBQUdKNUMsWUFBQUE7QUFISTtBQURNLFNBQVAsQ0FBUDtBQU9ELE9Bek1ELENBeU1FLE9BQU9sRixHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMseUNBQWQsRUFBeURGLEdBQXpEOztBQUNBLFlBQUksbUNBQXFCQSxHQUFyQixDQUFKLEVBQStCO0FBQzdCLGlCQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFBRUksY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsY0FBQUEsSUFBSSxFQUFFO0FBQUVtRixnQkFBQUEsYUFBYSxFQUFFLENBQWpCO0FBQW9CZ0QsZ0JBQUFBLFFBQVEsRUFBRTtBQUE5QjtBQUFuQjtBQURNLFdBQVAsQ0FBUDtBQUdEOztBQUNELGVBQU8xSSxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBN2NxQjs7QUFBQSwrQ0ErY0YsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQy9DLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUNiWSxVQUFBQSxTQUFTLEVBQUVELEVBREU7QUFFYlYsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBRkcsU0FBZjtBQUlBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQTlCO0FBQ0EsY0FBTTRJLG1CQUFtQixHQUFHLE1BQU14SSxpQkFBaUIsQ0FBQyw0QkFBRCxFQUErQkYsTUFBL0IsQ0FBbkQ7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLENBQUNxSSxtQkFBbUIsQ0FBQ0MsTUFBcEIsQ0FBMkJDLE1BRDVCO0FBRUp0SSxZQUFBQSxJQUFJLEVBQUVvSTtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FkRCxDQWNFLE9BQU9uSSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsZ0RBQWQsRUFBZ0VGLEdBQWhFO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXZlcUI7O0FBQUEsNENBeWVMLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUM1QyxVQUFJO0FBQ0YsY0FBTTtBQUFFOEksVUFBQUEsTUFBTSxHQUFHO0FBQVgsWUFBc0IvSSxHQUFHLENBQUNtQyxLQUFoQztBQUNBLGNBQU1qQyxNQUFNLEdBQUc7QUFDYkMsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHLElBREc7QUFFYjRJLFVBQUFBO0FBRmEsU0FBZjtBQUlBLGNBQU07QUFBRTNJLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTWdKLGVBQWUsR0FBRyxNQUFNNUksaUJBQWlCLENBQUMseUJBQUQsRUFBNEJGLE1BQTVCLENBQS9DO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRXdJO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQWRELENBY0UsT0FBT3ZJLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw2Q0FBZCxFQUE2REYsR0FBN0Q7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBamdCcUI7O0FBQUEsNENBb2dCTCxPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDNUMsVUFBSTtBQUNGLGNBQU07QUFBRWtDLFVBQUFBLEtBQUY7QUFBU0osVUFBQUEsS0FBVDtBQUFnQkcsVUFBQUE7QUFBaEIsWUFBeUJsQyxHQUFHLENBQUNHLElBQW5DO0FBQ0EsY0FBTUQsTUFBTSxHQUFHO0FBQUU2QixVQUFBQSxLQUFGO0FBQVNHLFVBQUFBLElBQVQ7QUFBZS9CLFVBQUFBLElBQUksRUFBRWdDO0FBQXJCLFNBQWY7QUFFQXpCLFFBQUFBLE9BQU8sQ0FBQ1EsR0FBUixDQUFZLDBCQUFaO0FBQ0FSLFFBQUFBLE9BQU8sQ0FBQ1EsR0FBUixDQUFZQyxJQUFJLENBQUNDLFNBQUwsQ0FBZWxCLE1BQWYsQ0FBWjtBQUVBLGNBQU07QUFBRUUsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNdUksT0FBTyxHQUFHLE1BQU1uSSxpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QkYsTUFBekIsQ0FBdkM7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFK0g7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BZkQsQ0FlRSxPQUFPOUgsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDRDQUFkLEVBQTRERixHQUE1RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0E3aEJxQjs7QUFDcEIsU0FBS2QsUUFBTCxHQUFnQkEsUUFBaEI7QUFDRDs7QUFIaUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5cbmltcG9ydCB7IElOREVYIH0gZnJvbSAnLi4vLi4vdXRpbHMvY29uc3RhbnRzJztcbmltcG9ydCB7IGlzSW5kZXhOb3RGb3VuZEVycm9yIH0gZnJvbSAnLi91dGlscy9oZWxwZXJzJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9uaXRvclNlcnZpY2Uge1xuICBjb25zdHJ1Y3Rvcihlc0RyaXZlcikge1xuICAgIHRoaXMuZXNEcml2ZXIgPSBlc0RyaXZlcjtcbiAgfVxuXG4gIGNyZWF0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGFyYW1zID0geyBib2R5OiByZXEuYm9keSB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgY3JlYXRlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuY3JlYXRlTW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IGNyZWF0ZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gY3JlYXRlTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgY3JlYXRlV29ya2Zsb3cgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGFyYW1zID0geyBib2R5OiByZXEuYm9keSB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgY3JlYXRlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuY3JlYXRlV29ya2Zsb3cnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiBjcmVhdGVSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGNyZWF0ZVdvcmtmbG93OicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBkZWxldGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IG1vbml0b3JJZDogaWQgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmRlbGV0ZU1vbml0b3InLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogcmVzcG9uc2UucmVzdWx0ID09PSAnZGVsZXRlZCcsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBkZWxldGVNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBkZWxldGVXb3JrZmxvdyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgICAgY29uc3QgcGFyYW1zID0geyB3b3JrZmxvd0lkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZGVsZXRlV29ya2Zsb3cnLCBwYXJhbXMpO1xuICAgICAgY29uc29sZS5sb2coJ2RlbGV0ZSB3b3JrZmxvdyByZXNwb25zZSBeKl4qXipeKl4qJyk7XG4gICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShyZXNwb25zZSkpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogcmVzcG9uc2UucmVzdWx0ID09PSAnZGVsZXRlZCcgfHwgcmVzcG9uc2UucmVzdWx0ID09PSB1bmRlZmluZWQsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBkZWxldGVXb3JrZmxvdzonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZ2V0TW9uaXRvciA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIGNvbnNvbGUubG9nKCcqKioqKiogR0VUIE1PTklUT1IgKioqKionKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZ2V0UmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICBjb25zb2xlLmxvZygnR2V0IG1vbml0b3IgY29tcGxldGUgcmVzcG9uc2UgXl5eXl5eXl5eJyk7XG4gICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShnZXRSZXNwb25zZSkpO1xuICAgICAgbGV0IG1vbml0b3IgPSBfLmdldChnZXRSZXNwb25zZSwgJ21vbml0b3InLCBudWxsKTtcbiAgICAgIGNvbnN0IHZlcnNpb24gPSBfLmdldChnZXRSZXNwb25zZSwgJ192ZXJzaW9uJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlNlcU5vID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfc2VxX25vJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlByaW1hcnlUZXJtID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfcHJpbWFyeV90ZXJtJywgbnVsbCk7XG4gICAgICBjb25zdCBhc3NvY2lhdGVkX3dvcmtmbG93cyA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnYXNzb2NpYXRlZF93b3JrZmxvd3MnLCBudWxsKTtcbiAgICAgIGlmIChtb25pdG9yKSB7XG4gICAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgICAgY29uc3QgYWdnc1BhcmFtcyA9IHtcbiAgICAgICAgICBpbmRleDogSU5ERVguQUxMX0FMRVJUUyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgIG11c3Q6IHtcbiAgICAgICAgICAgICAgICAgIHRlcm06IHtcbiAgICAgICAgICAgICAgICAgICAgbW9uaXRvcl9pZDogaWQsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgICBhY3RpdmVfY291bnQ6IHtcbiAgICAgICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICAgICAgZmllbGQ6ICdzdGF0ZScsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgJzI0X2hvdXJfY291bnQnOiB7XG4gICAgICAgICAgICAgICAgZGF0ZV9yYW5nZToge1xuICAgICAgICAgICAgICAgICAgZmllbGQ6ICdzdGFydF90aW1lJyxcbiAgICAgICAgICAgICAgICAgIHJhbmdlczogW3sgZnJvbTogJ25vdy0yNGgvaCcgfV0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgc2VhcmNoUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBhZ2dzUGFyYW1zKTtcbiAgICAgICAgY29uc3QgZGF5Q291bnQgPSBfLmdldChzZWFyY2hSZXNwb25zZSwgJ2FnZ3JlZ2F0aW9ucy4yNF9ob3VyX2NvdW50LmJ1Y2tldHMuMC5kb2NfY291bnQnLCAwKTtcbiAgICAgICAgY29uc3QgYWN0aXZlQnVja2V0cyA9IF8uZ2V0KHNlYXJjaFJlc3BvbnNlLCAnYWdncmVnYXRpb25zLmFjdGl2ZV9jb3VudC5idWNrZXRzJywgW10pO1xuICAgICAgICBjb25zdCBhY3RpdmVDb3VudCA9IGFjdGl2ZUJ1Y2tldHMucmVkdWNlKFxuICAgICAgICAgIChhY2MsIGN1cnIpID0+IChjdXJyLmtleSA9PT0gJ0FDVElWRScgPyBjdXJyLmRvY19jb3VudCA6IGFjYyksXG4gICAgICAgICAgMFxuICAgICAgICApO1xuICAgICAgICBpZiAoYXNzb2NpYXRlZF93b3JrZmxvd3MpIHtcbiAgICAgICAgICBtb25pdG9yID0ge1xuICAgICAgICAgICAgLi4ubW9uaXRvcixcbiAgICAgICAgICAgIGFzc29jaWF0ZWRfd29ya2Zsb3dzLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBvazogdHJ1ZSwgcmVzcDogbW9uaXRvciwgYWN0aXZlQ291bnQsIGRheUNvdW50LCB2ZXJzaW9uLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGdldE1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldFdvcmtmbG93ID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc29sZS5sb2coJyoqKioqKiBHRVQgV09SS0ZMT1cgKioqKionKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZ2V0UmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0V29ya2Zsb3cnLCBwYXJhbXMpO1xuICAgICAgY29uc3QgbW9uaXRvciA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnd29ya2Zsb3cnLCBudWxsKTtcbiAgICAgIGNvbnN0IHZlcnNpb24gPSBfLmdldChnZXRSZXNwb25zZSwgJ192ZXJzaW9uJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlNlcU5vID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfc2VxX25vJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlByaW1hcnlUZXJtID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfcHJpbWFyeV90ZXJtJywgbnVsbCk7XG4gICAgICBtb25pdG9yLm1vbml0b3JfdHlwZSA9IG1vbml0b3Iud29ya2Zsb3dfdHlwZTtcblxuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiBtb25pdG9yLFxuICAgICAgICAgIGFjdGl2ZUNvdW50OiAwLFxuICAgICAgICAgIGRheUNvdW50OiAwLFxuICAgICAgICAgIHZlcnNpb24sXG4gICAgICAgICAgaWZTZXFObyxcbiAgICAgICAgICBpZlByaW1hcnlUZXJtLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZ2V0V29ya2Zsb3c6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIHVwZGF0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCwgYm9keTogcmVxLmJvZHksIHJlZnJlc2g6ICd3YWl0X2ZvcicgfTtcbiAgICAgIGNvbnN0IHsgdHlwZSB9ID0gcmVxLmJvZHk7XG5cbiAgICAgIC8vIFRPRE8gRFJBRlQ6IEFyZSB3ZSBzdXJlIHdlIG5lZWQgdG8gaW5jbHVkZSBpZlNlcU5vIGFuZCBpZlByaW1hcnlUZXJtIGZyb20gdGhlIFVJIHNpZGUgd2hlbiB1cGRhdGluZyBtb25pdG9ycz9cbiAgICAgIGNvbnN0IHsgaWZTZXFObywgaWZQcmltYXJ5VGVybSB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgaWYgKGlmU2VxTm8gJiYgaWZQcmltYXJ5VGVybSkge1xuICAgICAgICBwYXJhbXMuaWZfc2VxX25vID0gaWZTZXFObztcbiAgICAgICAgcGFyYW1zLmlmX3ByaW1hcnlfdGVybSA9IGlmUHJpbWFyeVRlcm07XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IHVwZGF0ZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoXG4gICAgICAgIGBhbGVydGluZy4ke3R5cGUgPT09ICd3b3JrZmxvdycgPyAndXBkYXRlV29ya2Zsb3cnIDogJ3VwZGF0ZU1vbml0b3InfWAsXG4gICAgICAgIHBhcmFtc1xuICAgICAgKTtcbiAgICAgIGNvbnN0IHsgX3ZlcnNpb24sIF9pZCB9ID0gdXBkYXRlUmVzcG9uc2U7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHZlcnNpb246IF92ZXJzaW9uLFxuICAgICAgICAgIGlkOiBfaWQsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSB1cGRhdGVNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBnZXRNb25pdG9ycyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIGNvbnNvbGUubG9nKCcqKioqKiogR0VUIE1PTklUT1JTICoqKioqJyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZnJvbSwgc2l6ZSwgc2VhcmNoLCBzb3J0RGlyZWN0aW9uLCBzb3J0RmllbGQsIHN0YXRlIH0gPSByZXEucXVlcnk7XG5cbiAgICAgIGxldCBtdXN0ID0geyBtYXRjaF9hbGw6IHt9IH07XG4gICAgICBpZiAoc2VhcmNoLnRyaW0oKSkge1xuICAgICAgICAvLyBUaGlzIGlzIGFuIGV4cGVuc2l2ZSB3aWxkY2FyZCBxdWVyeSB0byBtYXRjaCBtb25pdG9yIG5hbWVzIHN1Y2ggYXM6IFwiVGhpcyBpcyBhIGxvbmcgbW9uaXRvciBuYW1lXCJcbiAgICAgICAgLy8gc2VhcmNoIHF1ZXJ5ID0+IFwibG9uZyBtb25pdFwiXG4gICAgICAgIC8vIFRoaXMgaXMgYWNjZXB0YWJsZSBiZWNhdXNlIHdlIHdpbGwgbmV2ZXIgYWxsb3cgbW9yZSB0aGFuIDEsMDAwIG1vbml0b3JzXG4gICAgICAgIG11c3QgPSB7XG4gICAgICAgICAgcXVlcnlfc3RyaW5nOiB7XG4gICAgICAgICAgICBkZWZhdWx0X2ZpZWxkOiAnbW9uaXRvci5uYW1lJyxcbiAgICAgICAgICAgIGRlZmF1bHRfb3BlcmF0b3I6ICdBTkQnLFxuICAgICAgICAgICAgcXVlcnk6IGAqJHtzZWFyY2gudHJpbSgpLnNwbGl0KCcgJykuam9pbignKiAqJyl9KmAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgc2hvdWxkID0gW107XG4gICAgICBpZiAoc3RhdGUgIT09ICdhbGwnKSB7XG4gICAgICAgIGNvbnN0IGVuYWJsZWQgPSBzdGF0ZSA9PT0gJ2VuYWJsZWQnO1xuICAgICAgICBzaG91bGQucHVzaCh7IHRlcm06IHsgJ21vbml0b3IuZW5hYmxlZCc6IGVuYWJsZWQgfSB9KTtcbiAgICAgICAgc2hvdWxkLnB1c2goeyB0ZXJtOiB7ICd3b3JrZmxvdy5lbmFibGVkJzogZW5hYmxlZCB9IH0pO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBtb25pdG9yU29ydHMgPSB7IG5hbWU6ICdtb25pdG9yLm5hbWUua2V5d29yZCcgfTtcbiAgICAgIGNvbnN0IG1vbml0b3JTb3J0UGFnZURhdGEgPSB7IHNpemU6IDEwMDAgfTtcbiAgICAgIGlmIChtb25pdG9yU29ydHNbc29ydEZpZWxkXSkge1xuICAgICAgICBtb25pdG9yU29ydFBhZ2VEYXRhLnNvcnQgPSBbeyBbbW9uaXRvclNvcnRzW3NvcnRGaWVsZF1dOiBzb3J0RGlyZWN0aW9uIH1dO1xuICAgICAgICBtb25pdG9yU29ydFBhZ2VEYXRhLnNpemUgPSBfLmRlZmF1bHRUbyhzaXplLCAxMDAwKTtcbiAgICAgICAgbW9uaXRvclNvcnRQYWdlRGF0YS5mcm9tID0gXy5kZWZhdWx0VG8oZnJvbSwgMCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHNlcV9ub19wcmltYXJ5X3Rlcm06IHRydWUsXG4gICAgICAgICAgdmVyc2lvbjogdHJ1ZSxcbiAgICAgICAgICAuLi5tb25pdG9yU29ydFBhZ2VEYXRhLFxuICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgIHNob3VsZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBhZ2dyZWdhdGlvbnM6IHtcbiAgICAgICAgICAgIGFzc29jaWF0ZWRfY29tcG9zaXRlX21vbml0b3JzOiB7XG4gICAgICAgICAgICAgIG5lc3RlZDoge1xuICAgICAgICAgICAgICAgIHBhdGg6ICd3b3JrZmxvdy5pbnB1dHMuY29tcG9zaXRlX2lucHV0LnNlcXVlbmNlLmRlbGVnYXRlcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGFnZ3M6IHtcbiAgICAgICAgICAgICAgICBtb25pdG9yX2lkczoge1xuICAgICAgICAgICAgICAgICAgdGVybXM6IHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQ6ICd3b3JrZmxvdy5pbnB1dHMuY29tcG9zaXRlX2lucHV0LnNlcXVlbmNlLmRlbGVnYXRlcy5tb25pdG9yX2lkJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGFsZXJ0aW5nQ2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGdldFJlc3BvbnNlID0gYXdhaXQgYWxlcnRpbmdDYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBwYXJhbXMpO1xuXG4gICAgICBjb25zdCB0b3RhbE1vbml0b3JzID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdoaXRzLnRvdGFsLnZhbHVlJywgMCk7XG4gICAgICBjb25zdCBtb25pdG9yS2V5VmFsdWVUdXBsZXMgPSBfLmdldChnZXRSZXNwb25zZSwgJ2hpdHMuaGl0cycsIFtdKS5tYXAoKHJlc3VsdCkgPT4ge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgICBfdmVyc2lvbjogdmVyc2lvbixcbiAgICAgICAgICBfc2VxX25vOiBpZlNlcU5vLFxuICAgICAgICAgIF9wcmltYXJ5X3Rlcm06IGlmUHJpbWFyeVRlcm0sXG4gICAgICAgICAgX3NvdXJjZTogbW9uaXRvcixcbiAgICAgICAgfSA9IHJlc3VsdDtcbiAgICAgICAgY29uc3QgeyBuYW1lLCBlbmFibGVkIH0gPSBtb25pdG9yO1xuICAgICAgICByZXR1cm4gW2lkLCB7IGlkLCB2ZXJzaW9uLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtLCBuYW1lLCBlbmFibGVkLCBtb25pdG9yIH1dO1xuICAgICAgfSwge30pO1xuICAgICAgY29uc3QgbW9uaXRvck1hcCA9IG5ldyBNYXAobW9uaXRvcktleVZhbHVlVHVwbGVzKTtcbiAgICAgIGNvbnN0IG1vbml0b3JJZHMgPSBbLi4ubW9uaXRvck1hcC5rZXlzKCldO1xuICAgICAgY29uc3QgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcCA9IHt9O1xuICAgICAgXy5nZXQoXG4gICAgICAgIGdldFJlc3BvbnNlLFxuICAgICAgICAnYWdncmVnYXRpb25zLmFzc29jaWF0ZWRfY29tcG9zaXRlX21vbml0b3JzLm1vbml0b3JfaWRzLmJ1Y2tldHMnLFxuICAgICAgICBbXVxuICAgICAgKS5mb3JFYWNoKCh7IGtleSwgZG9jX2NvdW50IH0pID0+IHtcbiAgICAgICAgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcFtrZXldID0gZG9jX2NvdW50O1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IGFnZ3NPcmRlckRhdGEgPSB7fTtcbiAgICAgIGNvbnN0IGFnZ3NTb3J0cyA9IHtcbiAgICAgICAgYWN0aXZlOiAnYWN0aXZlJyxcbiAgICAgICAgYWNrbm93bGVkZ2VkOiAnYWNrbm93bGVkZ2VkJyxcbiAgICAgICAgZXJyb3JzOiAnZXJyb3JzJyxcbiAgICAgICAgaWdub3JlZDogJ2lnbm9yZWQnLFxuICAgICAgICBsYXN0Tm90aWZpY2F0aW9uVGltZTogJ2xhc3Rfbm90aWZpY2F0aW9uX3RpbWUnLFxuICAgICAgfTtcbiAgICAgIGlmIChhZ2dzU29ydHNbc29ydEZpZWxkXSkge1xuICAgICAgICBhZ2dzT3JkZXJEYXRhLm9yZGVyID0geyBbYWdnc1NvcnRzW3NvcnRGaWVsZF1dOiBzb3J0RGlyZWN0aW9uIH07XG4gICAgICB9XG4gICAgICBjb25zdCBhZ2dzUGFyYW1zID0ge1xuICAgICAgICBpbmRleDogSU5ERVguQUxMX0FMRVJUUyxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgcXVlcnk6IHsgdGVybXM6IHsgbW9uaXRvcl9pZDogbW9uaXRvcklkcyB9IH0sXG4gICAgICAgICAgYWdncmVnYXRpb25zOiB7XG4gICAgICAgICAgICB1bmlxX21vbml0b3JfaWRzOiB7XG4gICAgICAgICAgICAgIHRlcm1zOiB7XG4gICAgICAgICAgICAgICAgZmllbGQ6ICdtb25pdG9yX2lkJyxcbiAgICAgICAgICAgICAgICAuLi5hZ2dzT3JkZXJEYXRhLFxuICAgICAgICAgICAgICAgIHNpemU6IGZyb20gKyBzaXplLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBhZ2dyZWdhdGlvbnM6IHtcbiAgICAgICAgICAgICAgICBhY3RpdmU6IHsgZmlsdGVyOiB7IHRlcm06IHsgc3RhdGU6ICdBQ1RJVkUnIH0gfSB9LFxuICAgICAgICAgICAgICAgIGFja25vd2xlZGdlZDogeyBmaWx0ZXI6IHsgdGVybTogeyBzdGF0ZTogJ0FDS05PV0xFREdFRCcgfSB9IH0sXG4gICAgICAgICAgICAgICAgZXJyb3JzOiB7IGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnRVJST1InIH0gfSB9LFxuICAgICAgICAgICAgICAgIGlnbm9yZWQ6IHtcbiAgICAgICAgICAgICAgICAgIGZpbHRlcjoge1xuICAgICAgICAgICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyOiB7IHRlcm06IHsgc3RhdGU6ICdDT01QTEVURUQnIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICBtdXN0X25vdDogeyBleGlzdHM6IHsgZmllbGQ6ICdhY2tub3dsZWRnZWRfdGltZScgfSB9LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGxhc3Rfbm90aWZpY2F0aW9uX3RpbWU6IHsgbWF4OiB7IGZpZWxkOiAnbGFzdF9ub3RpZmljYXRpb25fdGltZScgfSB9LFxuICAgICAgICAgICAgICAgIGxhdGVzdF9hbGVydDoge1xuICAgICAgICAgICAgICAgICAgdG9wX2hpdHM6IHtcbiAgICAgICAgICAgICAgICAgICAgc2l6ZTogMSxcbiAgICAgICAgICAgICAgICAgICAgc29ydDogW3sgc3RhcnRfdGltZTogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICAgICAgICAgICAgICAgIF9zb3VyY2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICBpbmNsdWRlczogWydsYXN0X25vdGlmaWNhdGlvbl90aW1lJywgJ3RyaWdnZXJfbmFtZSddLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfTtcblxuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZXNBZ2dzUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBhZ2dzUGFyYW1zKTtcbiAgICAgIGNvbnN0IGJ1Y2tldHMgPSBfLmdldChlc0FnZ3NSZXNwb25zZSwgJ2FnZ3JlZ2F0aW9ucy51bmlxX21vbml0b3JfaWRzLmJ1Y2tldHMnLCBbXSkubWFwKFxuICAgICAgICAoYnVja2V0KSA9PiB7XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAga2V5OiBpZCxcbiAgICAgICAgICAgIGxhc3Rfbm90aWZpY2F0aW9uX3RpbWU6IHsgdmFsdWU6IGxhc3ROb3RpZmljYXRpb25UaW1lIH0sXG4gICAgICAgICAgICBpZ25vcmVkOiB7IGRvY19jb3VudDogaWdub3JlZCB9LFxuICAgICAgICAgICAgYWNrbm93bGVkZ2VkOiB7IGRvY19jb3VudDogYWNrbm93bGVkZ2VkIH0sXG4gICAgICAgICAgICBhY3RpdmU6IHsgZG9jX2NvdW50OiBhY3RpdmUgfSxcbiAgICAgICAgICAgIGVycm9yczogeyBkb2NfY291bnQ6IGVycm9ycyB9LFxuICAgICAgICAgICAgbGF0ZXN0X2FsZXJ0OiB7XG4gICAgICAgICAgICAgIGhpdHM6IHtcbiAgICAgICAgICAgICAgICBoaXRzOiBbXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9zb3VyY2U6IHsgdHJpZ2dlcl9uYW1lOiBsYXRlc3RBbGVydCB9LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9ID0gYnVja2V0O1xuICAgICAgICAgIGNvbnN0IG1vbml0b3IgPSBtb25pdG9yTWFwLmdldChpZCk7XG4gICAgICAgICAgbW9uaXRvck1hcC5kZWxldGUoaWQpO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5tb25pdG9yLFxuICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICBsYXN0Tm90aWZpY2F0aW9uVGltZSxcbiAgICAgICAgICAgIGlnbm9yZWQsXG4gICAgICAgICAgICBsYXRlc3RBbGVydCxcbiAgICAgICAgICAgIGFja25vd2xlZGdlZCxcbiAgICAgICAgICAgIGFjdGl2ZSxcbiAgICAgICAgICAgIGVycm9ycyxcbiAgICAgICAgICAgIGN1cnJlbnRUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDbnQ6IGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ291bnRNYXBbaWRdIHx8IDAsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgKTtcblxuICAgICAgY29uc3QgdW51c2VkTW9uaXRvcnMgPSBbLi4ubW9uaXRvck1hcC52YWx1ZXMoKV0ubWFwKChtb25pdG9yKSA9PiAoe1xuICAgICAgICAuLi5tb25pdG9yLFxuICAgICAgICBsYXN0Tm90aWZpY2F0aW9uVGltZTogbnVsbCxcbiAgICAgICAgaWdub3JlZDogMCxcbiAgICAgICAgYWN0aXZlOiAwLFxuICAgICAgICBhY2tub3dsZWRnZWQ6IDAsXG4gICAgICAgIGVycm9yczogMCxcbiAgICAgICAgbGF0ZXN0QWxlcnQ6ICctLScsXG4gICAgICAgIGN1cnJlbnRUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgICBhc3NvY2lhdGVkQ29tcG9zaXRlTW9uaXRvckNudDogYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcFttb25pdG9yLmlkXSB8fCAwLFxuICAgICAgfSkpO1xuXG4gICAgICBsZXQgcmVzdWx0cyA9IF8ub3JkZXJCeShidWNrZXRzLmNvbmNhdCh1bnVzZWRNb25pdG9ycyksIFtzb3J0RmllbGRdLCBbc29ydERpcmVjdGlvbl0pO1xuICAgICAgLy8gSWYgd2Ugc29ydGVkIG9uIG1vbml0b3IgbmFtZSB0aGVuIHdlIGFscmVhZHkgYXBwbGllZCBmcm9tL3NpemUgdG8gdGhlIGZpcnN0IHF1ZXJ5IHRvIGxpbWl0IHdoYXQgd2UncmUgYWdncmVnYXRpbmcgb3ZlclxuICAgICAgLy8gVGhlcmVmb3JlIHdlIGRvIG5vdCBuZWVkIHRvIGFwcGx5IGZyb20vc2l6ZSB0byB0aGlzIHJlc3VsdCBzZXRcbiAgICAgIC8vIElmIHdlIHNvcnRlZCBvbiBhZ2dyZWdhdGlvbnMsIHRoZW4gdGhpcyBpcyBvdXIgaW4gbWVtb3J5IHBhZ2luYXRpb25cbiAgICAgIGlmICghbW9uaXRvclNvcnRzW3NvcnRGaWVsZF0pIHtcbiAgICAgICAgcmVzdWx0cyA9IHJlc3VsdHMuc2xpY2UoZnJvbSwgZnJvbSArIHNpemUpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIG1vbml0b3JzOiByZXN1bHRzLFxuICAgICAgICAgIHRvdGFsTW9uaXRvcnMsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBnZXRNb25pdG9ycycsIGVycik7XG4gICAgICBpZiAoaXNJbmRleE5vdEZvdW5kRXJyb3IoZXJyKSkge1xuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7IG9rOiBmYWxzZSwgcmVzcDogeyB0b3RhbE1vbml0b3JzOiAwLCBtb25pdG9yczogW10gfSB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGFja25vd2xlZGdlQWxlcnRzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIG1vbml0b3JJZDogaWQsXG4gICAgICAgIGJvZHk6IHJlcS5ib2R5LFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGFja25vd2xlZGdlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuYWNrbm93bGVkZ2VBbGVydHMnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogIWFja25vd2xlZGdlUmVzcG9uc2UuZmFpbGVkLmxlbmd0aCxcbiAgICAgICAgICByZXNwOiBhY2tub3dsZWRnZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gYWNrbm93bGVkZ2VBbGVydHM6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGV4ZWN1dGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZHJ5cnVuID0gJ3RydWUnIH0gPSByZXEucXVlcnk7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIGJvZHk6IHJlcS5ib2R5LFxuICAgICAgICBkcnlydW4sXG4gICAgICB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZXhlY3V0ZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmV4ZWN1dGVNb25pdG9yJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogZXhlY3V0ZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZXhlY3V0ZU1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIC8vVE9ETzogVGhpcyBpcyB0ZW1wb3JhcmlseSBhIHBhc3MgdGhyb3VnaCBjYWxsIHdoaWNoIG5lZWRzIHRvIGJlIGRlcHJlY2F0ZWRcbiAgc2VhcmNoTW9uaXRvcnMgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBxdWVyeSwgaW5kZXgsIHNpemUgfSA9IHJlcS5ib2R5O1xuICAgICAgY29uc3QgcGFyYW1zID0geyBpbmRleCwgc2l6ZSwgYm9keTogcXVlcnkgfTtcblxuICAgICAgY29uc29sZS5sb2coJ1NlYXJjaCBtb25pdG9ycyAqKioqKioqICcpO1xuICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocGFyYW1zKSk7XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiByZXN1bHRzLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gc2VhcmNoTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG59XG4iXX0=