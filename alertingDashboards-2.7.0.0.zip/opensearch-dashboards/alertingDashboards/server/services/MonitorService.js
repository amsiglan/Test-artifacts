"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _lodash = _interopRequireDefault(require("lodash"));

var _constants = require("../../utils/constants");

var _helpers = require("./utils/helpers");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class MonitorService {
  constructor(esDriver) {
    _defineProperty(this, "createMonitor", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "createWorkflow", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createWorkflow', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteMonitor', params);
        return res.ok({
          body: {
            ok: response.result === 'deleted'
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitor", async (context, req, res) => {
      console.log('****** GET MONITOR *****');

      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getMonitor', params);
        console.log('Get monitor complete response ^^^^^^^^^');
        console.log(JSON.stringify(getResponse));

        let monitor = _lodash.default.get(getResponse, 'monitor', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        const associated_workflows = _lodash.default.get(getResponse, 'associated_workflows', null);

        if (monitor) {
          const {
            callAsCurrentUser
          } = this.esDriver.asScoped(req);
          const aggsParams = {
            index: _constants.INDEX.ALL_ALERTS,
            body: {
              size: 0,
              query: {
                bool: {
                  must: {
                    term: {
                      monitor_id: id
                    }
                  }
                }
              },
              aggs: {
                active_count: {
                  terms: {
                    field: 'state'
                  }
                },
                '24_hour_count': {
                  date_range: {
                    field: 'start_time',
                    ranges: [{
                      from: 'now-24h/h'
                    }]
                  }
                }
              }
            }
          };
          const searchResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

          const dayCount = _lodash.default.get(searchResponse, 'aggregations.24_hour_count.buckets.0.doc_count', 0);

          const activeBuckets = _lodash.default.get(searchResponse, 'aggregations.active_count.buckets', []);

          const activeCount = activeBuckets.reduce((acc, curr) => curr.key === 'ACTIVE' ? curr.doc_count : acc, 0);

          if (associated_workflows) {
            monitor = { ...monitor,
              associated_workflows
            };
          }

          return res.ok({
            body: {
              ok: true,
              resp: monitor,
              activeCount,
              dayCount,
              version,
              ifSeqNo,
              ifPrimaryTerm
            }
          });
        } else {
          return res.ok({
            body: {
              ok: false
            }
          });
        }
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getWorkflow", async (context, req, res) => {
      console.log('****** GET WORKFLOW *****');

      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getWorkflow', params);

        const monitor = _lodash.default.get(getResponse, 'workflow', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        monitor.monitor_type = monitor.workflow_type;
        return res.ok({
          body: {
            ok: true,
            resp: monitor,
            activeCount: 0,
            dayCount: 0,
            version,
            ifSeqNo,
            ifPrimaryTerm
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "updateMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body,
          refresh: 'wait_for'
        };
        const {
          type
        } = req.body; // TODO DRAFT: Are we sure we need to include ifSeqNo and ifPrimaryTerm from the UI side when updating monitors?

        const {
          ifSeqNo,
          ifPrimaryTerm
        } = req.query;

        if (ifSeqNo && ifPrimaryTerm) {
          params.if_seq_no = ifSeqNo;
          params.if_primary_term = ifPrimaryTerm;
        }

        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const updateResponse = await callAsCurrentUser(`alerting.${type === 'workflow' ? 'updateWorkflow' : 'updateMonitor'}`, params);
        const {
          _version,
          _id
        } = updateResponse;
        return res.ok({
          body: {
            ok: true,
            version: _version,
            id: _id
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - updateMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitors", async (context, req, res) => {
      console.log('****** GET MONITORS *****');

      try {
        const {
          from,
          size,
          search,
          sortDirection,
          sortField,
          state
        } = req.query;
        let must = {
          match_all: {}
        };

        if (search.trim()) {
          // This is an expensive wildcard query to match monitor names such as: "This is a long monitor name"
          // search query => "long monit"
          // This is acceptable because we will never allow more than 1,000 monitors
          must = {
            query_string: {
              default_field: 'monitor.name',
              default_operator: 'AND',
              query: `*${search.trim().split(' ').join('* *')}*`
            }
          };
        }

        const should = [];

        if (state !== 'all') {
          const enabled = state === 'enabled';
          should.push({
            term: {
              'monitor.enabled': enabled
            }
          });
          should.push({
            term: {
              'workflow.enabled': enabled
            }
          });
        }

        const monitorSorts = {
          name: 'monitor.name.keyword'
        };
        const monitorSortPageData = {
          size: 1000
        };

        if (monitorSorts[sortField]) {
          monitorSortPageData.sort = [{
            [monitorSorts[sortField]]: sortDirection
          }];
          monitorSortPageData.size = _lodash.default.defaultTo(size, 1000);
          monitorSortPageData.from = _lodash.default.defaultTo(from, 0);
        }

        const params = {
          body: {
            seq_no_primary_term: true,
            version: true,
            ...monitorSortPageData,
            query: {
              bool: {
                should
              }
            },
            aggregations: {
              associated_composite_monitors: {
                nested: {
                  path: 'workflow.inputs.composite_input.sequence.delegates'
                },
                aggs: {
                  monitor_ids: {
                    terms: {
                      field: 'workflow.inputs.composite_input.sequence.delegates.monitor_id'
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser: alertingCallAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await alertingCallAsCurrentUser('alerting.getMonitors', params);

        const totalMonitors = _lodash.default.get(getResponse, 'hits.total.value', 0);

        const monitorKeyValueTuples = _lodash.default.get(getResponse, 'hits.hits', []).map(result => {
          const {
            _id: id,
            _version: version,
            _seq_no: ifSeqNo,
            _primary_term: ifPrimaryTerm,
            _source: monitor
          } = result;
          const {
            name,
            enabled
          } = monitor;
          return [id, {
            id,
            version,
            ifSeqNo,
            ifPrimaryTerm,
            name,
            enabled,
            monitor
          }];
        }, {});

        const monitorMap = new Map(monitorKeyValueTuples);
        const monitorIds = [...monitorMap.keys()];
        const associatedCompositeMonitorCountMap = {};

        _lodash.default.get(getResponse, 'aggregations.associated_composite_monitors.monitor_ids.buckets', []).forEach(({
          key,
          doc_count
        }) => {
          associatedCompositeMonitorCountMap[key] = doc_count;
        });

        const aggsOrderData = {};
        const aggsSorts = {
          active: 'active',
          acknowledged: 'acknowledged',
          errors: 'errors',
          ignored: 'ignored',
          lastNotificationTime: 'last_notification_time'
        };

        if (aggsSorts[sortField]) {
          aggsOrderData.order = {
            [aggsSorts[sortField]]: sortDirection
          };
        }

        const aggsParams = {
          index: _constants.INDEX.ALL_ALERTS,
          body: {
            size: 0,
            query: {
              terms: {
                monitor_id: monitorIds
              }
            },
            aggregations: {
              uniq_monitor_ids: {
                terms: {
                  field: 'monitor_id',
                  ...aggsOrderData,
                  size: from + size
                },
                aggregations: {
                  active: {
                    filter: {
                      term: {
                        state: 'ACTIVE'
                      }
                    }
                  },
                  acknowledged: {
                    filter: {
                      term: {
                        state: 'ACKNOWLEDGED'
                      }
                    }
                  },
                  errors: {
                    filter: {
                      term: {
                        state: 'ERROR'
                      }
                    }
                  },
                  ignored: {
                    filter: {
                      bool: {
                        filter: {
                          term: {
                            state: 'COMPLETED'
                          }
                        },
                        must_not: {
                          exists: {
                            field: 'acknowledged_time'
                          }
                        }
                      }
                    }
                  },
                  last_notification_time: {
                    max: {
                      field: 'last_notification_time'
                    }
                  },
                  latest_alert: {
                    top_hits: {
                      size: 1,
                      sort: [{
                        start_time: {
                          order: 'desc'
                        }
                      }],
                      _source: {
                        includes: ['last_notification_time', 'trigger_name']
                      }
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const esAggsResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

        const buckets = _lodash.default.get(esAggsResponse, 'aggregations.uniq_monitor_ids.buckets', []).map(bucket => {
          const {
            key: id,
            last_notification_time: {
              value: lastNotificationTime
            },
            ignored: {
              doc_count: ignored
            },
            acknowledged: {
              doc_count: acknowledged
            },
            active: {
              doc_count: active
            },
            errors: {
              doc_count: errors
            },
            latest_alert: {
              hits: {
                hits: [{
                  _source: {
                    trigger_name: latestAlert
                  }
                }]
              }
            }
          } = bucket;
          const monitor = monitorMap.get(id);
          monitorMap.delete(id);
          return { ...monitor,
            id,
            lastNotificationTime,
            ignored,
            latestAlert,
            acknowledged,
            active,
            errors,
            currentTime: Date.now(),
            associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[id] || 0
          };
        });

        const unusedMonitors = [...monitorMap.values()].map(monitor => ({ ...monitor,
          lastNotificationTime: null,
          ignored: 0,
          active: 0,
          acknowledged: 0,
          errors: 0,
          latestAlert: '--',
          currentTime: Date.now(),
          associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[monitor.id] || 0
        }));

        let results = _lodash.default.orderBy(buckets.concat(unusedMonitors), [sortField], [sortDirection]); // If we sorted on monitor name then we already applied from/size to the first query to limit what we're aggregating over
        // Therefore we do not need to apply from/size to this result set
        // If we sorted on aggregations, then this is our in memory pagination


        if (!monitorSorts[sortField]) {
          results = results.slice(from, from + size);
        }

        return res.ok({
          body: {
            ok: true,
            monitors: results,
            totalMonitors
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitors', err);

        if ((0, _helpers.isIndexNotFoundError)(err)) {
          return res.ok({
            body: {
              ok: false,
              resp: {
                totalMonitors: 0,
                monitors: []
              }
            }
          });
        }

        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "acknowledgeAlerts", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const acknowledgeResponse = await callAsCurrentUser('alerting.acknowledgeAlerts', params);
        return res.ok({
          body: {
            ok: !acknowledgeResponse.failed.length,
            resp: acknowledgeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - acknowledgeAlerts:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "executeMonitor", async (context, req, res) => {
      try {
        const {
          dryrun = 'true'
        } = req.query;
        const params = {
          body: req.body,
          dryrun
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const executeResponse = await callAsCurrentUser('alerting.executeMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: executeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - executeMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "searchMonitors", async (context, req, res) => {
      try {
        const {
          query,
          index,
          size
        } = req.body;
        const params = {
          index,
          size,
          body: query
        };
        console.log('Search monitors ******* ');
        console.log(JSON.stringify(params));
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const results = await callAsCurrentUser('alerting.getMonitors', params);
        return res.ok({
          body: {
            ok: true,
            resp: results
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - searchMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    this.esDriver = esDriver;
  }

}

exports.default = MonitorService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk1vbml0b3JTZXJ2aWNlLmpzIl0sIm5hbWVzIjpbIk1vbml0b3JTZXJ2aWNlIiwiY29uc3RydWN0b3IiLCJlc0RyaXZlciIsImNvbnRleHQiLCJyZXEiLCJyZXMiLCJwYXJhbXMiLCJib2R5IiwiY2FsbEFzQ3VycmVudFVzZXIiLCJhc1Njb3BlZCIsImNyZWF0ZVJlc3BvbnNlIiwib2siLCJyZXNwIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibWVzc2FnZSIsImlkIiwibW9uaXRvcklkIiwicmVzcG9uc2UiLCJyZXN1bHQiLCJsb2ciLCJnZXRSZXNwb25zZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJtb25pdG9yIiwiXyIsImdldCIsInZlcnNpb24iLCJpZlNlcU5vIiwiaWZQcmltYXJ5VGVybSIsImFzc29jaWF0ZWRfd29ya2Zsb3dzIiwiYWdnc1BhcmFtcyIsImluZGV4IiwiSU5ERVgiLCJBTExfQUxFUlRTIiwic2l6ZSIsInF1ZXJ5IiwiYm9vbCIsIm11c3QiLCJ0ZXJtIiwibW9uaXRvcl9pZCIsImFnZ3MiLCJhY3RpdmVfY291bnQiLCJ0ZXJtcyIsImZpZWxkIiwiZGF0ZV9yYW5nZSIsInJhbmdlcyIsImZyb20iLCJzZWFyY2hSZXNwb25zZSIsImRheUNvdW50IiwiYWN0aXZlQnVja2V0cyIsImFjdGl2ZUNvdW50IiwicmVkdWNlIiwiYWNjIiwiY3VyciIsImtleSIsImRvY19jb3VudCIsIm1vbml0b3JfdHlwZSIsIndvcmtmbG93X3R5cGUiLCJyZWZyZXNoIiwidHlwZSIsImlmX3NlcV9ubyIsImlmX3ByaW1hcnlfdGVybSIsInVwZGF0ZVJlc3BvbnNlIiwiX3ZlcnNpb24iLCJfaWQiLCJzZWFyY2giLCJzb3J0RGlyZWN0aW9uIiwic29ydEZpZWxkIiwic3RhdGUiLCJtYXRjaF9hbGwiLCJ0cmltIiwicXVlcnlfc3RyaW5nIiwiZGVmYXVsdF9maWVsZCIsImRlZmF1bHRfb3BlcmF0b3IiLCJzcGxpdCIsImpvaW4iLCJzaG91bGQiLCJlbmFibGVkIiwicHVzaCIsIm1vbml0b3JTb3J0cyIsIm5hbWUiLCJtb25pdG9yU29ydFBhZ2VEYXRhIiwic29ydCIsImRlZmF1bHRUbyIsInNlcV9ub19wcmltYXJ5X3Rlcm0iLCJhZ2dyZWdhdGlvbnMiLCJhc3NvY2lhdGVkX2NvbXBvc2l0ZV9tb25pdG9ycyIsIm5lc3RlZCIsInBhdGgiLCJtb25pdG9yX2lkcyIsImFsZXJ0aW5nQ2FsbEFzQ3VycmVudFVzZXIiLCJ0b3RhbE1vbml0b3JzIiwibW9uaXRvcktleVZhbHVlVHVwbGVzIiwibWFwIiwiX3NlcV9ubyIsIl9wcmltYXJ5X3Rlcm0iLCJfc291cmNlIiwibW9uaXRvck1hcCIsIk1hcCIsIm1vbml0b3JJZHMiLCJrZXlzIiwiYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcCIsImZvckVhY2giLCJhZ2dzT3JkZXJEYXRhIiwiYWdnc1NvcnRzIiwiYWN0aXZlIiwiYWNrbm93bGVkZ2VkIiwiZXJyb3JzIiwiaWdub3JlZCIsImxhc3ROb3RpZmljYXRpb25UaW1lIiwib3JkZXIiLCJ1bmlxX21vbml0b3JfaWRzIiwiZmlsdGVyIiwibXVzdF9ub3QiLCJleGlzdHMiLCJsYXN0X25vdGlmaWNhdGlvbl90aW1lIiwibWF4IiwibGF0ZXN0X2FsZXJ0IiwidG9wX2hpdHMiLCJzdGFydF90aW1lIiwiaW5jbHVkZXMiLCJlc0FnZ3NSZXNwb25zZSIsImJ1Y2tldHMiLCJidWNrZXQiLCJ2YWx1ZSIsImhpdHMiLCJ0cmlnZ2VyX25hbWUiLCJsYXRlc3RBbGVydCIsImRlbGV0ZSIsImN1cnJlbnRUaW1lIiwiRGF0ZSIsIm5vdyIsImFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ250IiwidW51c2VkTW9uaXRvcnMiLCJ2YWx1ZXMiLCJyZXN1bHRzIiwib3JkZXJCeSIsImNvbmNhdCIsInNsaWNlIiwibW9uaXRvcnMiLCJhY2tub3dsZWRnZVJlc3BvbnNlIiwiZmFpbGVkIiwibGVuZ3RoIiwiZHJ5cnVuIiwiZXhlY3V0ZVJlc3BvbnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBS0E7O0FBRUE7O0FBQ0E7Ozs7OztBQUVlLE1BQU1BLGNBQU4sQ0FBcUI7QUFDbENDLEVBQUFBLFdBQVcsQ0FBQ0MsUUFBRCxFQUFXO0FBQUEsMkNBSU4sT0FBT0MsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNQyxNQUFNLEdBQUc7QUFBRUMsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBQVosU0FBZjtBQUNBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNTSxjQUFjLEdBQUcsTUFBTUYsaUJBQWlCLENBQUMsd0JBQUQsRUFBMkJGLE1BQTNCLENBQTlDO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUY7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BVkQsQ0FVRSxPQUFPRyxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNENBQWQsRUFBNERGLEdBQTVEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXhCcUI7O0FBQUEsNENBMEJMLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUM1QyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxHQUFHO0FBQUVDLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRztBQUFaLFNBQWY7QUFDQSxjQUFNO0FBQUVDLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTU0sY0FBYyxHQUFHLE1BQU1GLGlCQUFpQixDQUFDLHlCQUFELEVBQTRCRixNQUE1QixDQUE5QztBQUNBLGVBQU9ELEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVGO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQVZELENBVUUsT0FBT0csR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDZDQUFkLEVBQTZERixHQUE3RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0E5Q3FCOztBQUFBLDJDQWdETixPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDM0MsVUFBSTtBQUNGLGNBQU07QUFBRVksVUFBQUE7QUFBRixZQUFTYixHQUFHLENBQUNFLE1BQW5CO0FBQ0EsY0FBTUEsTUFBTSxHQUFHO0FBQUVZLFVBQUFBLFNBQVMsRUFBRUQ7QUFBYixTQUFmO0FBQ0EsY0FBTTtBQUFFVCxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1lLFFBQVEsR0FBRyxNQUFNWCxpQkFBaUIsQ0FBQyx3QkFBRCxFQUEyQkYsTUFBM0IsQ0FBeEM7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFUSxRQUFRLENBQUNDLE1BQVQsS0FBb0I7QUFEcEI7QUFETSxTQUFQLENBQVA7QUFLRCxPQVZELENBVUUsT0FBT1AsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDRDQUFkLEVBQTRERixHQUE1RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0FwRXFCOztBQUFBLHdDQXNFVCxPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDeENTLE1BQUFBLE9BQU8sQ0FBQ08sR0FBUixDQUFZLDBCQUFaOztBQUNBLFVBQUk7QUFDRixjQUFNO0FBQUVKLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUFFWSxVQUFBQSxTQUFTLEVBQUVEO0FBQWIsU0FBZjtBQUNBLGNBQU07QUFBRVQsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNa0IsV0FBVyxHQUFHLE1BQU1kLGlCQUFpQixDQUFDLHFCQUFELEVBQXdCRixNQUF4QixDQUEzQztBQUNBUSxRQUFBQSxPQUFPLENBQUNPLEdBQVIsQ0FBWSx5Q0FBWjtBQUNBUCxRQUFBQSxPQUFPLENBQUNPLEdBQVIsQ0FBWUUsSUFBSSxDQUFDQyxTQUFMLENBQWVGLFdBQWYsQ0FBWjs7QUFDQSxZQUFJRyxPQUFPLEdBQUdDLGdCQUFFQyxHQUFGLENBQU1MLFdBQU4sRUFBbUIsU0FBbkIsRUFBOEIsSUFBOUIsQ0FBZDs7QUFDQSxjQUFNTSxPQUFPLEdBQUdGLGdCQUFFQyxHQUFGLENBQU1MLFdBQU4sRUFBbUIsVUFBbkIsRUFBK0IsSUFBL0IsQ0FBaEI7O0FBQ0EsY0FBTU8sT0FBTyxHQUFHSCxnQkFBRUMsR0FBRixDQUFNTCxXQUFOLEVBQW1CLFNBQW5CLEVBQThCLElBQTlCLENBQWhCOztBQUNBLGNBQU1RLGFBQWEsR0FBR0osZ0JBQUVDLEdBQUYsQ0FBTUwsV0FBTixFQUFtQixlQUFuQixFQUFvQyxJQUFwQyxDQUF0Qjs7QUFDQSxjQUFNUyxvQkFBb0IsR0FBR0wsZ0JBQUVDLEdBQUYsQ0FBTUwsV0FBTixFQUFtQixzQkFBbkIsRUFBMkMsSUFBM0MsQ0FBN0I7O0FBQ0EsWUFBSUcsT0FBSixFQUFhO0FBQ1gsZ0JBQU07QUFBRWpCLFlBQUFBO0FBQUYsY0FBd0IsS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUE5QjtBQUNBLGdCQUFNNEIsVUFBVSxHQUFHO0FBQ2pCQyxZQUFBQSxLQUFLLEVBQUVDLGlCQUFNQyxVQURJO0FBRWpCNUIsWUFBQUEsSUFBSSxFQUFFO0FBQ0o2QixjQUFBQSxJQUFJLEVBQUUsQ0FERjtBQUVKQyxjQUFBQSxLQUFLLEVBQUU7QUFDTEMsZ0JBQUFBLElBQUksRUFBRTtBQUNKQyxrQkFBQUEsSUFBSSxFQUFFO0FBQ0pDLG9CQUFBQSxJQUFJLEVBQUU7QUFDSkMsc0JBQUFBLFVBQVUsRUFBRXhCO0FBRFI7QUFERjtBQURGO0FBREQsZUFGSDtBQVdKeUIsY0FBQUEsSUFBSSxFQUFFO0FBQ0pDLGdCQUFBQSxZQUFZLEVBQUU7QUFDWkMsa0JBQUFBLEtBQUssRUFBRTtBQUNMQyxvQkFBQUEsS0FBSyxFQUFFO0FBREY7QUFESyxpQkFEVjtBQU1KLGlDQUFpQjtBQUNmQyxrQkFBQUEsVUFBVSxFQUFFO0FBQ1ZELG9CQUFBQSxLQUFLLEVBQUUsWUFERztBQUVWRSxvQkFBQUEsTUFBTSxFQUFFLENBQUM7QUFBRUMsc0JBQUFBLElBQUksRUFBRTtBQUFSLHFCQUFEO0FBRkU7QUFERztBQU5iO0FBWEY7QUFGVyxXQUFuQjtBQTRCQSxnQkFBTUMsY0FBYyxHQUFHLE1BQU16QyxpQkFBaUIsQ0FBQyxzQkFBRCxFQUF5QndCLFVBQXpCLENBQTlDOztBQUNBLGdCQUFNa0IsUUFBUSxHQUFHeEIsZ0JBQUVDLEdBQUYsQ0FBTXNCLGNBQU4sRUFBc0IsZ0RBQXRCLEVBQXdFLENBQXhFLENBQWpCOztBQUNBLGdCQUFNRSxhQUFhLEdBQUd6QixnQkFBRUMsR0FBRixDQUFNc0IsY0FBTixFQUFzQixtQ0FBdEIsRUFBMkQsRUFBM0QsQ0FBdEI7O0FBQ0EsZ0JBQU1HLFdBQVcsR0FBR0QsYUFBYSxDQUFDRSxNQUFkLENBQ2xCLENBQUNDLEdBQUQsRUFBTUMsSUFBTixLQUFnQkEsSUFBSSxDQUFDQyxHQUFMLEtBQWEsUUFBYixHQUF3QkQsSUFBSSxDQUFDRSxTQUE3QixHQUF5Q0gsR0FEdkMsRUFFbEIsQ0FGa0IsQ0FBcEI7O0FBSUEsY0FBSXZCLG9CQUFKLEVBQTBCO0FBQ3hCTixZQUFBQSxPQUFPLEdBQUcsRUFDUixHQUFHQSxPQURLO0FBRVJNLGNBQUFBO0FBRlEsYUFBVjtBQUlEOztBQUNELGlCQUFPMUIsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosWUFBQUEsSUFBSSxFQUFFO0FBQUVJLGNBQUFBLEVBQUUsRUFBRSxJQUFOO0FBQVlDLGNBQUFBLElBQUksRUFBRWEsT0FBbEI7QUFBMkIyQixjQUFBQSxXQUEzQjtBQUF3Q0YsY0FBQUEsUUFBeEM7QUFBa0R0QixjQUFBQSxPQUFsRDtBQUEyREMsY0FBQUEsT0FBM0Q7QUFBb0VDLGNBQUFBO0FBQXBFO0FBRE0sV0FBUCxDQUFQO0FBR0QsU0E5Q0QsTUE4Q087QUFDTCxpQkFBT3pCLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFlBQUFBLElBQUksRUFBRTtBQUNKSSxjQUFBQSxFQUFFLEVBQUU7QUFEQTtBQURNLFdBQVAsQ0FBUDtBQUtEO0FBQ0YsT0FqRUQsQ0FpRUUsT0FBT0UsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLHlDQUFkLEVBQXlERixHQUF6RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0FsSnFCOztBQUFBLHlDQW9KUixPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDekNTLE1BQUFBLE9BQU8sQ0FBQ08sR0FBUixDQUFZLDJCQUFaOztBQUNBLFVBQUk7QUFDRixjQUFNO0FBQUVKLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUFFWSxVQUFBQSxTQUFTLEVBQUVEO0FBQWIsU0FBZjtBQUNBLGNBQU07QUFBRVQsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNa0IsV0FBVyxHQUFHLE1BQU1kLGlCQUFpQixDQUFDLHNCQUFELEVBQXlCRixNQUF6QixDQUEzQzs7QUFDQSxjQUFNbUIsT0FBTyxHQUFHQyxnQkFBRUMsR0FBRixDQUFNTCxXQUFOLEVBQW1CLFVBQW5CLEVBQStCLElBQS9CLENBQWhCOztBQUNBLGNBQU1NLE9BQU8sR0FBR0YsZ0JBQUVDLEdBQUYsQ0FBTUwsV0FBTixFQUFtQixVQUFuQixFQUErQixJQUEvQixDQUFoQjs7QUFDQSxjQUFNTyxPQUFPLEdBQUdILGdCQUFFQyxHQUFGLENBQU1MLFdBQU4sRUFBbUIsU0FBbkIsRUFBOEIsSUFBOUIsQ0FBaEI7O0FBQ0EsY0FBTVEsYUFBYSxHQUFHSixnQkFBRUMsR0FBRixDQUFNTCxXQUFOLEVBQW1CLGVBQW5CLEVBQW9DLElBQXBDLENBQXRCOztBQUNBRyxRQUFBQSxPQUFPLENBQUNpQyxZQUFSLEdBQXVCakMsT0FBTyxDQUFDa0MsYUFBL0I7QUFFQSxlQUFPdEQsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRWEsT0FGRjtBQUdKMkIsWUFBQUEsV0FBVyxFQUFFLENBSFQ7QUFJSkYsWUFBQUEsUUFBUSxFQUFFLENBSk47QUFLSnRCLFlBQUFBLE9BTEk7QUFNSkMsWUFBQUEsT0FOSTtBQU9KQyxZQUFBQTtBQVBJO0FBRE0sU0FBUCxDQUFQO0FBV0QsT0F0QkQsQ0FzQkUsT0FBT2pCLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYywwQ0FBZCxFQUEwREYsR0FBMUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBckxxQjs7QUFBQSwyQ0F1TE4sT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUFFWSxVQUFBQSxTQUFTLEVBQUVELEVBQWI7QUFBaUJWLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRyxJQUEzQjtBQUFpQ3FELFVBQUFBLE9BQU8sRUFBRTtBQUExQyxTQUFmO0FBQ0EsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQVd6RCxHQUFHLENBQUNHLElBQXJCLENBSEUsQ0FLRjs7QUFDQSxjQUFNO0FBQUVzQixVQUFBQSxPQUFGO0FBQVdDLFVBQUFBO0FBQVgsWUFBNkIxQixHQUFHLENBQUNpQyxLQUF2Qzs7QUFDQSxZQUFJUixPQUFPLElBQUlDLGFBQWYsRUFBOEI7QUFDNUJ4QixVQUFBQSxNQUFNLENBQUN3RCxTQUFQLEdBQW1CakMsT0FBbkI7QUFDQXZCLFVBQUFBLE1BQU0sQ0FBQ3lELGVBQVAsR0FBeUJqQyxhQUF6QjtBQUNEOztBQUVELGNBQU07QUFBRXRCLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTTRELGNBQWMsR0FBRyxNQUFNeEQsaUJBQWlCLENBQzNDLFlBQVdxRCxJQUFJLEtBQUssVUFBVCxHQUFzQixnQkFBdEIsR0FBeUMsZUFBZ0IsRUFEekIsRUFFNUN2RCxNQUY0QyxDQUE5QztBQUlBLGNBQU07QUFBRTJELFVBQUFBLFFBQUY7QUFBWUMsVUFBQUE7QUFBWixZQUFvQkYsY0FBMUI7QUFDQSxlQUFPM0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUppQixZQUFBQSxPQUFPLEVBQUVxQyxRQUZMO0FBR0poRCxZQUFBQSxFQUFFLEVBQUVpRDtBQUhBO0FBRE0sU0FBUCxDQUFQO0FBT0QsT0F6QkQsQ0F5QkUsT0FBT3JELEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw0Q0FBZCxFQUE0REYsR0FBNUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBMU5xQjs7QUFBQSx5Q0E0TlIsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3pDUyxNQUFBQSxPQUFPLENBQUNPLEdBQVIsQ0FBWSwyQkFBWjs7QUFDQSxVQUFJO0FBQ0YsY0FBTTtBQUFFMkIsVUFBQUEsSUFBRjtBQUFRWixVQUFBQSxJQUFSO0FBQWMrQixVQUFBQSxNQUFkO0FBQXNCQyxVQUFBQSxhQUF0QjtBQUFxQ0MsVUFBQUEsU0FBckM7QUFBZ0RDLFVBQUFBO0FBQWhELFlBQTBEbEUsR0FBRyxDQUFDaUMsS0FBcEU7QUFFQSxZQUFJRSxJQUFJLEdBQUc7QUFBRWdDLFVBQUFBLFNBQVMsRUFBRTtBQUFiLFNBQVg7O0FBQ0EsWUFBSUosTUFBTSxDQUFDSyxJQUFQLEVBQUosRUFBbUI7QUFDakI7QUFDQTtBQUNBO0FBQ0FqQyxVQUFBQSxJQUFJLEdBQUc7QUFDTGtDLFlBQUFBLFlBQVksRUFBRTtBQUNaQyxjQUFBQSxhQUFhLEVBQUUsY0FESDtBQUVaQyxjQUFBQSxnQkFBZ0IsRUFBRSxLQUZOO0FBR1p0QyxjQUFBQSxLQUFLLEVBQUcsSUFBRzhCLE1BQU0sQ0FBQ0ssSUFBUCxHQUFjSSxLQUFkLENBQW9CLEdBQXBCLEVBQXlCQyxJQUF6QixDQUE4QixLQUE5QixDQUFxQztBQUhwQztBQURULFdBQVA7QUFPRDs7QUFFRCxjQUFNQyxNQUFNLEdBQUcsRUFBZjs7QUFDQSxZQUFJUixLQUFLLEtBQUssS0FBZCxFQUFxQjtBQUNuQixnQkFBTVMsT0FBTyxHQUFHVCxLQUFLLEtBQUssU0FBMUI7QUFDQVEsVUFBQUEsTUFBTSxDQUFDRSxJQUFQLENBQVk7QUFBRXhDLFlBQUFBLElBQUksRUFBRTtBQUFFLGlDQUFtQnVDO0FBQXJCO0FBQVIsV0FBWjtBQUNBRCxVQUFBQSxNQUFNLENBQUNFLElBQVAsQ0FBWTtBQUFFeEMsWUFBQUEsSUFBSSxFQUFFO0FBQUUsa0NBQW9CdUM7QUFBdEI7QUFBUixXQUFaO0FBQ0Q7O0FBRUQsY0FBTUUsWUFBWSxHQUFHO0FBQUVDLFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQXJCO0FBQ0EsY0FBTUMsbUJBQW1CLEdBQUc7QUFBRS9DLFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQTVCOztBQUNBLFlBQUk2QyxZQUFZLENBQUNaLFNBQUQsQ0FBaEIsRUFBNkI7QUFDM0JjLFVBQUFBLG1CQUFtQixDQUFDQyxJQUFwQixHQUEyQixDQUFDO0FBQUUsYUFBQ0gsWUFBWSxDQUFDWixTQUFELENBQWIsR0FBMkJEO0FBQTdCLFdBQUQsQ0FBM0I7QUFDQWUsVUFBQUEsbUJBQW1CLENBQUMvQyxJQUFwQixHQUEyQlYsZ0JBQUUyRCxTQUFGLENBQVlqRCxJQUFaLEVBQWtCLElBQWxCLENBQTNCO0FBQ0ErQyxVQUFBQSxtQkFBbUIsQ0FBQ25DLElBQXBCLEdBQTJCdEIsZ0JBQUUyRCxTQUFGLENBQVlyQyxJQUFaLEVBQWtCLENBQWxCLENBQTNCO0FBQ0Q7O0FBRUQsY0FBTTFDLE1BQU0sR0FBRztBQUNiQyxVQUFBQSxJQUFJLEVBQUU7QUFDSitFLFlBQUFBLG1CQUFtQixFQUFFLElBRGpCO0FBRUoxRCxZQUFBQSxPQUFPLEVBQUUsSUFGTDtBQUdKLGVBQUd1RCxtQkFIQztBQUlKOUMsWUFBQUEsS0FBSyxFQUFFO0FBQ0xDLGNBQUFBLElBQUksRUFBRTtBQUNKd0MsZ0JBQUFBO0FBREk7QUFERCxhQUpIO0FBU0pTLFlBQUFBLFlBQVksRUFBRTtBQUNaQyxjQUFBQSw2QkFBNkIsRUFBRTtBQUM3QkMsZ0JBQUFBLE1BQU0sRUFBRTtBQUNOQyxrQkFBQUEsSUFBSSxFQUFFO0FBREEsaUJBRHFCO0FBSTdCaEQsZ0JBQUFBLElBQUksRUFBRTtBQUNKaUQsa0JBQUFBLFdBQVcsRUFBRTtBQUNYL0Msb0JBQUFBLEtBQUssRUFBRTtBQUNMQyxzQkFBQUEsS0FBSyxFQUFFO0FBREY7QUFESTtBQURUO0FBSnVCO0FBRG5CO0FBVFY7QUFETyxTQUFmO0FBMkJBLGNBQU07QUFBRXJDLFVBQUFBLGlCQUFpQixFQUFFb0Y7QUFBckIsWUFBbUQsTUFBTSxLQUFLMUYsUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUEvRDtBQUNBLGNBQU1rQixXQUFXLEdBQUcsTUFBTXNFLHlCQUF5QixDQUFDLHNCQUFELEVBQXlCdEYsTUFBekIsQ0FBbkQ7O0FBRUEsY0FBTXVGLGFBQWEsR0FBR25FLGdCQUFFQyxHQUFGLENBQU1MLFdBQU4sRUFBbUIsa0JBQW5CLEVBQXVDLENBQXZDLENBQXRCOztBQUNBLGNBQU13RSxxQkFBcUIsR0FBR3BFLGdCQUFFQyxHQUFGLENBQU1MLFdBQU4sRUFBbUIsV0FBbkIsRUFBZ0MsRUFBaEMsRUFBb0N5RSxHQUFwQyxDQUF5QzNFLE1BQUQsSUFBWTtBQUNoRixnQkFBTTtBQUNKOEMsWUFBQUEsR0FBRyxFQUFFakQsRUFERDtBQUVKZ0QsWUFBQUEsUUFBUSxFQUFFckMsT0FGTjtBQUdKb0UsWUFBQUEsT0FBTyxFQUFFbkUsT0FITDtBQUlKb0UsWUFBQUEsYUFBYSxFQUFFbkUsYUFKWDtBQUtKb0UsWUFBQUEsT0FBTyxFQUFFekU7QUFMTCxjQU1GTCxNQU5KO0FBT0EsZ0JBQU07QUFBRThELFlBQUFBLElBQUY7QUFBUUgsWUFBQUE7QUFBUixjQUFvQnRELE9BQTFCO0FBQ0EsaUJBQU8sQ0FBQ1IsRUFBRCxFQUFLO0FBQUVBLFlBQUFBLEVBQUY7QUFBTVcsWUFBQUEsT0FBTjtBQUFlQyxZQUFBQSxPQUFmO0FBQXdCQyxZQUFBQSxhQUF4QjtBQUF1Q29ELFlBQUFBLElBQXZDO0FBQTZDSCxZQUFBQSxPQUE3QztBQUFzRHRELFlBQUFBO0FBQXRELFdBQUwsQ0FBUDtBQUNELFNBVjZCLEVBVTNCLEVBVjJCLENBQTlCOztBQVdBLGNBQU0wRSxVQUFVLEdBQUcsSUFBSUMsR0FBSixDQUFRTixxQkFBUixDQUFuQjtBQUNBLGNBQU1PLFVBQVUsR0FBRyxDQUFDLEdBQUdGLFVBQVUsQ0FBQ0csSUFBWCxFQUFKLENBQW5CO0FBQ0EsY0FBTUMsa0NBQWtDLEdBQUcsRUFBM0M7O0FBQ0E3RSx3QkFBRUMsR0FBRixDQUNFTCxXQURGLEVBRUUsZ0VBRkYsRUFHRSxFQUhGLEVBSUVrRixPQUpGLENBSVUsQ0FBQztBQUFFaEQsVUFBQUEsR0FBRjtBQUFPQyxVQUFBQTtBQUFQLFNBQUQsS0FBd0I7QUFDaEM4QyxVQUFBQSxrQ0FBa0MsQ0FBQy9DLEdBQUQsQ0FBbEMsR0FBMENDLFNBQTFDO0FBQ0QsU0FORDs7QUFRQSxjQUFNZ0QsYUFBYSxHQUFHLEVBQXRCO0FBQ0EsY0FBTUMsU0FBUyxHQUFHO0FBQ2hCQyxVQUFBQSxNQUFNLEVBQUUsUUFEUTtBQUVoQkMsVUFBQUEsWUFBWSxFQUFFLGNBRkU7QUFHaEJDLFVBQUFBLE1BQU0sRUFBRSxRQUhRO0FBSWhCQyxVQUFBQSxPQUFPLEVBQUUsU0FKTztBQUtoQkMsVUFBQUEsb0JBQW9CLEVBQUU7QUFMTixTQUFsQjs7QUFPQSxZQUFJTCxTQUFTLENBQUNyQyxTQUFELENBQWIsRUFBMEI7QUFDeEJvQyxVQUFBQSxhQUFhLENBQUNPLEtBQWQsR0FBc0I7QUFBRSxhQUFDTixTQUFTLENBQUNyQyxTQUFELENBQVYsR0FBd0JEO0FBQTFCLFdBQXRCO0FBQ0Q7O0FBQ0QsY0FBTXBDLFVBQVUsR0FBRztBQUNqQkMsVUFBQUEsS0FBSyxFQUFFQyxpQkFBTUMsVUFESTtBQUVqQjVCLFVBQUFBLElBQUksRUFBRTtBQUNKNkIsWUFBQUEsSUFBSSxFQUFFLENBREY7QUFFSkMsWUFBQUEsS0FBSyxFQUFFO0FBQUVPLGNBQUFBLEtBQUssRUFBRTtBQUFFSCxnQkFBQUEsVUFBVSxFQUFFNEQ7QUFBZDtBQUFULGFBRkg7QUFHSmQsWUFBQUEsWUFBWSxFQUFFO0FBQ1owQixjQUFBQSxnQkFBZ0IsRUFBRTtBQUNoQnJFLGdCQUFBQSxLQUFLLEVBQUU7QUFDTEMsa0JBQUFBLEtBQUssRUFBRSxZQURGO0FBRUwscUJBQUc0RCxhQUZFO0FBR0xyRSxrQkFBQUEsSUFBSSxFQUFFWSxJQUFJLEdBQUdaO0FBSFIsaUJBRFM7QUFNaEJtRCxnQkFBQUEsWUFBWSxFQUFFO0FBQ1pvQixrQkFBQUEsTUFBTSxFQUFFO0FBQUVPLG9CQUFBQSxNQUFNLEVBQUU7QUFBRTFFLHNCQUFBQSxJQUFJLEVBQUU7QUFBRThCLHdCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFSO0FBQVYsbUJBREk7QUFFWnNDLGtCQUFBQSxZQUFZLEVBQUU7QUFBRU0sb0JBQUFBLE1BQU0sRUFBRTtBQUFFMUUsc0JBQUFBLElBQUksRUFBRTtBQUFFOEIsd0JBQUFBLEtBQUssRUFBRTtBQUFUO0FBQVI7QUFBVixtQkFGRjtBQUdadUMsa0JBQUFBLE1BQU0sRUFBRTtBQUFFSyxvQkFBQUEsTUFBTSxFQUFFO0FBQUUxRSxzQkFBQUEsSUFBSSxFQUFFO0FBQUU4Qix3QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUjtBQUFWLG1CQUhJO0FBSVp3QyxrQkFBQUEsT0FBTyxFQUFFO0FBQ1BJLG9CQUFBQSxNQUFNLEVBQUU7QUFDTjVFLHNCQUFBQSxJQUFJLEVBQUU7QUFDSjRFLHdCQUFBQSxNQUFNLEVBQUU7QUFBRTFFLDBCQUFBQSxJQUFJLEVBQUU7QUFBRThCLDRCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFSLHlCQURKO0FBRUo2Qyx3QkFBQUEsUUFBUSxFQUFFO0FBQUVDLDBCQUFBQSxNQUFNLEVBQUU7QUFBRXZFLDRCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFWO0FBRk47QUFEQTtBQURELG1CQUpHO0FBWVp3RSxrQkFBQUEsc0JBQXNCLEVBQUU7QUFBRUMsb0JBQUFBLEdBQUcsRUFBRTtBQUFFekUsc0JBQUFBLEtBQUssRUFBRTtBQUFUO0FBQVAsbUJBWlo7QUFhWjBFLGtCQUFBQSxZQUFZLEVBQUU7QUFDWkMsb0JBQUFBLFFBQVEsRUFBRTtBQUNScEYsc0JBQUFBLElBQUksRUFBRSxDQURFO0FBRVJnRCxzQkFBQUEsSUFBSSxFQUFFLENBQUM7QUFBRXFDLHdCQUFBQSxVQUFVLEVBQUU7QUFBRVQsMEJBQUFBLEtBQUssRUFBRTtBQUFUO0FBQWQsdUJBQUQsQ0FGRTtBQUdSZCxzQkFBQUEsT0FBTyxFQUFFO0FBQ1B3Qix3QkFBQUEsUUFBUSxFQUFFLENBQUMsd0JBQUQsRUFBMkIsY0FBM0I7QUFESDtBQUhEO0FBREU7QUFiRjtBQU5FO0FBRE47QUFIVjtBQUZXLFNBQW5CO0FBd0NBLGNBQU07QUFBRWxILFVBQUFBO0FBQUYsWUFBd0IsS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUE5QjtBQUNBLGNBQU11SCxjQUFjLEdBQUcsTUFBTW5ILGlCQUFpQixDQUFDLHNCQUFELEVBQXlCd0IsVUFBekIsQ0FBOUM7O0FBQ0EsY0FBTTRGLE9BQU8sR0FBR2xHLGdCQUFFQyxHQUFGLENBQU1nRyxjQUFOLEVBQXNCLHVDQUF0QixFQUErRCxFQUEvRCxFQUFtRTVCLEdBQW5FLENBQ2I4QixNQUFELElBQVk7QUFDVixnQkFBTTtBQUNKckUsWUFBQUEsR0FBRyxFQUFFdkMsRUFERDtBQUVKb0csWUFBQUEsc0JBQXNCLEVBQUU7QUFBRVMsY0FBQUEsS0FBSyxFQUFFZjtBQUFULGFBRnBCO0FBR0pELFlBQUFBLE9BQU8sRUFBRTtBQUFFckQsY0FBQUEsU0FBUyxFQUFFcUQ7QUFBYixhQUhMO0FBSUpGLFlBQUFBLFlBQVksRUFBRTtBQUFFbkQsY0FBQUEsU0FBUyxFQUFFbUQ7QUFBYixhQUpWO0FBS0pELFlBQUFBLE1BQU0sRUFBRTtBQUFFbEQsY0FBQUEsU0FBUyxFQUFFa0Q7QUFBYixhQUxKO0FBTUpFLFlBQUFBLE1BQU0sRUFBRTtBQUFFcEQsY0FBQUEsU0FBUyxFQUFFb0Q7QUFBYixhQU5KO0FBT0pVLFlBQUFBLFlBQVksRUFBRTtBQUNaUSxjQUFBQSxJQUFJLEVBQUU7QUFDSkEsZ0JBQUFBLElBQUksRUFBRSxDQUNKO0FBQ0U3QixrQkFBQUEsT0FBTyxFQUFFO0FBQUU4QixvQkFBQUEsWUFBWSxFQUFFQztBQUFoQjtBQURYLGlCQURJO0FBREY7QUFETTtBQVBWLGNBZ0JGSixNQWhCSjtBQWlCQSxnQkFBTXBHLE9BQU8sR0FBRzBFLFVBQVUsQ0FBQ3hFLEdBQVgsQ0FBZVYsRUFBZixDQUFoQjtBQUNBa0YsVUFBQUEsVUFBVSxDQUFDK0IsTUFBWCxDQUFrQmpILEVBQWxCO0FBQ0EsaUJBQU8sRUFDTCxHQUFHUSxPQURFO0FBRUxSLFlBQUFBLEVBRks7QUFHTDhGLFlBQUFBLG9CQUhLO0FBSUxELFlBQUFBLE9BSks7QUFLTG1CLFlBQUFBLFdBTEs7QUFNTHJCLFlBQUFBLFlBTks7QUFPTEQsWUFBQUEsTUFQSztBQVFMRSxZQUFBQSxNQVJLO0FBU0xzQixZQUFBQSxXQUFXLEVBQUVDLElBQUksQ0FBQ0MsR0FBTCxFQVRSO0FBVUxDLFlBQUFBLDZCQUE2QixFQUFFL0Isa0NBQWtDLENBQUN0RixFQUFELENBQWxDLElBQTBDO0FBVnBFLFdBQVA7QUFZRCxTQWpDYSxDQUFoQjs7QUFvQ0EsY0FBTXNILGNBQWMsR0FBRyxDQUFDLEdBQUdwQyxVQUFVLENBQUNxQyxNQUFYLEVBQUosRUFBeUJ6QyxHQUF6QixDQUE4QnRFLE9BQUQsS0FBYyxFQUNoRSxHQUFHQSxPQUQ2RDtBQUVoRXNGLFVBQUFBLG9CQUFvQixFQUFFLElBRjBDO0FBR2hFRCxVQUFBQSxPQUFPLEVBQUUsQ0FIdUQ7QUFJaEVILFVBQUFBLE1BQU0sRUFBRSxDQUp3RDtBQUtoRUMsVUFBQUEsWUFBWSxFQUFFLENBTGtEO0FBTWhFQyxVQUFBQSxNQUFNLEVBQUUsQ0FOd0Q7QUFPaEVvQixVQUFBQSxXQUFXLEVBQUUsSUFQbUQ7QUFRaEVFLFVBQUFBLFdBQVcsRUFBRUMsSUFBSSxDQUFDQyxHQUFMLEVBUm1EO0FBU2hFQyxVQUFBQSw2QkFBNkIsRUFBRS9CLGtDQUFrQyxDQUFDOUUsT0FBTyxDQUFDUixFQUFULENBQWxDLElBQWtEO0FBVGpCLFNBQWQsQ0FBN0IsQ0FBdkI7O0FBWUEsWUFBSXdILE9BQU8sR0FBRy9HLGdCQUFFZ0gsT0FBRixDQUFVZCxPQUFPLENBQUNlLE1BQVIsQ0FBZUosY0FBZixDQUFWLEVBQTBDLENBQUNsRSxTQUFELENBQTFDLEVBQXVELENBQUNELGFBQUQsQ0FBdkQsQ0FBZCxDQTFMRSxDQTJMRjtBQUNBO0FBQ0E7OztBQUNBLFlBQUksQ0FBQ2EsWUFBWSxDQUFDWixTQUFELENBQWpCLEVBQThCO0FBQzVCb0UsVUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUNHLEtBQVIsQ0FBYzVGLElBQWQsRUFBb0JBLElBQUksR0FBR1osSUFBM0IsQ0FBVjtBQUNEOztBQUVELGVBQU8vQixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSmtJLFlBQUFBLFFBQVEsRUFBRUosT0FGTjtBQUdKNUMsWUFBQUE7QUFISTtBQURNLFNBQVAsQ0FBUDtBQU9ELE9Bek1ELENBeU1FLE9BQU9oRixHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMseUNBQWQsRUFBeURGLEdBQXpEOztBQUNBLFlBQUksbUNBQXFCQSxHQUFyQixDQUFKLEVBQStCO0FBQzdCLGlCQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFBRUksY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsY0FBQUEsSUFBSSxFQUFFO0FBQUVpRixnQkFBQUEsYUFBYSxFQUFFLENBQWpCO0FBQW9CZ0QsZ0JBQUFBLFFBQVEsRUFBRTtBQUE5QjtBQUFuQjtBQURNLFdBQVAsQ0FBUDtBQUdEOztBQUNELGVBQU94SSxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBcmJxQjs7QUFBQSwrQ0F1YkYsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQy9DLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUNiWSxVQUFBQSxTQUFTLEVBQUVELEVBREU7QUFFYlYsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBRkcsU0FBZjtBQUlBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQTlCO0FBQ0EsY0FBTTBJLG1CQUFtQixHQUFHLE1BQU10SSxpQkFBaUIsQ0FBQyw0QkFBRCxFQUErQkYsTUFBL0IsQ0FBbkQ7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLENBQUNtSSxtQkFBbUIsQ0FBQ0MsTUFBcEIsQ0FBMkJDLE1BRDVCO0FBRUpwSSxZQUFBQSxJQUFJLEVBQUVrSTtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FkRCxDQWNFLE9BQU9qSSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsZ0RBQWQsRUFBZ0VGLEdBQWhFO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQS9jcUI7O0FBQUEsNENBaWRMLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUM1QyxVQUFJO0FBQ0YsY0FBTTtBQUFFNEksVUFBQUEsTUFBTSxHQUFHO0FBQVgsWUFBc0I3SSxHQUFHLENBQUNpQyxLQUFoQztBQUNBLGNBQU0vQixNQUFNLEdBQUc7QUFDYkMsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHLElBREc7QUFFYjBJLFVBQUFBO0FBRmEsU0FBZjtBQUlBLGNBQU07QUFBRXpJLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTThJLGVBQWUsR0FBRyxNQUFNMUksaUJBQWlCLENBQUMseUJBQUQsRUFBNEJGLE1BQTVCLENBQS9DO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRXNJO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQWRELENBY0UsT0FBT3JJLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw2Q0FBZCxFQUE2REYsR0FBN0Q7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBemVxQjs7QUFBQSw0Q0E0ZUwsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzVDLFVBQUk7QUFDRixjQUFNO0FBQUVnQyxVQUFBQSxLQUFGO0FBQVNKLFVBQUFBLEtBQVQ7QUFBZ0JHLFVBQUFBO0FBQWhCLFlBQXlCaEMsR0FBRyxDQUFDRyxJQUFuQztBQUNBLGNBQU1ELE1BQU0sR0FBRztBQUFFMkIsVUFBQUEsS0FBRjtBQUFTRyxVQUFBQSxJQUFUO0FBQWU3QixVQUFBQSxJQUFJLEVBQUU4QjtBQUFyQixTQUFmO0FBRUF2QixRQUFBQSxPQUFPLENBQUNPLEdBQVIsQ0FBWSwwQkFBWjtBQUNBUCxRQUFBQSxPQUFPLENBQUNPLEdBQVIsQ0FBWUUsSUFBSSxDQUFDQyxTQUFMLENBQWVsQixNQUFmLENBQVo7QUFFQSxjQUFNO0FBQUVFLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTXFJLE9BQU8sR0FBRyxNQUFNakksaUJBQWlCLENBQUMsc0JBQUQsRUFBeUJGLE1BQXpCLENBQXZDO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRTZIO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQWZELENBZUUsT0FBTzVILEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw0Q0FBZCxFQUE0REYsR0FBNUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBcmdCcUI7O0FBQ3BCLFNBQUtkLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0Q7O0FBSGlDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5pbXBvcnQgXyBmcm9tICdsb2Rhc2gnO1xuXG5pbXBvcnQgeyBJTkRFWCB9IGZyb20gJy4uLy4uL3V0aWxzL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBpc0luZGV4Tm90Rm91bmRFcnJvciB9IGZyb20gJy4vdXRpbHMvaGVscGVycyc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vbml0b3JTZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IoZXNEcml2ZXIpIHtcbiAgICB0aGlzLmVzRHJpdmVyID0gZXNEcml2ZXI7XG4gIH1cblxuICBjcmVhdGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgYm9keTogcmVxLmJvZHkgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGNyZWF0ZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmNyZWF0ZU1vbml0b3InLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwOiBjcmVhdGVSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGNyZWF0ZU1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGNyZWF0ZVdvcmtmbG93ID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgYm9keTogcmVxLmJvZHkgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGNyZWF0ZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmNyZWF0ZVdvcmtmbG93JywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogY3JlYXRlUmVzcG9uc2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBjcmVhdGVXb3JrZmxvdzonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZGVsZXRlTW9uaXRvciA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgICAgY29uc3QgcGFyYW1zID0geyBtb25pdG9ySWQ6IGlkIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5kZWxldGVNb25pdG9yJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHJlc3BvbnNlLnJlc3VsdCA9PT0gJ2RlbGV0ZWQnLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZGVsZXRlTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZ2V0TW9uaXRvciA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIGNvbnNvbGUubG9nKCcqKioqKiogR0VUIE1PTklUT1IgKioqKionKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZ2V0UmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICBjb25zb2xlLmxvZygnR2V0IG1vbml0b3IgY29tcGxldGUgcmVzcG9uc2UgXl5eXl5eXl5eJyk7XG4gICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShnZXRSZXNwb25zZSkpO1xuICAgICAgbGV0IG1vbml0b3IgPSBfLmdldChnZXRSZXNwb25zZSwgJ21vbml0b3InLCBudWxsKTtcbiAgICAgIGNvbnN0IHZlcnNpb24gPSBfLmdldChnZXRSZXNwb25zZSwgJ192ZXJzaW9uJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlNlcU5vID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfc2VxX25vJywgbnVsbCk7XG4gICAgICBjb25zdCBpZlByaW1hcnlUZXJtID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfcHJpbWFyeV90ZXJtJywgbnVsbCk7XG4gICAgICBjb25zdCBhc3NvY2lhdGVkX3dvcmtmbG93cyA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnYXNzb2NpYXRlZF93b3JrZmxvd3MnLCBudWxsKTtcbiAgICAgIGlmIChtb25pdG9yKSB7XG4gICAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgICAgY29uc3QgYWdnc1BhcmFtcyA9IHtcbiAgICAgICAgICBpbmRleDogSU5ERVguQUxMX0FMRVJUUyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgIG11c3Q6IHtcbiAgICAgICAgICAgICAgICAgIHRlcm06IHtcbiAgICAgICAgICAgICAgICAgICAgbW9uaXRvcl9pZDogaWQsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgICBhY3RpdmVfY291bnQ6IHtcbiAgICAgICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICAgICAgZmllbGQ6ICdzdGF0ZScsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgJzI0X2hvdXJfY291bnQnOiB7XG4gICAgICAgICAgICAgICAgZGF0ZV9yYW5nZToge1xuICAgICAgICAgICAgICAgICAgZmllbGQ6ICdzdGFydF90aW1lJyxcbiAgICAgICAgICAgICAgICAgIHJhbmdlczogW3sgZnJvbTogJ25vdy0yNGgvaCcgfV0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgc2VhcmNoUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBhZ2dzUGFyYW1zKTtcbiAgICAgICAgY29uc3QgZGF5Q291bnQgPSBfLmdldChzZWFyY2hSZXNwb25zZSwgJ2FnZ3JlZ2F0aW9ucy4yNF9ob3VyX2NvdW50LmJ1Y2tldHMuMC5kb2NfY291bnQnLCAwKTtcbiAgICAgICAgY29uc3QgYWN0aXZlQnVja2V0cyA9IF8uZ2V0KHNlYXJjaFJlc3BvbnNlLCAnYWdncmVnYXRpb25zLmFjdGl2ZV9jb3VudC5idWNrZXRzJywgW10pO1xuICAgICAgICBjb25zdCBhY3RpdmVDb3VudCA9IGFjdGl2ZUJ1Y2tldHMucmVkdWNlKFxuICAgICAgICAgIChhY2MsIGN1cnIpID0+IChjdXJyLmtleSA9PT0gJ0FDVElWRScgPyBjdXJyLmRvY19jb3VudCA6IGFjYyksXG4gICAgICAgICAgMFxuICAgICAgICApO1xuICAgICAgICBpZiAoYXNzb2NpYXRlZF93b3JrZmxvd3MpIHtcbiAgICAgICAgICBtb25pdG9yID0ge1xuICAgICAgICAgICAgLi4ubW9uaXRvcixcbiAgICAgICAgICAgIGFzc29jaWF0ZWRfd29ya2Zsb3dzXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHsgb2s6IHRydWUsIHJlc3A6IG1vbml0b3IsIGFjdGl2ZUNvdW50LCBkYXlDb3VudCwgdmVyc2lvbiwgaWZTZXFObywgaWZQcmltYXJ5VGVybSB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBnZXRNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBnZXRXb3JrZmxvdyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIGNvbnNvbGUubG9nKCcqKioqKiogR0VUIFdPUktGTE9XICoqKioqJyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IG1vbml0b3JJZDogaWQgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGdldFJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldFdvcmtmbG93JywgcGFyYW1zKTtcbiAgICAgIGNvbnN0IG1vbml0b3IgPSBfLmdldChnZXRSZXNwb25zZSwgJ3dvcmtmbG93JywgbnVsbCk7XG4gICAgICBjb25zdCB2ZXJzaW9uID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdfdmVyc2lvbicsIG51bGwpO1xuICAgICAgY29uc3QgaWZTZXFObyA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnX3NlcV9ubycsIG51bGwpO1xuICAgICAgY29uc3QgaWZQcmltYXJ5VGVybSA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnX3ByaW1hcnlfdGVybScsIG51bGwpO1xuICAgICAgbW9uaXRvci5tb25pdG9yX3R5cGUgPSBtb25pdG9yLndvcmtmbG93X3R5cGU7XG5cbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogbW9uaXRvcixcbiAgICAgICAgICBhY3RpdmVDb3VudDogMCxcbiAgICAgICAgICBkYXlDb3VudDogMCxcbiAgICAgICAgICB2ZXJzaW9uLFxuICAgICAgICAgIGlmU2VxTm8sXG4gICAgICAgICAgaWZQcmltYXJ5VGVybSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGdldFdvcmtmbG93OicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICB1cGRhdGVNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IG1vbml0b3JJZDogaWQsIGJvZHk6IHJlcS5ib2R5LCByZWZyZXNoOiAnd2FpdF9mb3InIH07XG4gICAgICBjb25zdCB7IHR5cGUgfSA9IHJlcS5ib2R5O1xuXG4gICAgICAvLyBUT0RPIERSQUZUOiBBcmUgd2Ugc3VyZSB3ZSBuZWVkIHRvIGluY2x1ZGUgaWZTZXFObyBhbmQgaWZQcmltYXJ5VGVybSBmcm9tIHRoZSBVSSBzaWRlIHdoZW4gdXBkYXRpbmcgbW9uaXRvcnM/XG4gICAgICBjb25zdCB7IGlmU2VxTm8sIGlmUHJpbWFyeVRlcm0gfSA9IHJlcS5xdWVyeTtcbiAgICAgIGlmIChpZlNlcU5vICYmIGlmUHJpbWFyeVRlcm0pIHtcbiAgICAgICAgcGFyYW1zLmlmX3NlcV9ubyA9IGlmU2VxTm87XG4gICAgICAgIHBhcmFtcy5pZl9wcmltYXJ5X3Rlcm0gPSBpZlByaW1hcnlUZXJtO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCB1cGRhdGVSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKFxuICAgICAgICBgYWxlcnRpbmcuJHt0eXBlID09PSAnd29ya2Zsb3cnID8gJ3VwZGF0ZVdvcmtmbG93JyA6ICd1cGRhdGVNb25pdG9yJ31gLFxuICAgICAgICBwYXJhbXNcbiAgICAgICk7XG4gICAgICBjb25zdCB7IF92ZXJzaW9uLCBfaWQgfSA9IHVwZGF0ZVJlc3BvbnNlO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICB2ZXJzaW9uOiBfdmVyc2lvbixcbiAgICAgICAgICBpZDogX2lkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gdXBkYXRlTW9uaXRvcjonLCBlcnIpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgcmVzcDogZXJyLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgZ2V0TW9uaXRvcnMgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICBjb25zb2xlLmxvZygnKioqKioqIEdFVCBNT05JVE9SUyAqKioqKicpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGZyb20sIHNpemUsIHNlYXJjaCwgc29ydERpcmVjdGlvbiwgc29ydEZpZWxkLCBzdGF0ZSB9ID0gcmVxLnF1ZXJ5O1xuXG4gICAgICBsZXQgbXVzdCA9IHsgbWF0Y2hfYWxsOiB7fSB9O1xuICAgICAgaWYgKHNlYXJjaC50cmltKCkpIHtcbiAgICAgICAgLy8gVGhpcyBpcyBhbiBleHBlbnNpdmUgd2lsZGNhcmQgcXVlcnkgdG8gbWF0Y2ggbW9uaXRvciBuYW1lcyBzdWNoIGFzOiBcIlRoaXMgaXMgYSBsb25nIG1vbml0b3IgbmFtZVwiXG4gICAgICAgIC8vIHNlYXJjaCBxdWVyeSA9PiBcImxvbmcgbW9uaXRcIlxuICAgICAgICAvLyBUaGlzIGlzIGFjY2VwdGFibGUgYmVjYXVzZSB3ZSB3aWxsIG5ldmVyIGFsbG93IG1vcmUgdGhhbiAxLDAwMCBtb25pdG9yc1xuICAgICAgICBtdXN0ID0ge1xuICAgICAgICAgIHF1ZXJ5X3N0cmluZzoge1xuICAgICAgICAgICAgZGVmYXVsdF9maWVsZDogJ21vbml0b3IubmFtZScsXG4gICAgICAgICAgICBkZWZhdWx0X29wZXJhdG9yOiAnQU5EJyxcbiAgICAgICAgICAgIHF1ZXJ5OiBgKiR7c2VhcmNoLnRyaW0oKS5zcGxpdCgnICcpLmpvaW4oJyogKicpfSpgLFxuICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHNob3VsZCA9IFtdO1xuICAgICAgaWYgKHN0YXRlICE9PSAnYWxsJykge1xuICAgICAgICBjb25zdCBlbmFibGVkID0gc3RhdGUgPT09ICdlbmFibGVkJztcbiAgICAgICAgc2hvdWxkLnB1c2goeyB0ZXJtOiB7ICdtb25pdG9yLmVuYWJsZWQnOiBlbmFibGVkIH0gfSk7XG4gICAgICAgIHNob3VsZC5wdXNoKHsgdGVybTogeyAnd29ya2Zsb3cuZW5hYmxlZCc6IGVuYWJsZWQgfSB9KTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgbW9uaXRvclNvcnRzID0geyBuYW1lOiAnbW9uaXRvci5uYW1lLmtleXdvcmQnIH07XG4gICAgICBjb25zdCBtb25pdG9yU29ydFBhZ2VEYXRhID0geyBzaXplOiAxMDAwIH07XG4gICAgICBpZiAobW9uaXRvclNvcnRzW3NvcnRGaWVsZF0pIHtcbiAgICAgICAgbW9uaXRvclNvcnRQYWdlRGF0YS5zb3J0ID0gW3sgW21vbml0b3JTb3J0c1tzb3J0RmllbGRdXTogc29ydERpcmVjdGlvbiB9XTtcbiAgICAgICAgbW9uaXRvclNvcnRQYWdlRGF0YS5zaXplID0gXy5kZWZhdWx0VG8oc2l6ZSwgMTAwMCk7XG4gICAgICAgIG1vbml0b3JTb3J0UGFnZURhdGEuZnJvbSA9IF8uZGVmYXVsdFRvKGZyb20sIDApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzZXFfbm9fcHJpbWFyeV90ZXJtOiB0cnVlLFxuICAgICAgICAgIHZlcnNpb246IHRydWUsXG4gICAgICAgICAgLi4ubW9uaXRvclNvcnRQYWdlRGF0YSxcbiAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICBzaG91bGQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYWdncmVnYXRpb25zOiB7XG4gICAgICAgICAgICBhc3NvY2lhdGVkX2NvbXBvc2l0ZV9tb25pdG9yczoge1xuICAgICAgICAgICAgICBuZXN0ZWQ6IHtcbiAgICAgICAgICAgICAgICBwYXRoOiAnd29ya2Zsb3cuaW5wdXRzLmNvbXBvc2l0ZV9pbnB1dC5zZXF1ZW5jZS5kZWxlZ2F0ZXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBhZ2dzOiB7XG4gICAgICAgICAgICAgICAgbW9uaXRvcl9pZHM6IHtcbiAgICAgICAgICAgICAgICAgIHRlcm1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkOiAnd29ya2Zsb3cuaW5wdXRzLmNvbXBvc2l0ZV9pbnB1dC5zZXF1ZW5jZS5kZWxlZ2F0ZXMubW9uaXRvcl9pZCcsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9O1xuXG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyOiBhbGVydGluZ0NhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBnZXRSZXNwb25zZSA9IGF3YWl0IGFsZXJ0aW5nQ2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldE1vbml0b3JzJywgcGFyYW1zKTtcblxuICAgICAgY29uc3QgdG90YWxNb25pdG9ycyA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnaGl0cy50b3RhbC52YWx1ZScsIDApO1xuICAgICAgY29uc3QgbW9uaXRvcktleVZhbHVlVHVwbGVzID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdoaXRzLmhpdHMnLCBbXSkubWFwKChyZXN1bHQpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIF9pZDogaWQsXG4gICAgICAgICAgX3ZlcnNpb246IHZlcnNpb24sXG4gICAgICAgICAgX3NlcV9ubzogaWZTZXFObyxcbiAgICAgICAgICBfcHJpbWFyeV90ZXJtOiBpZlByaW1hcnlUZXJtLFxuICAgICAgICAgIF9zb3VyY2U6IG1vbml0b3IsXG4gICAgICAgIH0gPSByZXN1bHQ7XG4gICAgICAgIGNvbnN0IHsgbmFtZSwgZW5hYmxlZCB9ID0gbW9uaXRvcjtcbiAgICAgICAgcmV0dXJuIFtpZCwgeyBpZCwgdmVyc2lvbiwgaWZTZXFObywgaWZQcmltYXJ5VGVybSwgbmFtZSwgZW5hYmxlZCwgbW9uaXRvciB9XTtcbiAgICAgIH0sIHt9KTtcbiAgICAgIGNvbnN0IG1vbml0b3JNYXAgPSBuZXcgTWFwKG1vbml0b3JLZXlWYWx1ZVR1cGxlcyk7XG4gICAgICBjb25zdCBtb25pdG9ySWRzID0gWy4uLm1vbml0b3JNYXAua2V5cygpXTtcbiAgICAgIGNvbnN0IGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ291bnRNYXAgPSB7fTtcbiAgICAgIF8uZ2V0KFxuICAgICAgICBnZXRSZXNwb25zZSxcbiAgICAgICAgJ2FnZ3JlZ2F0aW9ucy5hc3NvY2lhdGVkX2NvbXBvc2l0ZV9tb25pdG9ycy5tb25pdG9yX2lkcy5idWNrZXRzJyxcbiAgICAgICAgW11cbiAgICAgICkuZm9yRWFjaCgoeyBrZXksIGRvY19jb3VudCB9KSA9PiB7XG4gICAgICAgIGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ291bnRNYXBba2V5XSA9IGRvY19jb3VudDtcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCBhZ2dzT3JkZXJEYXRhID0ge307XG4gICAgICBjb25zdCBhZ2dzU29ydHMgPSB7XG4gICAgICAgIGFjdGl2ZTogJ2FjdGl2ZScsXG4gICAgICAgIGFja25vd2xlZGdlZDogJ2Fja25vd2xlZGdlZCcsXG4gICAgICAgIGVycm9yczogJ2Vycm9ycycsXG4gICAgICAgIGlnbm9yZWQ6ICdpZ25vcmVkJyxcbiAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWU6ICdsYXN0X25vdGlmaWNhdGlvbl90aW1lJyxcbiAgICAgIH07XG4gICAgICBpZiAoYWdnc1NvcnRzW3NvcnRGaWVsZF0pIHtcbiAgICAgICAgYWdnc09yZGVyRGF0YS5vcmRlciA9IHsgW2FnZ3NTb3J0c1tzb3J0RmllbGRdXTogc29ydERpcmVjdGlvbiB9O1xuICAgICAgfVxuICAgICAgY29uc3QgYWdnc1BhcmFtcyA9IHtcbiAgICAgICAgaW5kZXg6IElOREVYLkFMTF9BTEVSVFMsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgIHF1ZXJ5OiB7IHRlcm1zOiB7IG1vbml0b3JfaWQ6IG1vbml0b3JJZHMgfSB9LFxuICAgICAgICAgIGFnZ3JlZ2F0aW9uczoge1xuICAgICAgICAgICAgdW5pcV9tb25pdG9yX2lkczoge1xuICAgICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICAgIGZpZWxkOiAnbW9uaXRvcl9pZCcsXG4gICAgICAgICAgICAgICAgLi4uYWdnc09yZGVyRGF0YSxcbiAgICAgICAgICAgICAgICBzaXplOiBmcm9tICsgc2l6ZSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgYWdncmVnYXRpb25zOiB7XG4gICAgICAgICAgICAgICAgYWN0aXZlOiB7IGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnQUNUSVZFJyB9IH0gfSxcbiAgICAgICAgICAgICAgICBhY2tub3dsZWRnZWQ6IHsgZmlsdGVyOiB7IHRlcm06IHsgc3RhdGU6ICdBQ0tOT1dMRURHRUQnIH0gfSB9LFxuICAgICAgICAgICAgICAgIGVycm9yczogeyBmaWx0ZXI6IHsgdGVybTogeyBzdGF0ZTogJ0VSUk9SJyB9IH0gfSxcbiAgICAgICAgICAgICAgICBpZ25vcmVkOiB7XG4gICAgICAgICAgICAgICAgICBmaWx0ZXI6IHtcbiAgICAgICAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnQ09NUExFVEVEJyB9IH0sXG4gICAgICAgICAgICAgICAgICAgICAgbXVzdF9ub3Q6IHsgZXhpc3RzOiB7IGZpZWxkOiAnYWNrbm93bGVkZ2VkX3RpbWUnIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBsYXN0X25vdGlmaWNhdGlvbl90aW1lOiB7IG1heDogeyBmaWVsZDogJ2xhc3Rfbm90aWZpY2F0aW9uX3RpbWUnIH0gfSxcbiAgICAgICAgICAgICAgICBsYXRlc3RfYWxlcnQ6IHtcbiAgICAgICAgICAgICAgICAgIHRvcF9oaXRzOiB7XG4gICAgICAgICAgICAgICAgICAgIHNpemU6IDEsXG4gICAgICAgICAgICAgICAgICAgIHNvcnQ6IFt7IHN0YXJ0X3RpbWU6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgICAgICAgICAgICBfc291cmNlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgaW5jbHVkZXM6IFsnbGFzdF9ub3RpZmljYXRpb25fdGltZScsICd0cmlnZ2VyX25hbWUnXSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGVzQWdnc1Jlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldE1vbml0b3JzJywgYWdnc1BhcmFtcyk7XG4gICAgICBjb25zdCBidWNrZXRzID0gXy5nZXQoZXNBZ2dzUmVzcG9uc2UsICdhZ2dyZWdhdGlvbnMudW5pcV9tb25pdG9yX2lkcy5idWNrZXRzJywgW10pLm1hcChcbiAgICAgICAgKGJ1Y2tldCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGtleTogaWQsXG4gICAgICAgICAgICBsYXN0X25vdGlmaWNhdGlvbl90aW1lOiB7IHZhbHVlOiBsYXN0Tm90aWZpY2F0aW9uVGltZSB9LFxuICAgICAgICAgICAgaWdub3JlZDogeyBkb2NfY291bnQ6IGlnbm9yZWQgfSxcbiAgICAgICAgICAgIGFja25vd2xlZGdlZDogeyBkb2NfY291bnQ6IGFja25vd2xlZGdlZCB9LFxuICAgICAgICAgICAgYWN0aXZlOiB7IGRvY19jb3VudDogYWN0aXZlIH0sXG4gICAgICAgICAgICBlcnJvcnM6IHsgZG9jX2NvdW50OiBlcnJvcnMgfSxcbiAgICAgICAgICAgIGxhdGVzdF9hbGVydDoge1xuICAgICAgICAgICAgICBoaXRzOiB7XG4gICAgICAgICAgICAgICAgaGl0czogW1xuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBfc291cmNlOiB7IHRyaWdnZXJfbmFtZTogbGF0ZXN0QWxlcnQgfSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSA9IGJ1Y2tldDtcbiAgICAgICAgICBjb25zdCBtb25pdG9yID0gbW9uaXRvck1hcC5nZXQoaWQpO1xuICAgICAgICAgIG1vbml0b3JNYXAuZGVsZXRlKGlkKTtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4ubW9uaXRvcixcbiAgICAgICAgICAgIGlkLFxuICAgICAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWUsXG4gICAgICAgICAgICBpZ25vcmVkLFxuICAgICAgICAgICAgbGF0ZXN0QWxlcnQsXG4gICAgICAgICAgICBhY2tub3dsZWRnZWQsXG4gICAgICAgICAgICBhY3RpdmUsXG4gICAgICAgICAgICBlcnJvcnMsXG4gICAgICAgICAgICBjdXJyZW50VGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgIGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ250OiBhc3NvY2lhdGVkQ29tcG9zaXRlTW9uaXRvckNvdW50TWFwW2lkXSB8fCAwLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IHVudXNlZE1vbml0b3JzID0gWy4uLm1vbml0b3JNYXAudmFsdWVzKCldLm1hcCgobW9uaXRvcikgPT4gKHtcbiAgICAgICAgLi4ubW9uaXRvcixcbiAgICAgICAgbGFzdE5vdGlmaWNhdGlvblRpbWU6IG51bGwsXG4gICAgICAgIGlnbm9yZWQ6IDAsXG4gICAgICAgIGFjdGl2ZTogMCxcbiAgICAgICAgYWNrbm93bGVkZ2VkOiAwLFxuICAgICAgICBlcnJvcnM6IDAsXG4gICAgICAgIGxhdGVzdEFsZXJ0OiAnLS0nLFxuICAgICAgICBjdXJyZW50VGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDbnQ6IGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ291bnRNYXBbbW9uaXRvci5pZF0gfHwgMCxcbiAgICAgIH0pKTtcblxuICAgICAgbGV0IHJlc3VsdHMgPSBfLm9yZGVyQnkoYnVja2V0cy5jb25jYXQodW51c2VkTW9uaXRvcnMpLCBbc29ydEZpZWxkXSwgW3NvcnREaXJlY3Rpb25dKTtcbiAgICAgIC8vIElmIHdlIHNvcnRlZCBvbiBtb25pdG9yIG5hbWUgdGhlbiB3ZSBhbHJlYWR5IGFwcGxpZWQgZnJvbS9zaXplIHRvIHRoZSBmaXJzdCBxdWVyeSB0byBsaW1pdCB3aGF0IHdlJ3JlIGFnZ3JlZ2F0aW5nIG92ZXJcbiAgICAgIC8vIFRoZXJlZm9yZSB3ZSBkbyBub3QgbmVlZCB0byBhcHBseSBmcm9tL3NpemUgdG8gdGhpcyByZXN1bHQgc2V0XG4gICAgICAvLyBJZiB3ZSBzb3J0ZWQgb24gYWdncmVnYXRpb25zLCB0aGVuIHRoaXMgaXMgb3VyIGluIG1lbW9yeSBwYWdpbmF0aW9uXG4gICAgICBpZiAoIW1vbml0b3JTb3J0c1tzb3J0RmllbGRdKSB7XG4gICAgICAgIHJlc3VsdHMgPSByZXN1bHRzLnNsaWNlKGZyb20sIGZyb20gKyBzaXplKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICBtb25pdG9yczogcmVzdWx0cyxcbiAgICAgICAgICB0b3RhbE1vbml0b3JzLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZ2V0TW9uaXRvcnMnLCBlcnIpO1xuICAgICAgaWYgKGlzSW5kZXhOb3RGb3VuZEVycm9yKGVycikpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBvazogZmFsc2UsIHJlc3A6IHsgdG90YWxNb25pdG9yczogMCwgbW9uaXRvcnM6IFtdIH0gfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBhY2tub3dsZWRnZUFsZXJ0cyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICBtb25pdG9ySWQ6IGlkLFxuICAgICAgICBib2R5OiByZXEuYm9keSxcbiAgICAgIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBhY2tub3dsZWRnZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmFja25vd2xlZGdlQWxlcnRzJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6ICFhY2tub3dsZWRnZVJlc3BvbnNlLmZhaWxlZC5sZW5ndGgsXG4gICAgICAgICAgcmVzcDogYWNrbm93bGVkZ2VSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGFja25vd2xlZGdlQWxlcnRzOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBleGVjdXRlTW9uaXRvciA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRyeXJ1biA9ICd0cnVlJyB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICBib2R5OiByZXEuYm9keSxcbiAgICAgICAgZHJ5cnVuLFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGV4ZWN1dGVSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5leGVjdXRlTW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IGV4ZWN1dGVSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGV4ZWN1dGVNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICAvL1RPRE86IFRoaXMgaXMgdGVtcG9yYXJpbHkgYSBwYXNzIHRocm91Z2ggY2FsbCB3aGljaCBuZWVkcyB0byBiZSBkZXByZWNhdGVkXG4gIHNlYXJjaE1vbml0b3JzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgcXVlcnksIGluZGV4LCBzaXplIH0gPSByZXEuYm9keTtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgaW5kZXgsIHNpemUsIGJvZHk6IHF1ZXJ5IH07XG5cbiAgICAgIGNvbnNvbGUubG9nKCdTZWFyY2ggbW9uaXRvcnMgKioqKioqKiAnKTtcbiAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHBhcmFtcykpO1xuXG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldE1vbml0b3JzJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogcmVzdWx0cyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIHNlYXJjaE1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xufVxuIl19