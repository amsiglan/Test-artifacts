"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _lodash = _interopRequireDefault(require("lodash"));

var _constants = require("../../utils/constants");

var _helpers = require("./utils/helpers");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class MonitorService {
  constructor(esDriver) {
    _defineProperty(this, "createMonitor", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "createWorkflow", async (context, req, res) => {
      try {
        const params = {
          body: req.body
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const createResponse = await callAsCurrentUser('alerting.createWorkflow', params);
        return res.ok({
          body: {
            ok: true,
            resp: createResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - createWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteMonitor', params);
        console.log('Delete monitor response');
        console.log(JSON.stringify(response));
        return res.ok({
          body: {
            ok: response.result === 'deleted' || response.result === undefined
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "deleteWorkflow", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          workflowId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const response = await callAsCurrentUser('alerting.deleteWorkflow', params);
        console.log('delete workflow response ^*^*^*^*^*');
        console.log(JSON.stringify(response));
        return res.ok({
          body: {
            ok: response.result === 'deleted' || response.result === undefined
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - deleteWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitor", async (context, req, res) => {
      console.log('****** GET MONITOR *****');

      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getMonitor', params);
        console.log('Get monitor complete response ^^^^^^^^^');
        console.log(JSON.stringify(getResponse));

        let monitor = _lodash.default.get(getResponse, 'monitor', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        const associated_workflows = _lodash.default.get(getResponse, 'associated_workflows', null);

        if (monitor) {
          const {
            callAsCurrentUser
          } = this.esDriver.asScoped(req);
          const aggsParams = {
            index: _constants.INDEX.ALL_ALERTS,
            body: {
              size: 0,
              query: {
                bool: {
                  must: {
                    term: {
                      monitor_id: id
                    }
                  }
                }
              },
              aggs: {
                active_count: {
                  terms: {
                    field: 'state'
                  }
                },
                '24_hour_count': {
                  date_range: {
                    field: 'start_time',
                    ranges: [{
                      from: 'now-24h/h'
                    }]
                  }
                }
              }
            }
          };
          const searchResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

          const dayCount = _lodash.default.get(searchResponse, 'aggregations.24_hour_count.buckets.0.doc_count', 0);

          const activeBuckets = _lodash.default.get(searchResponse, 'aggregations.active_count.buckets', []);

          const activeCount = activeBuckets.reduce((acc, curr) => curr.key === 'ACTIVE' ? curr.doc_count : acc, 0);

          if (associated_workflows) {
            monitor = { ...monitor,
              associated_workflows
            };
          }

          monitor = { ...monitor,
            item_type: monitor.workflow_type || monitor.monitor_type,
            id,
            version
          };
          return res.ok({
            body: {
              ok: true,
              resp: monitor,
              activeCount,
              dayCount,
              version,
              ifSeqNo,
              ifPrimaryTerm
            }
          });
        } else {
          return res.ok({
            body: {
              ok: false
            }
          });
        }
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getWorkflow", async (context, req, res) => {
      console.log('****** GET WORKFLOW *****');

      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await callAsCurrentUser('alerting.getWorkflow', params);

        let workflow = _lodash.default.get(getResponse, 'workflow', null);

        const version = _lodash.default.get(getResponse, '_version', null);

        const ifSeqNo = _lodash.default.get(getResponse, '_seq_no', null);

        const ifPrimaryTerm = _lodash.default.get(getResponse, '_primary_term', null);

        workflow.monitor_type = workflow.workflow_type;
        workflow = { ...workflow,
          item_type: workflow.workflow_type,
          id,
          version
        };
        return res.ok({
          body: {
            ok: true,
            resp: workflow,
            activeCount: 0,
            dayCount: 0,
            version,
            ifSeqNo,
            ifPrimaryTerm
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getWorkflow:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "updateMonitor", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body,
          refresh: 'wait_for'
        };
        const {
          type
        } = req.body; // TODO DRAFT: Are we sure we need to include ifSeqNo and ifPrimaryTerm from the UI side when updating monitors?

        const {
          ifSeqNo,
          ifPrimaryTerm
        } = req.query;

        if (ifSeqNo && ifPrimaryTerm) {
          params.if_seq_no = ifSeqNo;
          params.if_primary_term = ifPrimaryTerm;
        }

        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const updateResponse = await callAsCurrentUser(`alerting.${type === 'workflow' ? 'updateWorkflow' : 'updateMonitor'}`, params);
        const {
          _version,
          _id
        } = updateResponse;
        return res.ok({
          body: {
            ok: true,
            version: _version,
            id: _id
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - updateMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "getMonitors", async (context, req, res) => {
      console.log('****** GET MONITORS *****');

      try {
        const {
          from,
          size,
          search,
          sortDirection,
          sortField,
          state
        } = req.query;
        let must = {
          match_all: {}
        };

        if (search.trim()) {
          // This is an expensive wildcard query to match monitor names such as: "This is a long monitor name"
          // search query => "long monit"
          // This is acceptable because we will never allow more than 1,000 monitors
          must = {
            query_string: {
              default_field: 'monitor.name',
              default_operator: 'AND',
              query: `*${search.trim().split(' ').join('* *')}*`
            }
          };
        }

        const should = [];

        if (state !== 'all') {
          const enabled = state === 'enabled';
          should.push({
            term: {
              'monitor.enabled': enabled
            }
          });
          should.push({
            term: {
              'workflow.enabled': enabled
            }
          });
        }

        const monitorSorts = {
          name: 'monitor.name.keyword'
        };
        const monitorSortPageData = {
          size: 1000
        };

        if (monitorSorts[sortField]) {
          monitorSortPageData.sort = [{
            [monitorSorts[sortField]]: sortDirection
          }];
          monitorSortPageData.size = _lodash.default.defaultTo(size, 1000);
          monitorSortPageData.from = _lodash.default.defaultTo(from, 0);
        }

        const params = {
          body: {
            seq_no_primary_term: true,
            version: true,
            ...monitorSortPageData,
            query: {
              bool: {
                should
              }
            },
            aggregations: {
              associated_composite_monitors: {
                nested: {
                  path: 'workflow.inputs.composite_input.sequence.delegates'
                },
                aggs: {
                  monitor_ids: {
                    terms: {
                      field: 'workflow.inputs.composite_input.sequence.delegates.monitor_id'
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser: alertingCallAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const getResponse = await alertingCallAsCurrentUser('alerting.getMonitors', params);

        const totalMonitors = _lodash.default.get(getResponse, 'hits.total.value', 0);

        const monitorKeyValueTuples = _lodash.default.get(getResponse, 'hits.hits', []).map(result => {
          const {
            _id: id,
            _version: version,
            _seq_no: ifSeqNo,
            _primary_term: ifPrimaryTerm,
            _source: monitor
          } = result;
          const {
            name,
            enabled
          } = monitor;
          return [id, {
            id,
            version,
            ifSeqNo,
            ifPrimaryTerm,
            name,
            enabled,
            monitor
          }];
        }, {});

        const monitorMap = new Map(monitorKeyValueTuples);
        const monitorIds = [...monitorMap.keys()];
        const associatedCompositeMonitorCountMap = {};

        _lodash.default.get(getResponse, 'aggregations.associated_composite_monitors.monitor_ids.buckets', []).forEach(({
          key,
          doc_count
        }) => {
          associatedCompositeMonitorCountMap[key] = doc_count;
        });

        const aggsOrderData = {};
        const aggsSorts = {
          active: 'active',
          acknowledged: 'acknowledged',
          errors: 'errors',
          ignored: 'ignored',
          lastNotificationTime: 'last_notification_time'
        };

        if (aggsSorts[sortField]) {
          aggsOrderData.order = {
            [aggsSorts[sortField]]: sortDirection
          };
        }

        const aggsParams = {
          index: _constants.INDEX.ALL_ALERTS,
          body: {
            size: 0,
            query: {
              terms: {
                monitor_id: monitorIds
              }
            },
            aggregations: {
              uniq_monitor_ids: {
                terms: {
                  field: 'monitor_id',
                  ...aggsOrderData,
                  size: from + size
                },
                aggregations: {
                  active: {
                    filter: {
                      term: {
                        state: 'ACTIVE'
                      }
                    }
                  },
                  acknowledged: {
                    filter: {
                      term: {
                        state: 'ACKNOWLEDGED'
                      }
                    }
                  },
                  errors: {
                    filter: {
                      term: {
                        state: 'ERROR'
                      }
                    }
                  },
                  ignored: {
                    filter: {
                      bool: {
                        filter: {
                          term: {
                            state: 'COMPLETED'
                          }
                        },
                        must_not: {
                          exists: {
                            field: 'acknowledged_time'
                          }
                        }
                      }
                    }
                  },
                  last_notification_time: {
                    max: {
                      field: 'last_notification_time'
                    }
                  },
                  latest_alert: {
                    top_hits: {
                      size: 1,
                      sort: [{
                        start_time: {
                          order: 'desc'
                        }
                      }],
                      _source: {
                        includes: ['last_notification_time', 'trigger_name']
                      }
                    }
                  }
                }
              }
            }
          }
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const esAggsResponse = await callAsCurrentUser('alerting.getMonitors', aggsParams);

        const buckets = _lodash.default.get(esAggsResponse, 'aggregations.uniq_monitor_ids.buckets', []).map(bucket => {
          const {
            key: id,
            last_notification_time: {
              value: lastNotificationTime
            },
            ignored: {
              doc_count: ignored
            },
            acknowledged: {
              doc_count: acknowledged
            },
            active: {
              doc_count: active
            },
            errors: {
              doc_count: errors
            },
            latest_alert: {
              hits: {
                hits: [{
                  _source: {
                    trigger_name: latestAlert
                  }
                }]
              }
            }
          } = bucket;
          const monitor = monitorMap.get(id);
          monitorMap.delete(id);
          return { ...monitor,
            id,
            lastNotificationTime,
            ignored,
            latestAlert,
            acknowledged,
            active,
            errors,
            currentTime: Date.now(),
            associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[id] || 0
          };
        });

        const unusedMonitors = [...monitorMap.values()].map(monitor => ({ ...monitor,
          lastNotificationTime: null,
          ignored: 0,
          active: 0,
          acknowledged: 0,
          errors: 0,
          latestAlert: '--',
          currentTime: Date.now(),
          associatedCompositeMonitorCnt: associatedCompositeMonitorCountMap[monitor.id] || 0
        }));

        let results = _lodash.default.orderBy(buckets.concat(unusedMonitors), [sortField], [sortDirection]); // If we sorted on monitor name then we already applied from/size to the first query to limit what we're aggregating over
        // Therefore we do not need to apply from/size to this result set
        // If we sorted on aggregations, then this is our in memory pagination


        if (!monitorSorts[sortField]) {
          results = results.slice(from, from + size);
        }

        return res.ok({
          body: {
            ok: true,
            monitors: results,
            totalMonitors
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - getMonitors', err);

        if ((0, _helpers.isIndexNotFoundError)(err)) {
          return res.ok({
            body: {
              ok: false,
              resp: {
                totalMonitors: 0,
                monitors: []
              }
            }
          });
        }

        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "acknowledgeAlerts", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          monitorId: id,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const acknowledgeResponse = await callAsCurrentUser('alerting.acknowledgeAlerts', params);
        return res.ok({
          body: {
            ok: !acknowledgeResponse.failed.length,
            resp: acknowledgeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - acknowledgeAlerts:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "acknowledgeChainedAlerts", async (context, req, res) => {
      try {
        const {
          id
        } = req.params;
        const params = {
          workflowId: id,
          body: req.body
        };
        const {
          callAsCurrentUser
        } = this.esDriver.asScoped(req);
        const acknowledgeResponse = await callAsCurrentUser('alerting.acknowledgeChainedAlerts', params);
        return res.ok({
          body: {
            ok: !acknowledgeResponse.failed.length,
            resp: acknowledgeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - acknowledgeChainedAlerts:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "executeMonitor", async (context, req, res) => {
      try {
        const {
          dryrun = 'true'
        } = req.query;
        const params = {
          body: req.body,
          dryrun
        };
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const executeResponse = await callAsCurrentUser('alerting.executeMonitor', params);
        return res.ok({
          body: {
            ok: true,
            resp: executeResponse
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - executeMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    _defineProperty(this, "searchMonitors", async (context, req, res) => {
      try {
        const {
          query,
          index,
          size
        } = req.body;
        const params = {
          index,
          size,
          body: query
        };
        console.log('Search monitors ******* ');
        console.log(JSON.stringify(params));
        const {
          callAsCurrentUser
        } = await this.esDriver.asScoped(req);
        const results = await callAsCurrentUser('alerting.getMonitors', params);
        return res.ok({
          body: {
            ok: true,
            resp: results
          }
        });
      } catch (err) {
        console.error('Alerting - MonitorService - searchMonitor:', err);
        return res.ok({
          body: {
            ok: false,
            resp: err.message
          }
        });
      }
    });

    this.esDriver = esDriver;
  }

}

exports.default = MonitorService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk1vbml0b3JTZXJ2aWNlLmpzIl0sIm5hbWVzIjpbIk1vbml0b3JTZXJ2aWNlIiwiY29uc3RydWN0b3IiLCJlc0RyaXZlciIsImNvbnRleHQiLCJyZXEiLCJyZXMiLCJwYXJhbXMiLCJib2R5IiwiY2FsbEFzQ3VycmVudFVzZXIiLCJhc1Njb3BlZCIsImNyZWF0ZVJlc3BvbnNlIiwib2siLCJyZXNwIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibWVzc2FnZSIsImlkIiwibW9uaXRvcklkIiwicmVzcG9uc2UiLCJsb2ciLCJKU09OIiwic3RyaW5naWZ5IiwicmVzdWx0IiwidW5kZWZpbmVkIiwid29ya2Zsb3dJZCIsImdldFJlc3BvbnNlIiwibW9uaXRvciIsIl8iLCJnZXQiLCJ2ZXJzaW9uIiwiaWZTZXFObyIsImlmUHJpbWFyeVRlcm0iLCJhc3NvY2lhdGVkX3dvcmtmbG93cyIsImFnZ3NQYXJhbXMiLCJpbmRleCIsIklOREVYIiwiQUxMX0FMRVJUUyIsInNpemUiLCJxdWVyeSIsImJvb2wiLCJtdXN0IiwidGVybSIsIm1vbml0b3JfaWQiLCJhZ2dzIiwiYWN0aXZlX2NvdW50IiwidGVybXMiLCJmaWVsZCIsImRhdGVfcmFuZ2UiLCJyYW5nZXMiLCJmcm9tIiwic2VhcmNoUmVzcG9uc2UiLCJkYXlDb3VudCIsImFjdGl2ZUJ1Y2tldHMiLCJhY3RpdmVDb3VudCIsInJlZHVjZSIsImFjYyIsImN1cnIiLCJrZXkiLCJkb2NfY291bnQiLCJpdGVtX3R5cGUiLCJ3b3JrZmxvd190eXBlIiwibW9uaXRvcl90eXBlIiwid29ya2Zsb3ciLCJyZWZyZXNoIiwidHlwZSIsImlmX3NlcV9ubyIsImlmX3ByaW1hcnlfdGVybSIsInVwZGF0ZVJlc3BvbnNlIiwiX3ZlcnNpb24iLCJfaWQiLCJzZWFyY2giLCJzb3J0RGlyZWN0aW9uIiwic29ydEZpZWxkIiwic3RhdGUiLCJtYXRjaF9hbGwiLCJ0cmltIiwicXVlcnlfc3RyaW5nIiwiZGVmYXVsdF9maWVsZCIsImRlZmF1bHRfb3BlcmF0b3IiLCJzcGxpdCIsImpvaW4iLCJzaG91bGQiLCJlbmFibGVkIiwicHVzaCIsIm1vbml0b3JTb3J0cyIsIm5hbWUiLCJtb25pdG9yU29ydFBhZ2VEYXRhIiwic29ydCIsImRlZmF1bHRUbyIsInNlcV9ub19wcmltYXJ5X3Rlcm0iLCJhZ2dyZWdhdGlvbnMiLCJhc3NvY2lhdGVkX2NvbXBvc2l0ZV9tb25pdG9ycyIsIm5lc3RlZCIsInBhdGgiLCJtb25pdG9yX2lkcyIsImFsZXJ0aW5nQ2FsbEFzQ3VycmVudFVzZXIiLCJ0b3RhbE1vbml0b3JzIiwibW9uaXRvcktleVZhbHVlVHVwbGVzIiwibWFwIiwiX3NlcV9ubyIsIl9wcmltYXJ5X3Rlcm0iLCJfc291cmNlIiwibW9uaXRvck1hcCIsIk1hcCIsIm1vbml0b3JJZHMiLCJrZXlzIiwiYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcCIsImZvckVhY2giLCJhZ2dzT3JkZXJEYXRhIiwiYWdnc1NvcnRzIiwiYWN0aXZlIiwiYWNrbm93bGVkZ2VkIiwiZXJyb3JzIiwiaWdub3JlZCIsImxhc3ROb3RpZmljYXRpb25UaW1lIiwib3JkZXIiLCJ1bmlxX21vbml0b3JfaWRzIiwiZmlsdGVyIiwibXVzdF9ub3QiLCJleGlzdHMiLCJsYXN0X25vdGlmaWNhdGlvbl90aW1lIiwibWF4IiwibGF0ZXN0X2FsZXJ0IiwidG9wX2hpdHMiLCJzdGFydF90aW1lIiwiaW5jbHVkZXMiLCJlc0FnZ3NSZXNwb25zZSIsImJ1Y2tldHMiLCJidWNrZXQiLCJ2YWx1ZSIsImhpdHMiLCJ0cmlnZ2VyX25hbWUiLCJsYXRlc3RBbGVydCIsImRlbGV0ZSIsImN1cnJlbnRUaW1lIiwiRGF0ZSIsIm5vdyIsImFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ250IiwidW51c2VkTW9uaXRvcnMiLCJ2YWx1ZXMiLCJyZXN1bHRzIiwib3JkZXJCeSIsImNvbmNhdCIsInNsaWNlIiwibW9uaXRvcnMiLCJhY2tub3dsZWRnZVJlc3BvbnNlIiwiZmFpbGVkIiwibGVuZ3RoIiwiZHJ5cnVuIiwiZXhlY3V0ZVJlc3BvbnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBS0E7O0FBRUE7O0FBQ0E7Ozs7OztBQUVlLE1BQU1BLGNBQU4sQ0FBcUI7QUFDbENDLEVBQUFBLFdBQVcsQ0FBQ0MsUUFBRCxFQUFXO0FBQUEsMkNBSU4sT0FBT0MsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNQyxNQUFNLEdBQUc7QUFBRUMsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBQVosU0FBZjtBQUNBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNTSxjQUFjLEdBQUcsTUFBTUYsaUJBQWlCLENBQUMsd0JBQUQsRUFBMkJGLE1BQTNCLENBQTlDO0FBQ0EsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUY7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BVkQsQ0FVRSxPQUFPRyxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNENBQWQsRUFBNERGLEdBQTVEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXhCcUI7O0FBQUEsNENBMEJMLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUM1QyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxHQUFHO0FBQUVDLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRztBQUFaLFNBQWY7QUFDQSxjQUFNO0FBQUVDLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTU0sY0FBYyxHQUFHLE1BQU1GLGlCQUFpQixDQUFDLHlCQUFELEVBQTRCRixNQUE1QixDQUE5QztBQUNBLGVBQU9ELEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVGO0FBRkY7QUFETSxTQUFQLENBQVA7QUFNRCxPQVZELENBVUUsT0FBT0csR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDZDQUFkLEVBQTZERixHQUE3RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0E5Q3FCOztBQUFBLDJDQWdETixPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDM0MsVUFBSTtBQUNGLGNBQU07QUFBRVksVUFBQUE7QUFBRixZQUFTYixHQUFHLENBQUNFLE1BQW5CO0FBQ0EsY0FBTUEsTUFBTSxHQUFHO0FBQUVZLFVBQUFBLFNBQVMsRUFBRUQ7QUFBYixTQUFmO0FBQ0EsY0FBTTtBQUFFVCxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU1lLFFBQVEsR0FBRyxNQUFNWCxpQkFBaUIsQ0FBQyx3QkFBRCxFQUEyQkYsTUFBM0IsQ0FBeEM7QUFDQVEsUUFBQUEsT0FBTyxDQUFDTSxHQUFSLENBQVkseUJBQVo7QUFDQU4sUUFBQUEsT0FBTyxDQUFDTSxHQUFSLENBQVlDLElBQUksQ0FBQ0MsU0FBTCxDQUFlSCxRQUFmLENBQVo7QUFDQSxlQUFPZCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFUSxRQUFRLENBQUNJLE1BQVQsS0FBb0IsU0FBcEIsSUFBaUNKLFFBQVEsQ0FBQ0ksTUFBVCxLQUFvQkM7QUFEckQ7QUFETSxTQUFQLENBQVA7QUFLRCxPQVpELENBWUUsT0FBT1gsR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDRDQUFkLEVBQTRERixHQUE1RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0F0RXFCOztBQUFBLDRDQXdFTCxPQUFPYixPQUFQLEVBQWdCQyxHQUFoQixFQUFxQkMsR0FBckIsS0FBNkI7QUFDNUMsVUFBSTtBQUNGLGNBQU07QUFBRVksVUFBQUE7QUFBRixZQUFTYixHQUFHLENBQUNFLE1BQW5CO0FBQ0EsY0FBTUEsTUFBTSxHQUFHO0FBQUVtQixVQUFBQSxVQUFVLEVBQUVSO0FBQWQsU0FBZjtBQUNBLGNBQU07QUFBRVQsVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNZSxRQUFRLEdBQUcsTUFBTVgsaUJBQWlCLENBQUMseUJBQUQsRUFBNEJGLE1BQTVCLENBQXhDO0FBQ0FRLFFBQUFBLE9BQU8sQ0FBQ00sR0FBUixDQUFZLHFDQUFaO0FBQ0FOLFFBQUFBLE9BQU8sQ0FBQ00sR0FBUixDQUFZQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUgsUUFBZixDQUFaO0FBQ0EsZUFBT2QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRVEsUUFBUSxDQUFDSSxNQUFULEtBQW9CLFNBQXBCLElBQWlDSixRQUFRLENBQUNJLE1BQVQsS0FBb0JDO0FBRHJEO0FBRE0sU0FBUCxDQUFQO0FBS0QsT0FaRCxDQVlFLE9BQU9YLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw2Q0FBZCxFQUE2REYsR0FBN0Q7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBOUZxQjs7QUFBQSx3Q0FnR1QsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3hDUyxNQUFBQSxPQUFPLENBQUNNLEdBQVIsQ0FBWSwwQkFBWjs7QUFDQSxVQUFJO0FBQ0YsY0FBTTtBQUFFSCxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRVksVUFBQUEsU0FBUyxFQUFFRDtBQUFiLFNBQWY7QUFDQSxjQUFNO0FBQUVULFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTXNCLFdBQVcsR0FBRyxNQUFNbEIsaUJBQWlCLENBQUMscUJBQUQsRUFBd0JGLE1BQXhCLENBQTNDO0FBQ0FRLFFBQUFBLE9BQU8sQ0FBQ00sR0FBUixDQUFZLHlDQUFaO0FBQ0FOLFFBQUFBLE9BQU8sQ0FBQ00sR0FBUixDQUFZQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUksV0FBZixDQUFaOztBQUNBLFlBQUlDLE9BQU8sR0FBR0MsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixTQUFuQixFQUE4QixJQUE5QixDQUFkOztBQUNBLGNBQU1JLE9BQU8sR0FBR0YsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixVQUFuQixFQUErQixJQUEvQixDQUFoQjs7QUFDQSxjQUFNSyxPQUFPLEdBQUdILGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsU0FBbkIsRUFBOEIsSUFBOUIsQ0FBaEI7O0FBQ0EsY0FBTU0sYUFBYSxHQUFHSixnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLGVBQW5CLEVBQW9DLElBQXBDLENBQXRCOztBQUNBLGNBQU1PLG9CQUFvQixHQUFHTCxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLHNCQUFuQixFQUEyQyxJQUEzQyxDQUE3Qjs7QUFDQSxZQUFJQyxPQUFKLEVBQWE7QUFDWCxnQkFBTTtBQUFFbkIsWUFBQUE7QUFBRixjQUF3QixLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQTlCO0FBQ0EsZ0JBQU04QixVQUFVLEdBQUc7QUFDakJDLFlBQUFBLEtBQUssRUFBRUMsaUJBQU1DLFVBREk7QUFFakI5QixZQUFBQSxJQUFJLEVBQUU7QUFDSitCLGNBQUFBLElBQUksRUFBRSxDQURGO0FBRUpDLGNBQUFBLEtBQUssRUFBRTtBQUNMQyxnQkFBQUEsSUFBSSxFQUFFO0FBQ0pDLGtCQUFBQSxJQUFJLEVBQUU7QUFDSkMsb0JBQUFBLElBQUksRUFBRTtBQUNKQyxzQkFBQUEsVUFBVSxFQUFFMUI7QUFEUjtBQURGO0FBREY7QUFERCxlQUZIO0FBV0oyQixjQUFBQSxJQUFJLEVBQUU7QUFDSkMsZ0JBQUFBLFlBQVksRUFBRTtBQUNaQyxrQkFBQUEsS0FBSyxFQUFFO0FBQ0xDLG9CQUFBQSxLQUFLLEVBQUU7QUFERjtBQURLLGlCQURWO0FBTUosaUNBQWlCO0FBQ2ZDLGtCQUFBQSxVQUFVLEVBQUU7QUFDVkQsb0JBQUFBLEtBQUssRUFBRSxZQURHO0FBRVZFLG9CQUFBQSxNQUFNLEVBQUUsQ0FBQztBQUFFQyxzQkFBQUEsSUFBSSxFQUFFO0FBQVIscUJBQUQ7QUFGRTtBQURHO0FBTmI7QUFYRjtBQUZXLFdBQW5CO0FBNEJBLGdCQUFNQyxjQUFjLEdBQUcsTUFBTTNDLGlCQUFpQixDQUFDLHNCQUFELEVBQXlCMEIsVUFBekIsQ0FBOUM7O0FBQ0EsZ0JBQU1rQixRQUFRLEdBQUd4QixnQkFBRUMsR0FBRixDQUFNc0IsY0FBTixFQUFzQixnREFBdEIsRUFBd0UsQ0FBeEUsQ0FBakI7O0FBQ0EsZ0JBQU1FLGFBQWEsR0FBR3pCLGdCQUFFQyxHQUFGLENBQU1zQixjQUFOLEVBQXNCLG1DQUF0QixFQUEyRCxFQUEzRCxDQUF0Qjs7QUFDQSxnQkFBTUcsV0FBVyxHQUFHRCxhQUFhLENBQUNFLE1BQWQsQ0FDbEIsQ0FBQ0MsR0FBRCxFQUFNQyxJQUFOLEtBQWdCQSxJQUFJLENBQUNDLEdBQUwsS0FBYSxRQUFiLEdBQXdCRCxJQUFJLENBQUNFLFNBQTdCLEdBQXlDSCxHQUR2QyxFQUVsQixDQUZrQixDQUFwQjs7QUFJQSxjQUFJdkIsb0JBQUosRUFBMEI7QUFDeEJOLFlBQUFBLE9BQU8sR0FBRyxFQUNSLEdBQUdBLE9BREs7QUFFUk0sY0FBQUE7QUFGUSxhQUFWO0FBSUQ7O0FBQ0ROLFVBQUFBLE9BQU8sR0FBRyxFQUNSLEdBQUdBLE9BREs7QUFFUmlDLFlBQUFBLFNBQVMsRUFBRWpDLE9BQU8sQ0FBQ2tDLGFBQVIsSUFBeUJsQyxPQUFPLENBQUNtQyxZQUZwQztBQUdSN0MsWUFBQUEsRUFIUTtBQUlSYSxZQUFBQTtBQUpRLFdBQVY7QUFNQSxpQkFBT3pCLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFlBQUFBLElBQUksRUFBRTtBQUFFSSxjQUFBQSxFQUFFLEVBQUUsSUFBTjtBQUFZQyxjQUFBQSxJQUFJLEVBQUVlLE9BQWxCO0FBQTJCMkIsY0FBQUEsV0FBM0I7QUFBd0NGLGNBQUFBLFFBQXhDO0FBQWtEdEIsY0FBQUEsT0FBbEQ7QUFBMkRDLGNBQUFBLE9BQTNEO0FBQW9FQyxjQUFBQTtBQUFwRTtBQURNLFdBQVAsQ0FBUDtBQUdELFNBcERELE1Bb0RPO0FBQ0wsaUJBQU8zQixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFDSkksY0FBQUEsRUFBRSxFQUFFO0FBREE7QUFETSxXQUFQLENBQVA7QUFLRDtBQUNGLE9BdkVELENBdUVFLE9BQU9FLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyx5Q0FBZCxFQUF5REYsR0FBekQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBbExxQjs7QUFBQSx5Q0FvTFIsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3pDUyxNQUFBQSxPQUFPLENBQUNNLEdBQVIsQ0FBWSwyQkFBWjs7QUFDQSxVQUFJO0FBQ0YsY0FBTTtBQUFFSCxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFBRVksVUFBQUEsU0FBUyxFQUFFRDtBQUFiLFNBQWY7QUFDQSxjQUFNO0FBQUVULFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTXNCLFdBQVcsR0FBRyxNQUFNbEIsaUJBQWlCLENBQUMsc0JBQUQsRUFBeUJGLE1BQXpCLENBQTNDOztBQUNBLFlBQUl5RCxRQUFRLEdBQUduQyxnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFVBQW5CLEVBQStCLElBQS9CLENBQWY7O0FBQ0EsY0FBTUksT0FBTyxHQUFHRixnQkFBRUMsR0FBRixDQUFNSCxXQUFOLEVBQW1CLFVBQW5CLEVBQStCLElBQS9CLENBQWhCOztBQUNBLGNBQU1LLE9BQU8sR0FBR0gsZ0JBQUVDLEdBQUYsQ0FBTUgsV0FBTixFQUFtQixTQUFuQixFQUE4QixJQUE5QixDQUFoQjs7QUFDQSxjQUFNTSxhQUFhLEdBQUdKLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsZUFBbkIsRUFBb0MsSUFBcEMsQ0FBdEI7O0FBQ0FxQyxRQUFBQSxRQUFRLENBQUNELFlBQVQsR0FBd0JDLFFBQVEsQ0FBQ0YsYUFBakM7QUFDQUUsUUFBQUEsUUFBUSxHQUFHLEVBQ1QsR0FBR0EsUUFETTtBQUVUSCxVQUFBQSxTQUFTLEVBQUVHLFFBQVEsQ0FBQ0YsYUFGWDtBQUdUNUMsVUFBQUEsRUFIUztBQUlUYSxVQUFBQTtBQUpTLFNBQVg7QUFPQSxlQUFPekIsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRW1ELFFBRkY7QUFHSlQsWUFBQUEsV0FBVyxFQUFFLENBSFQ7QUFJSkYsWUFBQUEsUUFBUSxFQUFFLENBSk47QUFLSnRCLFlBQUFBLE9BTEk7QUFNSkMsWUFBQUEsT0FOSTtBQU9KQyxZQUFBQTtBQVBJO0FBRE0sU0FBUCxDQUFQO0FBV0QsT0E1QkQsQ0E0QkUsT0FBT25CLEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYywwQ0FBZCxFQUEwREYsR0FBMUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBM05xQjs7QUFBQSwyQ0E2Tk4sT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzNDLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUFFWSxVQUFBQSxTQUFTLEVBQUVELEVBQWI7QUFBaUJWLFVBQUFBLElBQUksRUFBRUgsR0FBRyxDQUFDRyxJQUEzQjtBQUFpQ3lELFVBQUFBLE9BQU8sRUFBRTtBQUExQyxTQUFmO0FBQ0EsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQVc3RCxHQUFHLENBQUNHLElBQXJCLENBSEUsQ0FLRjs7QUFDQSxjQUFNO0FBQUV3QixVQUFBQSxPQUFGO0FBQVdDLFVBQUFBO0FBQVgsWUFBNkI1QixHQUFHLENBQUNtQyxLQUF2Qzs7QUFDQSxZQUFJUixPQUFPLElBQUlDLGFBQWYsRUFBOEI7QUFDNUIxQixVQUFBQSxNQUFNLENBQUM0RCxTQUFQLEdBQW1CbkMsT0FBbkI7QUFDQXpCLFVBQUFBLE1BQU0sQ0FBQzZELGVBQVAsR0FBeUJuQyxhQUF6QjtBQUNEOztBQUVELGNBQU07QUFBRXhCLFVBQUFBO0FBQUYsWUFBd0IsTUFBTSxLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQXBDO0FBQ0EsY0FBTWdFLGNBQWMsR0FBRyxNQUFNNUQsaUJBQWlCLENBQzNDLFlBQVd5RCxJQUFJLEtBQUssVUFBVCxHQUFzQixnQkFBdEIsR0FBeUMsZUFBZ0IsRUFEekIsRUFFNUMzRCxNQUY0QyxDQUE5QztBQUlBLGNBQU07QUFBRStELFVBQUFBLFFBQUY7QUFBWUMsVUFBQUE7QUFBWixZQUFvQkYsY0FBMUI7QUFDQSxlQUFPL0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxJQURBO0FBRUptQixZQUFBQSxPQUFPLEVBQUV1QyxRQUZMO0FBR0pwRCxZQUFBQSxFQUFFLEVBQUVxRDtBQUhBO0FBRE0sU0FBUCxDQUFQO0FBT0QsT0F6QkQsQ0F5QkUsT0FBT3pELEdBQVAsRUFBWTtBQUNaQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyw0Q0FBZCxFQUE0REYsR0FBNUQ7QUFDQSxlQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBaFFxQjs7QUFBQSx5Q0FrUVIsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQ3pDUyxNQUFBQSxPQUFPLENBQUNNLEdBQVIsQ0FBWSwyQkFBWjs7QUFDQSxVQUFJO0FBQ0YsY0FBTTtBQUFFOEIsVUFBQUEsSUFBRjtBQUFRWixVQUFBQSxJQUFSO0FBQWNpQyxVQUFBQSxNQUFkO0FBQXNCQyxVQUFBQSxhQUF0QjtBQUFxQ0MsVUFBQUEsU0FBckM7QUFBZ0RDLFVBQUFBO0FBQWhELFlBQTBEdEUsR0FBRyxDQUFDbUMsS0FBcEU7QUFFQSxZQUFJRSxJQUFJLEdBQUc7QUFBRWtDLFVBQUFBLFNBQVMsRUFBRTtBQUFiLFNBQVg7O0FBQ0EsWUFBSUosTUFBTSxDQUFDSyxJQUFQLEVBQUosRUFBbUI7QUFDakI7QUFDQTtBQUNBO0FBQ0FuQyxVQUFBQSxJQUFJLEdBQUc7QUFDTG9DLFlBQUFBLFlBQVksRUFBRTtBQUNaQyxjQUFBQSxhQUFhLEVBQUUsY0FESDtBQUVaQyxjQUFBQSxnQkFBZ0IsRUFBRSxLQUZOO0FBR1p4QyxjQUFBQSxLQUFLLEVBQUcsSUFBR2dDLE1BQU0sQ0FBQ0ssSUFBUCxHQUFjSSxLQUFkLENBQW9CLEdBQXBCLEVBQXlCQyxJQUF6QixDQUE4QixLQUE5QixDQUFxQztBQUhwQztBQURULFdBQVA7QUFPRDs7QUFFRCxjQUFNQyxNQUFNLEdBQUcsRUFBZjs7QUFDQSxZQUFJUixLQUFLLEtBQUssS0FBZCxFQUFxQjtBQUNuQixnQkFBTVMsT0FBTyxHQUFHVCxLQUFLLEtBQUssU0FBMUI7QUFDQVEsVUFBQUEsTUFBTSxDQUFDRSxJQUFQLENBQVk7QUFBRTFDLFlBQUFBLElBQUksRUFBRTtBQUFFLGlDQUFtQnlDO0FBQXJCO0FBQVIsV0FBWjtBQUNBRCxVQUFBQSxNQUFNLENBQUNFLElBQVAsQ0FBWTtBQUFFMUMsWUFBQUEsSUFBSSxFQUFFO0FBQUUsa0NBQW9CeUM7QUFBdEI7QUFBUixXQUFaO0FBQ0Q7O0FBRUQsY0FBTUUsWUFBWSxHQUFHO0FBQUVDLFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQXJCO0FBQ0EsY0FBTUMsbUJBQW1CLEdBQUc7QUFBRWpELFVBQUFBLElBQUksRUFBRTtBQUFSLFNBQTVCOztBQUNBLFlBQUkrQyxZQUFZLENBQUNaLFNBQUQsQ0FBaEIsRUFBNkI7QUFDM0JjLFVBQUFBLG1CQUFtQixDQUFDQyxJQUFwQixHQUEyQixDQUFDO0FBQUUsYUFBQ0gsWUFBWSxDQUFDWixTQUFELENBQWIsR0FBMkJEO0FBQTdCLFdBQUQsQ0FBM0I7QUFDQWUsVUFBQUEsbUJBQW1CLENBQUNqRCxJQUFwQixHQUEyQlYsZ0JBQUU2RCxTQUFGLENBQVluRCxJQUFaLEVBQWtCLElBQWxCLENBQTNCO0FBQ0FpRCxVQUFBQSxtQkFBbUIsQ0FBQ3JDLElBQXBCLEdBQTJCdEIsZ0JBQUU2RCxTQUFGLENBQVl2QyxJQUFaLEVBQWtCLENBQWxCLENBQTNCO0FBQ0Q7O0FBRUQsY0FBTTVDLE1BQU0sR0FBRztBQUNiQyxVQUFBQSxJQUFJLEVBQUU7QUFDSm1GLFlBQUFBLG1CQUFtQixFQUFFLElBRGpCO0FBRUo1RCxZQUFBQSxPQUFPLEVBQUUsSUFGTDtBQUdKLGVBQUd5RCxtQkFIQztBQUlKaEQsWUFBQUEsS0FBSyxFQUFFO0FBQ0xDLGNBQUFBLElBQUksRUFBRTtBQUNKMEMsZ0JBQUFBO0FBREk7QUFERCxhQUpIO0FBU0pTLFlBQUFBLFlBQVksRUFBRTtBQUNaQyxjQUFBQSw2QkFBNkIsRUFBRTtBQUM3QkMsZ0JBQUFBLE1BQU0sRUFBRTtBQUNOQyxrQkFBQUEsSUFBSSxFQUFFO0FBREEsaUJBRHFCO0FBSTdCbEQsZ0JBQUFBLElBQUksRUFBRTtBQUNKbUQsa0JBQUFBLFdBQVcsRUFBRTtBQUNYakQsb0JBQUFBLEtBQUssRUFBRTtBQUNMQyxzQkFBQUEsS0FBSyxFQUFFO0FBREY7QUFESTtBQURUO0FBSnVCO0FBRG5CO0FBVFY7QUFETyxTQUFmO0FBMkJBLGNBQU07QUFBRXZDLFVBQUFBLGlCQUFpQixFQUFFd0Y7QUFBckIsWUFBbUQsTUFBTSxLQUFLOUYsUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUEvRDtBQUNBLGNBQU1zQixXQUFXLEdBQUcsTUFBTXNFLHlCQUF5QixDQUFDLHNCQUFELEVBQXlCMUYsTUFBekIsQ0FBbkQ7O0FBRUEsY0FBTTJGLGFBQWEsR0FBR3JFLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsa0JBQW5CLEVBQXVDLENBQXZDLENBQXRCOztBQUNBLGNBQU13RSxxQkFBcUIsR0FBR3RFLGdCQUFFQyxHQUFGLENBQU1ILFdBQU4sRUFBbUIsV0FBbkIsRUFBZ0MsRUFBaEMsRUFBb0N5RSxHQUFwQyxDQUF5QzVFLE1BQUQsSUFBWTtBQUNoRixnQkFBTTtBQUNKK0MsWUFBQUEsR0FBRyxFQUFFckQsRUFERDtBQUVKb0QsWUFBQUEsUUFBUSxFQUFFdkMsT0FGTjtBQUdKc0UsWUFBQUEsT0FBTyxFQUFFckUsT0FITDtBQUlKc0UsWUFBQUEsYUFBYSxFQUFFckUsYUFKWDtBQUtKc0UsWUFBQUEsT0FBTyxFQUFFM0U7QUFMTCxjQU1GSixNQU5KO0FBT0EsZ0JBQU07QUFBRStELFlBQUFBLElBQUY7QUFBUUgsWUFBQUE7QUFBUixjQUFvQnhELE9BQTFCO0FBQ0EsaUJBQU8sQ0FBQ1YsRUFBRCxFQUFLO0FBQUVBLFlBQUFBLEVBQUY7QUFBTWEsWUFBQUEsT0FBTjtBQUFlQyxZQUFBQSxPQUFmO0FBQXdCQyxZQUFBQSxhQUF4QjtBQUF1Q3NELFlBQUFBLElBQXZDO0FBQTZDSCxZQUFBQSxPQUE3QztBQUFzRHhELFlBQUFBO0FBQXRELFdBQUwsQ0FBUDtBQUNELFNBVjZCLEVBVTNCLEVBVjJCLENBQTlCOztBQVdBLGNBQU00RSxVQUFVLEdBQUcsSUFBSUMsR0FBSixDQUFRTixxQkFBUixDQUFuQjtBQUNBLGNBQU1PLFVBQVUsR0FBRyxDQUFDLEdBQUdGLFVBQVUsQ0FBQ0csSUFBWCxFQUFKLENBQW5CO0FBQ0EsY0FBTUMsa0NBQWtDLEdBQUcsRUFBM0M7O0FBQ0EvRSx3QkFBRUMsR0FBRixDQUNFSCxXQURGLEVBRUUsZ0VBRkYsRUFHRSxFQUhGLEVBSUVrRixPQUpGLENBSVUsQ0FBQztBQUFFbEQsVUFBQUEsR0FBRjtBQUFPQyxVQUFBQTtBQUFQLFNBQUQsS0FBd0I7QUFDaENnRCxVQUFBQSxrQ0FBa0MsQ0FBQ2pELEdBQUQsQ0FBbEMsR0FBMENDLFNBQTFDO0FBQ0QsU0FORDs7QUFRQSxjQUFNa0QsYUFBYSxHQUFHLEVBQXRCO0FBQ0EsY0FBTUMsU0FBUyxHQUFHO0FBQ2hCQyxVQUFBQSxNQUFNLEVBQUUsUUFEUTtBQUVoQkMsVUFBQUEsWUFBWSxFQUFFLGNBRkU7QUFHaEJDLFVBQUFBLE1BQU0sRUFBRSxRQUhRO0FBSWhCQyxVQUFBQSxPQUFPLEVBQUUsU0FKTztBQUtoQkMsVUFBQUEsb0JBQW9CLEVBQUU7QUFMTixTQUFsQjs7QUFPQSxZQUFJTCxTQUFTLENBQUNyQyxTQUFELENBQWIsRUFBMEI7QUFDeEJvQyxVQUFBQSxhQUFhLENBQUNPLEtBQWQsR0FBc0I7QUFBRSxhQUFDTixTQUFTLENBQUNyQyxTQUFELENBQVYsR0FBd0JEO0FBQTFCLFdBQXRCO0FBQ0Q7O0FBQ0QsY0FBTXRDLFVBQVUsR0FBRztBQUNqQkMsVUFBQUEsS0FBSyxFQUFFQyxpQkFBTUMsVUFESTtBQUVqQjlCLFVBQUFBLElBQUksRUFBRTtBQUNKK0IsWUFBQUEsSUFBSSxFQUFFLENBREY7QUFFSkMsWUFBQUEsS0FBSyxFQUFFO0FBQUVPLGNBQUFBLEtBQUssRUFBRTtBQUFFSCxnQkFBQUEsVUFBVSxFQUFFOEQ7QUFBZDtBQUFULGFBRkg7QUFHSmQsWUFBQUEsWUFBWSxFQUFFO0FBQ1owQixjQUFBQSxnQkFBZ0IsRUFBRTtBQUNoQnZFLGdCQUFBQSxLQUFLLEVBQUU7QUFDTEMsa0JBQUFBLEtBQUssRUFBRSxZQURGO0FBRUwscUJBQUc4RCxhQUZFO0FBR0x2RSxrQkFBQUEsSUFBSSxFQUFFWSxJQUFJLEdBQUdaO0FBSFIsaUJBRFM7QUFNaEJxRCxnQkFBQUEsWUFBWSxFQUFFO0FBQ1pvQixrQkFBQUEsTUFBTSxFQUFFO0FBQUVPLG9CQUFBQSxNQUFNLEVBQUU7QUFBRTVFLHNCQUFBQSxJQUFJLEVBQUU7QUFBRWdDLHdCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFSO0FBQVYsbUJBREk7QUFFWnNDLGtCQUFBQSxZQUFZLEVBQUU7QUFBRU0sb0JBQUFBLE1BQU0sRUFBRTtBQUFFNUUsc0JBQUFBLElBQUksRUFBRTtBQUFFZ0Msd0JBQUFBLEtBQUssRUFBRTtBQUFUO0FBQVI7QUFBVixtQkFGRjtBQUdadUMsa0JBQUFBLE1BQU0sRUFBRTtBQUFFSyxvQkFBQUEsTUFBTSxFQUFFO0FBQUU1RSxzQkFBQUEsSUFBSSxFQUFFO0FBQUVnQyx3QkFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBUjtBQUFWLG1CQUhJO0FBSVp3QyxrQkFBQUEsT0FBTyxFQUFFO0FBQ1BJLG9CQUFBQSxNQUFNLEVBQUU7QUFDTjlFLHNCQUFBQSxJQUFJLEVBQUU7QUFDSjhFLHdCQUFBQSxNQUFNLEVBQUU7QUFBRTVFLDBCQUFBQSxJQUFJLEVBQUU7QUFBRWdDLDRCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFSLHlCQURKO0FBRUo2Qyx3QkFBQUEsUUFBUSxFQUFFO0FBQUVDLDBCQUFBQSxNQUFNLEVBQUU7QUFBRXpFLDRCQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFWO0FBRk47QUFEQTtBQURELG1CQUpHO0FBWVowRSxrQkFBQUEsc0JBQXNCLEVBQUU7QUFBRUMsb0JBQUFBLEdBQUcsRUFBRTtBQUFFM0Usc0JBQUFBLEtBQUssRUFBRTtBQUFUO0FBQVAsbUJBWlo7QUFhWjRFLGtCQUFBQSxZQUFZLEVBQUU7QUFDWkMsb0JBQUFBLFFBQVEsRUFBRTtBQUNSdEYsc0JBQUFBLElBQUksRUFBRSxDQURFO0FBRVJrRCxzQkFBQUEsSUFBSSxFQUFFLENBQUM7QUFBRXFDLHdCQUFBQSxVQUFVLEVBQUU7QUFBRVQsMEJBQUFBLEtBQUssRUFBRTtBQUFUO0FBQWQsdUJBQUQsQ0FGRTtBQUdSZCxzQkFBQUEsT0FBTyxFQUFFO0FBQ1B3Qix3QkFBQUEsUUFBUSxFQUFFLENBQUMsd0JBQUQsRUFBMkIsY0FBM0I7QUFESDtBQUhEO0FBREU7QUFiRjtBQU5FO0FBRE47QUFIVjtBQUZXLFNBQW5CO0FBd0NBLGNBQU07QUFBRXRILFVBQUFBO0FBQUYsWUFBd0IsS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUE5QjtBQUNBLGNBQU0ySCxjQUFjLEdBQUcsTUFBTXZILGlCQUFpQixDQUFDLHNCQUFELEVBQXlCMEIsVUFBekIsQ0FBOUM7O0FBQ0EsY0FBTThGLE9BQU8sR0FBR3BHLGdCQUFFQyxHQUFGLENBQU1rRyxjQUFOLEVBQXNCLHVDQUF0QixFQUErRCxFQUEvRCxFQUFtRTVCLEdBQW5FLENBQ2I4QixNQUFELElBQVk7QUFDVixnQkFBTTtBQUNKdkUsWUFBQUEsR0FBRyxFQUFFekMsRUFERDtBQUVKd0csWUFBQUEsc0JBQXNCLEVBQUU7QUFBRVMsY0FBQUEsS0FBSyxFQUFFZjtBQUFULGFBRnBCO0FBR0pELFlBQUFBLE9BQU8sRUFBRTtBQUFFdkQsY0FBQUEsU0FBUyxFQUFFdUQ7QUFBYixhQUhMO0FBSUpGLFlBQUFBLFlBQVksRUFBRTtBQUFFckQsY0FBQUEsU0FBUyxFQUFFcUQ7QUFBYixhQUpWO0FBS0pELFlBQUFBLE1BQU0sRUFBRTtBQUFFcEQsY0FBQUEsU0FBUyxFQUFFb0Q7QUFBYixhQUxKO0FBTUpFLFlBQUFBLE1BQU0sRUFBRTtBQUFFdEQsY0FBQUEsU0FBUyxFQUFFc0Q7QUFBYixhQU5KO0FBT0pVLFlBQUFBLFlBQVksRUFBRTtBQUNaUSxjQUFBQSxJQUFJLEVBQUU7QUFDSkEsZ0JBQUFBLElBQUksRUFBRSxDQUNKO0FBQ0U3QixrQkFBQUEsT0FBTyxFQUFFO0FBQUU4QixvQkFBQUEsWUFBWSxFQUFFQztBQUFoQjtBQURYLGlCQURJO0FBREY7QUFETTtBQVBWLGNBZ0JGSixNQWhCSjtBQWlCQSxnQkFBTXRHLE9BQU8sR0FBRzRFLFVBQVUsQ0FBQzFFLEdBQVgsQ0FBZVosRUFBZixDQUFoQjtBQUNBc0YsVUFBQUEsVUFBVSxDQUFDK0IsTUFBWCxDQUFrQnJILEVBQWxCO0FBQ0EsaUJBQU8sRUFDTCxHQUFHVSxPQURFO0FBRUxWLFlBQUFBLEVBRks7QUFHTGtHLFlBQUFBLG9CQUhLO0FBSUxELFlBQUFBLE9BSks7QUFLTG1CLFlBQUFBLFdBTEs7QUFNTHJCLFlBQUFBLFlBTks7QUFPTEQsWUFBQUEsTUFQSztBQVFMRSxZQUFBQSxNQVJLO0FBU0xzQixZQUFBQSxXQUFXLEVBQUVDLElBQUksQ0FBQ0MsR0FBTCxFQVRSO0FBVUxDLFlBQUFBLDZCQUE2QixFQUFFL0Isa0NBQWtDLENBQUMxRixFQUFELENBQWxDLElBQTBDO0FBVnBFLFdBQVA7QUFZRCxTQWpDYSxDQUFoQjs7QUFvQ0EsY0FBTTBILGNBQWMsR0FBRyxDQUFDLEdBQUdwQyxVQUFVLENBQUNxQyxNQUFYLEVBQUosRUFBeUJ6QyxHQUF6QixDQUE4QnhFLE9BQUQsS0FBYyxFQUNoRSxHQUFHQSxPQUQ2RDtBQUVoRXdGLFVBQUFBLG9CQUFvQixFQUFFLElBRjBDO0FBR2hFRCxVQUFBQSxPQUFPLEVBQUUsQ0FIdUQ7QUFJaEVILFVBQUFBLE1BQU0sRUFBRSxDQUp3RDtBQUtoRUMsVUFBQUEsWUFBWSxFQUFFLENBTGtEO0FBTWhFQyxVQUFBQSxNQUFNLEVBQUUsQ0FOd0Q7QUFPaEVvQixVQUFBQSxXQUFXLEVBQUUsSUFQbUQ7QUFRaEVFLFVBQUFBLFdBQVcsRUFBRUMsSUFBSSxDQUFDQyxHQUFMLEVBUm1EO0FBU2hFQyxVQUFBQSw2QkFBNkIsRUFBRS9CLGtDQUFrQyxDQUFDaEYsT0FBTyxDQUFDVixFQUFULENBQWxDLElBQWtEO0FBVGpCLFNBQWQsQ0FBN0IsQ0FBdkI7O0FBWUEsWUFBSTRILE9BQU8sR0FBR2pILGdCQUFFa0gsT0FBRixDQUFVZCxPQUFPLENBQUNlLE1BQVIsQ0FBZUosY0FBZixDQUFWLEVBQTBDLENBQUNsRSxTQUFELENBQTFDLEVBQXVELENBQUNELGFBQUQsQ0FBdkQsQ0FBZCxDQTFMRSxDQTJMRjtBQUNBO0FBQ0E7OztBQUNBLFlBQUksQ0FBQ2EsWUFBWSxDQUFDWixTQUFELENBQWpCLEVBQThCO0FBQzVCb0UsVUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUNHLEtBQVIsQ0FBYzlGLElBQWQsRUFBb0JBLElBQUksR0FBR1osSUFBM0IsQ0FBVjtBQUNEOztBQUVELGVBQU9qQyxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSnNJLFlBQUFBLFFBQVEsRUFBRUosT0FGTjtBQUdKNUMsWUFBQUE7QUFISTtBQURNLFNBQVAsQ0FBUDtBQU9ELE9Bek1ELENBeU1FLE9BQU9wRixHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMseUNBQWQsRUFBeURGLEdBQXpEOztBQUNBLFlBQUksbUNBQXFCQSxHQUFyQixDQUFKLEVBQStCO0FBQzdCLGlCQUFPUixHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixZQUFBQSxJQUFJLEVBQUU7QUFBRUksY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsY0FBQUEsSUFBSSxFQUFFO0FBQUVxRixnQkFBQUEsYUFBYSxFQUFFLENBQWpCO0FBQW9CZ0QsZ0JBQUFBLFFBQVEsRUFBRTtBQUE5QjtBQUFuQjtBQURNLFdBQVAsQ0FBUDtBQUdEOztBQUNELGVBQU81SSxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFQyxHQUFHLENBQUNHO0FBRk47QUFETSxTQUFQLENBQVA7QUFNRDtBQUNGLEtBM2RxQjs7QUFBQSwrQ0E2ZEYsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQy9DLFVBQUk7QUFDRixjQUFNO0FBQUVZLFVBQUFBO0FBQUYsWUFBU2IsR0FBRyxDQUFDRSxNQUFuQjtBQUNBLGNBQU1BLE1BQU0sR0FBRztBQUNiWSxVQUFBQSxTQUFTLEVBQUVELEVBREU7QUFFYlYsVUFBQUEsSUFBSSxFQUFFSCxHQUFHLENBQUNHO0FBRkcsU0FBZjtBQUlBLGNBQU07QUFBRUMsVUFBQUE7QUFBRixZQUF3QixLQUFLTixRQUFMLENBQWNPLFFBQWQsQ0FBdUJMLEdBQXZCLENBQTlCO0FBQ0EsY0FBTThJLG1CQUFtQixHQUFHLE1BQU0xSSxpQkFBaUIsQ0FBQyw0QkFBRCxFQUErQkYsTUFBL0IsQ0FBbkQ7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLENBQUN1SSxtQkFBbUIsQ0FBQ0MsTUFBcEIsQ0FBMkJDLE1BRDVCO0FBRUp4SSxZQUFBQSxJQUFJLEVBQUVzSTtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FkRCxDQWNFLE9BQU9ySSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsZ0RBQWQsRUFBZ0VGLEdBQWhFO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXJmcUI7O0FBQUEsc0RBdWZLLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUN0RCxVQUFJO0FBQ0YsY0FBTTtBQUFFWSxVQUFBQTtBQUFGLFlBQVNiLEdBQUcsQ0FBQ0UsTUFBbkI7QUFDQSxjQUFNQSxNQUFNLEdBQUc7QUFDYm1CLFVBQUFBLFVBQVUsRUFBRVIsRUFEQztBQUViVixVQUFBQSxJQUFJLEVBQUVILEdBQUcsQ0FBQ0c7QUFGRyxTQUFmO0FBSUEsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQXdCLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBOUI7QUFDQSxjQUFNOEksbUJBQW1CLEdBQUcsTUFBTTFJLGlCQUFpQixDQUNqRCxtQ0FEaUQsRUFFakRGLE1BRmlELENBQW5EO0FBSUEsZUFBT0QsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxDQUFDdUksbUJBQW1CLENBQUNDLE1BQXBCLENBQTJCQyxNQUQ1QjtBQUVKeEksWUFBQUEsSUFBSSxFQUFFc0k7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BakJELENBaUJFLE9BQU9ySSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsdURBQWQsRUFBdUVGLEdBQXZFO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQWxoQnFCOztBQUFBLDRDQW9oQkwsT0FBT2IsT0FBUCxFQUFnQkMsR0FBaEIsRUFBcUJDLEdBQXJCLEtBQTZCO0FBQzVDLFVBQUk7QUFDRixjQUFNO0FBQUVnSixVQUFBQSxNQUFNLEdBQUc7QUFBWCxZQUFzQmpKLEdBQUcsQ0FBQ21DLEtBQWhDO0FBQ0EsY0FBTWpDLE1BQU0sR0FBRztBQUNiQyxVQUFBQSxJQUFJLEVBQUVILEdBQUcsQ0FBQ0csSUFERztBQUViOEksVUFBQUE7QUFGYSxTQUFmO0FBSUEsY0FBTTtBQUFFN0ksVUFBQUE7QUFBRixZQUF3QixNQUFNLEtBQUtOLFFBQUwsQ0FBY08sUUFBZCxDQUF1QkwsR0FBdkIsQ0FBcEM7QUFDQSxjQUFNa0osZUFBZSxHQUFHLE1BQU05SSxpQkFBaUIsQ0FBQyx5QkFBRCxFQUE0QkYsTUFBNUIsQ0FBL0M7QUFDQSxlQUFPRCxHQUFHLENBQUNNLEVBQUosQ0FBTztBQUNaSixVQUFBQSxJQUFJLEVBQUU7QUFDSkksWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSkMsWUFBQUEsSUFBSSxFQUFFMEk7QUFGRjtBQURNLFNBQVAsQ0FBUDtBQU1ELE9BZEQsQ0FjRSxPQUFPekksR0FBUCxFQUFZO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjLDZDQUFkLEVBQTZERixHQUE3RDtBQUNBLGVBQU9SLEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsS0FEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVDLEdBQUcsQ0FBQ0c7QUFGTjtBQURNLFNBQVAsQ0FBUDtBQU1EO0FBQ0YsS0E1aUJxQjs7QUFBQSw0Q0EraUJMLE9BQU9iLE9BQVAsRUFBZ0JDLEdBQWhCLEVBQXFCQyxHQUFyQixLQUE2QjtBQUM1QyxVQUFJO0FBQ0YsY0FBTTtBQUFFa0MsVUFBQUEsS0FBRjtBQUFTSixVQUFBQSxLQUFUO0FBQWdCRyxVQUFBQTtBQUFoQixZQUF5QmxDLEdBQUcsQ0FBQ0csSUFBbkM7QUFDQSxjQUFNRCxNQUFNLEdBQUc7QUFBRTZCLFVBQUFBLEtBQUY7QUFBU0csVUFBQUEsSUFBVDtBQUFlL0IsVUFBQUEsSUFBSSxFQUFFZ0M7QUFBckIsU0FBZjtBQUVBekIsUUFBQUEsT0FBTyxDQUFDTSxHQUFSLENBQVksMEJBQVo7QUFDQU4sUUFBQUEsT0FBTyxDQUFDTSxHQUFSLENBQVlDLElBQUksQ0FBQ0MsU0FBTCxDQUFlaEIsTUFBZixDQUFaO0FBRUEsY0FBTTtBQUFFRSxVQUFBQTtBQUFGLFlBQXdCLE1BQU0sS0FBS04sUUFBTCxDQUFjTyxRQUFkLENBQXVCTCxHQUF2QixDQUFwQztBQUNBLGNBQU15SSxPQUFPLEdBQUcsTUFBTXJJLGlCQUFpQixDQUFDLHNCQUFELEVBQXlCRixNQUF6QixDQUF2QztBQUNBLGVBQU9ELEdBQUcsQ0FBQ00sRUFBSixDQUFPO0FBQ1pKLFVBQUFBLElBQUksRUFBRTtBQUNKSSxZQUFBQSxFQUFFLEVBQUUsSUFEQTtBQUVKQyxZQUFBQSxJQUFJLEVBQUVpSTtBQUZGO0FBRE0sU0FBUCxDQUFQO0FBTUQsT0FmRCxDQWVFLE9BQU9oSSxHQUFQLEVBQVk7QUFDWkMsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsNENBQWQsRUFBNERGLEdBQTVEO0FBQ0EsZUFBT1IsR0FBRyxDQUFDTSxFQUFKLENBQU87QUFDWkosVUFBQUEsSUFBSSxFQUFFO0FBQ0pJLFlBQUFBLEVBQUUsRUFBRSxLQURBO0FBRUpDLFlBQUFBLElBQUksRUFBRUMsR0FBRyxDQUFDRztBQUZOO0FBRE0sU0FBUCxDQUFQO0FBTUQ7QUFDRixLQXhrQnFCOztBQUNwQixTQUFLZCxRQUFMLEdBQWdCQSxRQUFoQjtBQUNEOztBQUhpQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcblxuaW1wb3J0IHsgSU5ERVggfSBmcm9tICcuLi8uLi91dGlscy9jb25zdGFudHMnO1xuaW1wb3J0IHsgaXNJbmRleE5vdEZvdW5kRXJyb3IgfSBmcm9tICcuL3V0aWxzL2hlbHBlcnMnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb25pdG9yU2VydmljZSB7XG4gIGNvbnN0cnVjdG9yKGVzRHJpdmVyKSB7XG4gICAgdGhpcy5lc0RyaXZlciA9IGVzRHJpdmVyO1xuICB9XG5cbiAgY3JlYXRlTW9uaXRvciA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IGJvZHk6IHJlcS5ib2R5IH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBjcmVhdGVSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5jcmVhdGVNb25pdG9yJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogY3JlYXRlUmVzcG9uc2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBjcmVhdGVNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBjcmVhdGVXb3JrZmxvdyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IGJvZHk6IHJlcS5ib2R5IH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBjcmVhdGVSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5jcmVhdGVXb3JrZmxvdycsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IGNyZWF0ZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gY3JlYXRlV29ya2Zsb3c6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGRlbGV0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZGVsZXRlTW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICBjb25zb2xlLmxvZygnRGVsZXRlIG1vbml0b3IgcmVzcG9uc2UnKTtcbiAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlKSk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiByZXNwb25zZS5yZXN1bHQgPT09ICdkZWxldGVkJyB8fCByZXNwb25zZS5yZXN1bHQgPT09IHVuZGVmaW5lZCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGRlbGV0ZU1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGRlbGV0ZVdvcmtmbG93ID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IHdvcmtmbG93SWQ6IGlkIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5kZWxldGVXb3JrZmxvdycsIHBhcmFtcyk7XG4gICAgICBjb25zb2xlLmxvZygnZGVsZXRlIHdvcmtmbG93IHJlc3BvbnNlIF4qXipeKl4qXionKTtcbiAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlKSk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiByZXNwb25zZS5yZXN1bHQgPT09ICdkZWxldGVkJyB8fCByZXNwb25zZS5yZXN1bHQgPT09IHVuZGVmaW5lZCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGRlbGV0ZVdvcmtmbG93OicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBnZXRNb25pdG9yID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc29sZS5sb2coJyoqKioqKiBHRVQgTU9OSVRPUiAqKioqKicpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgICAgY29uc3QgcGFyYW1zID0geyBtb25pdG9ySWQ6IGlkIH07XG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCBnZXRSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5nZXRNb25pdG9yJywgcGFyYW1zKTtcbiAgICAgIGNvbnNvbGUubG9nKCdHZXQgbW9uaXRvciBjb21wbGV0ZSByZXNwb25zZSBeXl5eXl5eXl4nKTtcbiAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGdldFJlc3BvbnNlKSk7XG4gICAgICBsZXQgbW9uaXRvciA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnbW9uaXRvcicsIG51bGwpO1xuICAgICAgY29uc3QgdmVyc2lvbiA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnX3ZlcnNpb24nLCBudWxsKTtcbiAgICAgIGNvbnN0IGlmU2VxTm8gPSBfLmdldChnZXRSZXNwb25zZSwgJ19zZXFfbm8nLCBudWxsKTtcbiAgICAgIGNvbnN0IGlmUHJpbWFyeVRlcm0gPSBfLmdldChnZXRSZXNwb25zZSwgJ19wcmltYXJ5X3Rlcm0nLCBudWxsKTtcbiAgICAgIGNvbnN0IGFzc29jaWF0ZWRfd29ya2Zsb3dzID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdhc3NvY2lhdGVkX3dvcmtmbG93cycsIG51bGwpO1xuICAgICAgaWYgKG1vbml0b3IpIHtcbiAgICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgICBjb25zdCBhZ2dzUGFyYW1zID0ge1xuICAgICAgICAgIGluZGV4OiBJTkRFWC5BTExfQUxFUlRTLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgICAgbXVzdDoge1xuICAgICAgICAgICAgICAgICAgdGVybToge1xuICAgICAgICAgICAgICAgICAgICBtb25pdG9yX2lkOiBpZCxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBhZ2dzOiB7XG4gICAgICAgICAgICAgIGFjdGl2ZV9jb3VudDoge1xuICAgICAgICAgICAgICAgIHRlcm1zOiB7XG4gICAgICAgICAgICAgICAgICBmaWVsZDogJ3N0YXRlJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAnMjRfaG91cl9jb3VudCc6IHtcbiAgICAgICAgICAgICAgICBkYXRlX3JhbmdlOiB7XG4gICAgICAgICAgICAgICAgICBmaWVsZDogJ3N0YXJ0X3RpbWUnLFxuICAgICAgICAgICAgICAgICAgcmFuZ2VzOiBbeyBmcm9tOiAnbm93LTI0aC9oJyB9XSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBzZWFyY2hSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5nZXRNb25pdG9ycycsIGFnZ3NQYXJhbXMpO1xuICAgICAgICBjb25zdCBkYXlDb3VudCA9IF8uZ2V0KHNlYXJjaFJlc3BvbnNlLCAnYWdncmVnYXRpb25zLjI0X2hvdXJfY291bnQuYnVja2V0cy4wLmRvY19jb3VudCcsIDApO1xuICAgICAgICBjb25zdCBhY3RpdmVCdWNrZXRzID0gXy5nZXQoc2VhcmNoUmVzcG9uc2UsICdhZ2dyZWdhdGlvbnMuYWN0aXZlX2NvdW50LmJ1Y2tldHMnLCBbXSk7XG4gICAgICAgIGNvbnN0IGFjdGl2ZUNvdW50ID0gYWN0aXZlQnVja2V0cy5yZWR1Y2UoXG4gICAgICAgICAgKGFjYywgY3VycikgPT4gKGN1cnIua2V5ID09PSAnQUNUSVZFJyA/IGN1cnIuZG9jX2NvdW50IDogYWNjKSxcbiAgICAgICAgICAwXG4gICAgICAgICk7XG4gICAgICAgIGlmIChhc3NvY2lhdGVkX3dvcmtmbG93cykge1xuICAgICAgICAgIG1vbml0b3IgPSB7XG4gICAgICAgICAgICAuLi5tb25pdG9yLFxuICAgICAgICAgICAgYXNzb2NpYXRlZF93b3JrZmxvd3MsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBtb25pdG9yID0ge1xuICAgICAgICAgIC4uLm1vbml0b3IsXG4gICAgICAgICAgaXRlbV90eXBlOiBtb25pdG9yLndvcmtmbG93X3R5cGUgfHwgbW9uaXRvci5tb25pdG9yX3R5cGUsXG4gICAgICAgICAgaWQsXG4gICAgICAgICAgdmVyc2lvbixcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBvazogdHJ1ZSwgcmVzcDogbW9uaXRvciwgYWN0aXZlQ291bnQsIGRheUNvdW50LCB2ZXJzaW9uLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGdldE1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGdldFdvcmtmbG93ID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc29sZS5sb2coJyoqKioqKiBHRVQgV09SS0ZMT1cgKioqKionKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gYXdhaXQgdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZ2V0UmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0V29ya2Zsb3cnLCBwYXJhbXMpO1xuICAgICAgbGV0IHdvcmtmbG93ID0gXy5nZXQoZ2V0UmVzcG9uc2UsICd3b3JrZmxvdycsIG51bGwpO1xuICAgICAgY29uc3QgdmVyc2lvbiA9IF8uZ2V0KGdldFJlc3BvbnNlLCAnX3ZlcnNpb24nLCBudWxsKTtcbiAgICAgIGNvbnN0IGlmU2VxTm8gPSBfLmdldChnZXRSZXNwb25zZSwgJ19zZXFfbm8nLCBudWxsKTtcbiAgICAgIGNvbnN0IGlmUHJpbWFyeVRlcm0gPSBfLmdldChnZXRSZXNwb25zZSwgJ19wcmltYXJ5X3Rlcm0nLCBudWxsKTtcbiAgICAgIHdvcmtmbG93Lm1vbml0b3JfdHlwZSA9IHdvcmtmbG93LndvcmtmbG93X3R5cGU7XG4gICAgICB3b3JrZmxvdyA9IHtcbiAgICAgICAgLi4ud29ya2Zsb3csXG4gICAgICAgIGl0ZW1fdHlwZTogd29ya2Zsb3cud29ya2Zsb3dfdHlwZSxcbiAgICAgICAgaWQsXG4gICAgICAgIHZlcnNpb24sXG4gICAgICB9O1xuXG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IHdvcmtmbG93LFxuICAgICAgICAgIGFjdGl2ZUNvdW50OiAwLFxuICAgICAgICAgIGRheUNvdW50OiAwLFxuICAgICAgICAgIHZlcnNpb24sXG4gICAgICAgICAgaWZTZXFObyxcbiAgICAgICAgICBpZlByaW1hcnlUZXJtLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gZ2V0V29ya2Zsb3c6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIHVwZGF0ZU1vbml0b3IgPSBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbW9uaXRvcklkOiBpZCwgYm9keTogcmVxLmJvZHksIHJlZnJlc2g6ICd3YWl0X2ZvcicgfTtcbiAgICAgIGNvbnN0IHsgdHlwZSB9ID0gcmVxLmJvZHk7XG5cbiAgICAgIC8vIFRPRE8gRFJBRlQ6IEFyZSB3ZSBzdXJlIHdlIG5lZWQgdG8gaW5jbHVkZSBpZlNlcU5vIGFuZCBpZlByaW1hcnlUZXJtIGZyb20gdGhlIFVJIHNpZGUgd2hlbiB1cGRhdGluZyBtb25pdG9ycz9cbiAgICAgIGNvbnN0IHsgaWZTZXFObywgaWZQcmltYXJ5VGVybSB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgaWYgKGlmU2VxTm8gJiYgaWZQcmltYXJ5VGVybSkge1xuICAgICAgICBwYXJhbXMuaWZfc2VxX25vID0gaWZTZXFObztcbiAgICAgICAgcGFyYW1zLmlmX3ByaW1hcnlfdGVybSA9IGlmUHJpbWFyeVRlcm07XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IHVwZGF0ZVJlc3BvbnNlID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoXG4gICAgICAgIGBhbGVydGluZy4ke3R5cGUgPT09ICd3b3JrZmxvdycgPyAndXBkYXRlV29ya2Zsb3cnIDogJ3VwZGF0ZU1vbml0b3InfWAsXG4gICAgICAgIHBhcmFtc1xuICAgICAgKTtcbiAgICAgIGNvbnN0IHsgX3ZlcnNpb24sIF9pZCB9ID0gdXBkYXRlUmVzcG9uc2U7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHZlcnNpb246IF92ZXJzaW9uLFxuICAgICAgICAgIGlkOiBfaWQsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSB1cGRhdGVNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBnZXRNb25pdG9ycyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIGNvbnNvbGUubG9nKCcqKioqKiogR0VUIE1PTklUT1JTICoqKioqJyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZnJvbSwgc2l6ZSwgc2VhcmNoLCBzb3J0RGlyZWN0aW9uLCBzb3J0RmllbGQsIHN0YXRlIH0gPSByZXEucXVlcnk7XG5cbiAgICAgIGxldCBtdXN0ID0geyBtYXRjaF9hbGw6IHt9IH07XG4gICAgICBpZiAoc2VhcmNoLnRyaW0oKSkge1xuICAgICAgICAvLyBUaGlzIGlzIGFuIGV4cGVuc2l2ZSB3aWxkY2FyZCBxdWVyeSB0byBtYXRjaCBtb25pdG9yIG5hbWVzIHN1Y2ggYXM6IFwiVGhpcyBpcyBhIGxvbmcgbW9uaXRvciBuYW1lXCJcbiAgICAgICAgLy8gc2VhcmNoIHF1ZXJ5ID0+IFwibG9uZyBtb25pdFwiXG4gICAgICAgIC8vIFRoaXMgaXMgYWNjZXB0YWJsZSBiZWNhdXNlIHdlIHdpbGwgbmV2ZXIgYWxsb3cgbW9yZSB0aGFuIDEsMDAwIG1vbml0b3JzXG4gICAgICAgIG11c3QgPSB7XG4gICAgICAgICAgcXVlcnlfc3RyaW5nOiB7XG4gICAgICAgICAgICBkZWZhdWx0X2ZpZWxkOiAnbW9uaXRvci5uYW1lJyxcbiAgICAgICAgICAgIGRlZmF1bHRfb3BlcmF0b3I6ICdBTkQnLFxuICAgICAgICAgICAgcXVlcnk6IGAqJHtzZWFyY2gudHJpbSgpLnNwbGl0KCcgJykuam9pbignKiAqJyl9KmAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgc2hvdWxkID0gW107XG4gICAgICBpZiAoc3RhdGUgIT09ICdhbGwnKSB7XG4gICAgICAgIGNvbnN0IGVuYWJsZWQgPSBzdGF0ZSA9PT0gJ2VuYWJsZWQnO1xuICAgICAgICBzaG91bGQucHVzaCh7IHRlcm06IHsgJ21vbml0b3IuZW5hYmxlZCc6IGVuYWJsZWQgfSB9KTtcbiAgICAgICAgc2hvdWxkLnB1c2goeyB0ZXJtOiB7ICd3b3JrZmxvdy5lbmFibGVkJzogZW5hYmxlZCB9IH0pO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBtb25pdG9yU29ydHMgPSB7IG5hbWU6ICdtb25pdG9yLm5hbWUua2V5d29yZCcgfTtcbiAgICAgIGNvbnN0IG1vbml0b3JTb3J0UGFnZURhdGEgPSB7IHNpemU6IDEwMDAgfTtcbiAgICAgIGlmIChtb25pdG9yU29ydHNbc29ydEZpZWxkXSkge1xuICAgICAgICBtb25pdG9yU29ydFBhZ2VEYXRhLnNvcnQgPSBbeyBbbW9uaXRvclNvcnRzW3NvcnRGaWVsZF1dOiBzb3J0RGlyZWN0aW9uIH1dO1xuICAgICAgICBtb25pdG9yU29ydFBhZ2VEYXRhLnNpemUgPSBfLmRlZmF1bHRUbyhzaXplLCAxMDAwKTtcbiAgICAgICAgbW9uaXRvclNvcnRQYWdlRGF0YS5mcm9tID0gXy5kZWZhdWx0VG8oZnJvbSwgMCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHNlcV9ub19wcmltYXJ5X3Rlcm06IHRydWUsXG4gICAgICAgICAgdmVyc2lvbjogdHJ1ZSxcbiAgICAgICAgICAuLi5tb25pdG9yU29ydFBhZ2VEYXRhLFxuICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgIHNob3VsZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBhZ2dyZWdhdGlvbnM6IHtcbiAgICAgICAgICAgIGFzc29jaWF0ZWRfY29tcG9zaXRlX21vbml0b3JzOiB7XG4gICAgICAgICAgICAgIG5lc3RlZDoge1xuICAgICAgICAgICAgICAgIHBhdGg6ICd3b3JrZmxvdy5pbnB1dHMuY29tcG9zaXRlX2lucHV0LnNlcXVlbmNlLmRlbGVnYXRlcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGFnZ3M6IHtcbiAgICAgICAgICAgICAgICBtb25pdG9yX2lkczoge1xuICAgICAgICAgICAgICAgICAgdGVybXM6IHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQ6ICd3b3JrZmxvdy5pbnB1dHMuY29tcG9zaXRlX2lucHV0LnNlcXVlbmNlLmRlbGVnYXRlcy5tb25pdG9yX2lkJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGFsZXJ0aW5nQ2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGdldFJlc3BvbnNlID0gYXdhaXQgYWxlcnRpbmdDYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBwYXJhbXMpO1xuXG4gICAgICBjb25zdCB0b3RhbE1vbml0b3JzID0gXy5nZXQoZ2V0UmVzcG9uc2UsICdoaXRzLnRvdGFsLnZhbHVlJywgMCk7XG4gICAgICBjb25zdCBtb25pdG9yS2V5VmFsdWVUdXBsZXMgPSBfLmdldChnZXRSZXNwb25zZSwgJ2hpdHMuaGl0cycsIFtdKS5tYXAoKHJlc3VsdCkgPT4ge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgICBfdmVyc2lvbjogdmVyc2lvbixcbiAgICAgICAgICBfc2VxX25vOiBpZlNlcU5vLFxuICAgICAgICAgIF9wcmltYXJ5X3Rlcm06IGlmUHJpbWFyeVRlcm0sXG4gICAgICAgICAgX3NvdXJjZTogbW9uaXRvcixcbiAgICAgICAgfSA9IHJlc3VsdDtcbiAgICAgICAgY29uc3QgeyBuYW1lLCBlbmFibGVkIH0gPSBtb25pdG9yO1xuICAgICAgICByZXR1cm4gW2lkLCB7IGlkLCB2ZXJzaW9uLCBpZlNlcU5vLCBpZlByaW1hcnlUZXJtLCBuYW1lLCBlbmFibGVkLCBtb25pdG9yIH1dO1xuICAgICAgfSwge30pO1xuICAgICAgY29uc3QgbW9uaXRvck1hcCA9IG5ldyBNYXAobW9uaXRvcktleVZhbHVlVHVwbGVzKTtcbiAgICAgIGNvbnN0IG1vbml0b3JJZHMgPSBbLi4ubW9uaXRvck1hcC5rZXlzKCldO1xuICAgICAgY29uc3QgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcCA9IHt9O1xuICAgICAgXy5nZXQoXG4gICAgICAgIGdldFJlc3BvbnNlLFxuICAgICAgICAnYWdncmVnYXRpb25zLmFzc29jaWF0ZWRfY29tcG9zaXRlX21vbml0b3JzLm1vbml0b3JfaWRzLmJ1Y2tldHMnLFxuICAgICAgICBbXVxuICAgICAgKS5mb3JFYWNoKCh7IGtleSwgZG9jX2NvdW50IH0pID0+IHtcbiAgICAgICAgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcFtrZXldID0gZG9jX2NvdW50O1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IGFnZ3NPcmRlckRhdGEgPSB7fTtcbiAgICAgIGNvbnN0IGFnZ3NTb3J0cyA9IHtcbiAgICAgICAgYWN0aXZlOiAnYWN0aXZlJyxcbiAgICAgICAgYWNrbm93bGVkZ2VkOiAnYWNrbm93bGVkZ2VkJyxcbiAgICAgICAgZXJyb3JzOiAnZXJyb3JzJyxcbiAgICAgICAgaWdub3JlZDogJ2lnbm9yZWQnLFxuICAgICAgICBsYXN0Tm90aWZpY2F0aW9uVGltZTogJ2xhc3Rfbm90aWZpY2F0aW9uX3RpbWUnLFxuICAgICAgfTtcbiAgICAgIGlmIChhZ2dzU29ydHNbc29ydEZpZWxkXSkge1xuICAgICAgICBhZ2dzT3JkZXJEYXRhLm9yZGVyID0geyBbYWdnc1NvcnRzW3NvcnRGaWVsZF1dOiBzb3J0RGlyZWN0aW9uIH07XG4gICAgICB9XG4gICAgICBjb25zdCBhZ2dzUGFyYW1zID0ge1xuICAgICAgICBpbmRleDogSU5ERVguQUxMX0FMRVJUUyxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgcXVlcnk6IHsgdGVybXM6IHsgbW9uaXRvcl9pZDogbW9uaXRvcklkcyB9IH0sXG4gICAgICAgICAgYWdncmVnYXRpb25zOiB7XG4gICAgICAgICAgICB1bmlxX21vbml0b3JfaWRzOiB7XG4gICAgICAgICAgICAgIHRlcm1zOiB7XG4gICAgICAgICAgICAgICAgZmllbGQ6ICdtb25pdG9yX2lkJyxcbiAgICAgICAgICAgICAgICAuLi5hZ2dzT3JkZXJEYXRhLFxuICAgICAgICAgICAgICAgIHNpemU6IGZyb20gKyBzaXplLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBhZ2dyZWdhdGlvbnM6IHtcbiAgICAgICAgICAgICAgICBhY3RpdmU6IHsgZmlsdGVyOiB7IHRlcm06IHsgc3RhdGU6ICdBQ1RJVkUnIH0gfSB9LFxuICAgICAgICAgICAgICAgIGFja25vd2xlZGdlZDogeyBmaWx0ZXI6IHsgdGVybTogeyBzdGF0ZTogJ0FDS05PV0xFREdFRCcgfSB9IH0sXG4gICAgICAgICAgICAgICAgZXJyb3JzOiB7IGZpbHRlcjogeyB0ZXJtOiB7IHN0YXRlOiAnRVJST1InIH0gfSB9LFxuICAgICAgICAgICAgICAgIGlnbm9yZWQ6IHtcbiAgICAgICAgICAgICAgICAgIGZpbHRlcjoge1xuICAgICAgICAgICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyOiB7IHRlcm06IHsgc3RhdGU6ICdDT01QTEVURUQnIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICBtdXN0X25vdDogeyBleGlzdHM6IHsgZmllbGQ6ICdhY2tub3dsZWRnZWRfdGltZScgfSB9LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGxhc3Rfbm90aWZpY2F0aW9uX3RpbWU6IHsgbWF4OiB7IGZpZWxkOiAnbGFzdF9ub3RpZmljYXRpb25fdGltZScgfSB9LFxuICAgICAgICAgICAgICAgIGxhdGVzdF9hbGVydDoge1xuICAgICAgICAgICAgICAgICAgdG9wX2hpdHM6IHtcbiAgICAgICAgICAgICAgICAgICAgc2l6ZTogMSxcbiAgICAgICAgICAgICAgICAgICAgc29ydDogW3sgc3RhcnRfdGltZTogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICAgICAgICAgICAgICAgIF9zb3VyY2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICBpbmNsdWRlczogWydsYXN0X25vdGlmaWNhdGlvbl90aW1lJywgJ3RyaWdnZXJfbmFtZSddLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfTtcblxuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgZXNBZ2dzUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuZ2V0TW9uaXRvcnMnLCBhZ2dzUGFyYW1zKTtcbiAgICAgIGNvbnN0IGJ1Y2tldHMgPSBfLmdldChlc0FnZ3NSZXNwb25zZSwgJ2FnZ3JlZ2F0aW9ucy51bmlxX21vbml0b3JfaWRzLmJ1Y2tldHMnLCBbXSkubWFwKFxuICAgICAgICAoYnVja2V0KSA9PiB7XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAga2V5OiBpZCxcbiAgICAgICAgICAgIGxhc3Rfbm90aWZpY2F0aW9uX3RpbWU6IHsgdmFsdWU6IGxhc3ROb3RpZmljYXRpb25UaW1lIH0sXG4gICAgICAgICAgICBpZ25vcmVkOiB7IGRvY19jb3VudDogaWdub3JlZCB9LFxuICAgICAgICAgICAgYWNrbm93bGVkZ2VkOiB7IGRvY19jb3VudDogYWNrbm93bGVkZ2VkIH0sXG4gICAgICAgICAgICBhY3RpdmU6IHsgZG9jX2NvdW50OiBhY3RpdmUgfSxcbiAgICAgICAgICAgIGVycm9yczogeyBkb2NfY291bnQ6IGVycm9ycyB9LFxuICAgICAgICAgICAgbGF0ZXN0X2FsZXJ0OiB7XG4gICAgICAgICAgICAgIGhpdHM6IHtcbiAgICAgICAgICAgICAgICBoaXRzOiBbXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9zb3VyY2U6IHsgdHJpZ2dlcl9uYW1lOiBsYXRlc3RBbGVydCB9LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9ID0gYnVja2V0O1xuICAgICAgICAgIGNvbnN0IG1vbml0b3IgPSBtb25pdG9yTWFwLmdldChpZCk7XG4gICAgICAgICAgbW9uaXRvck1hcC5kZWxldGUoaWQpO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5tb25pdG9yLFxuICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICBsYXN0Tm90aWZpY2F0aW9uVGltZSxcbiAgICAgICAgICAgIGlnbm9yZWQsXG4gICAgICAgICAgICBsYXRlc3RBbGVydCxcbiAgICAgICAgICAgIGFja25vd2xlZGdlZCxcbiAgICAgICAgICAgIGFjdGl2ZSxcbiAgICAgICAgICAgIGVycm9ycyxcbiAgICAgICAgICAgIGN1cnJlbnRUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDbnQ6IGFzc29jaWF0ZWRDb21wb3NpdGVNb25pdG9yQ291bnRNYXBbaWRdIHx8IDAsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgKTtcblxuICAgICAgY29uc3QgdW51c2VkTW9uaXRvcnMgPSBbLi4ubW9uaXRvck1hcC52YWx1ZXMoKV0ubWFwKChtb25pdG9yKSA9PiAoe1xuICAgICAgICAuLi5tb25pdG9yLFxuICAgICAgICBsYXN0Tm90aWZpY2F0aW9uVGltZTogbnVsbCxcbiAgICAgICAgaWdub3JlZDogMCxcbiAgICAgICAgYWN0aXZlOiAwLFxuICAgICAgICBhY2tub3dsZWRnZWQ6IDAsXG4gICAgICAgIGVycm9yczogMCxcbiAgICAgICAgbGF0ZXN0QWxlcnQ6ICctLScsXG4gICAgICAgIGN1cnJlbnRUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgICBhc3NvY2lhdGVkQ29tcG9zaXRlTW9uaXRvckNudDogYXNzb2NpYXRlZENvbXBvc2l0ZU1vbml0b3JDb3VudE1hcFttb25pdG9yLmlkXSB8fCAwLFxuICAgICAgfSkpO1xuXG4gICAgICBsZXQgcmVzdWx0cyA9IF8ub3JkZXJCeShidWNrZXRzLmNvbmNhdCh1bnVzZWRNb25pdG9ycyksIFtzb3J0RmllbGRdLCBbc29ydERpcmVjdGlvbl0pO1xuICAgICAgLy8gSWYgd2Ugc29ydGVkIG9uIG1vbml0b3IgbmFtZSB0aGVuIHdlIGFscmVhZHkgYXBwbGllZCBmcm9tL3NpemUgdG8gdGhlIGZpcnN0IHF1ZXJ5IHRvIGxpbWl0IHdoYXQgd2UncmUgYWdncmVnYXRpbmcgb3ZlclxuICAgICAgLy8gVGhlcmVmb3JlIHdlIGRvIG5vdCBuZWVkIHRvIGFwcGx5IGZyb20vc2l6ZSB0byB0aGlzIHJlc3VsdCBzZXRcbiAgICAgIC8vIElmIHdlIHNvcnRlZCBvbiBhZ2dyZWdhdGlvbnMsIHRoZW4gdGhpcyBpcyBvdXIgaW4gbWVtb3J5IHBhZ2luYXRpb25cbiAgICAgIGlmICghbW9uaXRvclNvcnRzW3NvcnRGaWVsZF0pIHtcbiAgICAgICAgcmVzdWx0cyA9IHJlc3VsdHMuc2xpY2UoZnJvbSwgZnJvbSArIHNpemUpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIG1vbml0b3JzOiByZXN1bHRzLFxuICAgICAgICAgIHRvdGFsTW9uaXRvcnMsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FsZXJ0aW5nIC0gTW9uaXRvclNlcnZpY2UgLSBnZXRNb25pdG9ycycsIGVycik7XG4gICAgICBpZiAoaXNJbmRleE5vdEZvdW5kRXJyb3IoZXJyKSkge1xuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7IG9rOiBmYWxzZSwgcmVzcDogeyB0b3RhbE1vbml0b3JzOiAwLCBtb25pdG9yczogW10gfSB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGFja25vd2xlZGdlQWxlcnRzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgIG1vbml0b3JJZDogaWQsXG4gICAgICAgIGJvZHk6IHJlcS5ib2R5LFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGFja25vd2xlZGdlUmVzcG9uc2UgPSBhd2FpdCBjYWxsQXNDdXJyZW50VXNlcignYWxlcnRpbmcuYWNrbm93bGVkZ2VBbGVydHMnLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogIWFja25vd2xlZGdlUmVzcG9uc2UuZmFpbGVkLmxlbmd0aCxcbiAgICAgICAgICByZXNwOiBhY2tub3dsZWRnZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gYWNrbm93bGVkZ2VBbGVydHM6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIGFja25vd2xlZGdlQ2hhaW5lZEFsZXJ0cyA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICB3b3JrZmxvd0lkOiBpZCxcbiAgICAgICAgYm9keTogcmVxLmJvZHksXG4gICAgICB9O1xuICAgICAgY29uc3QgeyBjYWxsQXNDdXJyZW50VXNlciB9ID0gdGhpcy5lc0RyaXZlci5hc1Njb3BlZChyZXEpO1xuICAgICAgY29uc3QgYWNrbm93bGVkZ2VSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKFxuICAgICAgICAnYWxlcnRpbmcuYWNrbm93bGVkZ2VDaGFpbmVkQWxlcnRzJyxcbiAgICAgICAgcGFyYW1zXG4gICAgICApO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogIWFja25vd2xlZGdlUmVzcG9uc2UuZmFpbGVkLmxlbmd0aCxcbiAgICAgICAgICByZXNwOiBhY2tub3dsZWRnZVJlc3BvbnNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdBbGVydGluZyAtIE1vbml0b3JTZXJ2aWNlIC0gYWNrbm93bGVkZ2VDaGFpbmVkQWxlcnRzOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBleGVjdXRlTW9uaXRvciA9IGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRyeXJ1biA9ICd0cnVlJyB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICBib2R5OiByZXEuYm9keSxcbiAgICAgICAgZHJ5cnVuLFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXIgfSA9IGF3YWl0IHRoaXMuZXNEcml2ZXIuYXNTY29wZWQocmVxKTtcbiAgICAgIGNvbnN0IGV4ZWN1dGVSZXNwb25zZSA9IGF3YWl0IGNhbGxBc0N1cnJlbnRVc2VyKCdhbGVydGluZy5leGVjdXRlTW9uaXRvcicsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgIHJlc3A6IGV4ZWN1dGVSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIGV4ZWN1dGVNb25pdG9yOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICByZXNwOiBlcnIubWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICAvL1RPRE86IFRoaXMgaXMgdGVtcG9yYXJpbHkgYSBwYXNzIHRocm91Z2ggY2FsbCB3aGljaCBuZWVkcyB0byBiZSBkZXByZWNhdGVkXG4gIHNlYXJjaE1vbml0b3JzID0gYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgcXVlcnksIGluZGV4LCBzaXplIH0gPSByZXEuYm9keTtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgaW5kZXgsIHNpemUsIGJvZHk6IHF1ZXJ5IH07XG5cbiAgICAgIGNvbnNvbGUubG9nKCdTZWFyY2ggbW9uaXRvcnMgKioqKioqKiAnKTtcbiAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHBhcmFtcykpO1xuXG4gICAgICBjb25zdCB7IGNhbGxBc0N1cnJlbnRVc2VyIH0gPSBhd2FpdCB0aGlzLmVzRHJpdmVyLmFzU2NvcGVkKHJlcSk7XG4gICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgY2FsbEFzQ3VycmVudFVzZXIoJ2FsZXJ0aW5nLmdldE1vbml0b3JzJywgcGFyYW1zKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgcmVzcDogcmVzdWx0cyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQWxlcnRpbmcgLSBNb25pdG9yU2VydmljZSAtIHNlYXJjaE1vbml0b3I6JywgZXJyKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHJlc3A6IGVyci5tZXNzYWdlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICB9O1xufVxuIl19