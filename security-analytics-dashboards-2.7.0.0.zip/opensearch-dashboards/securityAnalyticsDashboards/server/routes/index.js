"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _DetectorRoutes = require("./DetectorRoutes");

Object.keys(_DetectorRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _DetectorRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _DetectorRoutes[key];
    }
  });
});

var _CorrelationRoutes = require("./CorrelationRoutes");

Object.keys(_CorrelationRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _CorrelationRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _CorrelationRoutes[key];
    }
  });
});

var _FindingsRoutes = require("./FindingsRoutes");

Object.keys(_FindingsRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _FindingsRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _FindingsRoutes[key];
    }
  });
});

var _OpenSearchRoutes = require("./OpenSearchRoutes");

Object.keys(_OpenSearchRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _OpenSearchRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _OpenSearchRoutes[key];
    }
  });
});

var _FieldMappingRoutes = require("./FieldMappingRoutes");

Object.keys(_FieldMappingRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _FieldMappingRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _FieldMappingRoutes[key];
    }
  });
});

var _IndexRoutes = require("./IndexRoutes");

Object.keys(_IndexRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _IndexRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _IndexRoutes[key];
    }
  });
});

var _AlertRoutes = require("./AlertRoutes");

Object.keys(_AlertRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _AlertRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _AlertRoutes[key];
    }
  });
});

var _NotificationsRoutes = require("./NotificationsRoutes");

Object.keys(_NotificationsRoutes).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _NotificationsRoutes[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _NotificationsRoutes[key];
    }
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL0RldGVjdG9yUm91dGVzJztcbmV4cG9ydCAqIGZyb20gJy4vQ29ycmVsYXRpb25Sb3V0ZXMnO1xuZXhwb3J0ICogZnJvbSAnLi9GaW5kaW5nc1JvdXRlcyc7XG5leHBvcnQgKiBmcm9tICcuL09wZW5TZWFyY2hSb3V0ZXMnO1xuZXhwb3J0ICogZnJvbSAnLi9GaWVsZE1hcHBpbmdSb3V0ZXMnO1xuZXhwb3J0ICogZnJvbSAnLi9JbmRleFJvdXRlcyc7XG5leHBvcnQgKiBmcm9tICcuL0FsZXJ0Um91dGVzJztcbmV4cG9ydCAqIGZyb20gJy4vTm90aWZpY2F0aW9uc1JvdXRlcyc7XG4iXX0=