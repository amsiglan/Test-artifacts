"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _RuleOptions = _interopRequireDefault(require("./RuleOptions.mock"));

var _RulePage = _interopRequireDefault(require("./RulePage.mock"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
var _default = {
  RuleOptions: _RuleOptions.default,
  RulePage: _RulePage.default
};
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlJ1bGVPcHRpb25zIiwiUnVsZVBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFLQTs7QUFDQTs7OztBQU5BO0FBQ0E7QUFDQTtBQUNBO2VBS2U7QUFDYkEsRUFBQUEsV0FBVyxFQUFYQSxvQkFEYTtBQUViQyxFQUFBQSxRQUFRLEVBQVJBO0FBRmEsQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IFJ1bGVPcHRpb25zIGZyb20gJy4vUnVsZU9wdGlvbnMubW9jayc7XG5pbXBvcnQgUnVsZVBhZ2UgZnJvbSAnLi9SdWxlUGFnZS5tb2NrJztcblxuZXhwb3J0IGRlZmF1bHQge1xuICBSdWxlT3B0aW9ucyxcbiAgUnVsZVBhZ2UsXG59O1xuIl19