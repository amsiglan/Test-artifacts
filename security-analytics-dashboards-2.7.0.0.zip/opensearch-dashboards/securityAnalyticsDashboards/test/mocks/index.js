"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _services = _interopRequireDefault(require("./services"));

var _Rules = _interopRequireDefault(require("./Rules"));

var _Detectors = _interopRequireDefault(require("./Detectors"));

var _CreateDetector = _interopRequireDefault(require("./CreateDetector"));

var _Alerts = _interopRequireDefault(require("./Alerts"));

var _browserHistory = _interopRequireDefault(require("./services/browserHistory.mock"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
var _default = {
  services: _services.default,
  rules: _Rules.default,
  detectors: _Detectors.default,
  createDetector: _CreateDetector.default,
  alerts: _Alerts.default,
  history: _browserHistory.default
};
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInNlcnZpY2VzIiwicnVsZXMiLCJkZXRlY3RvcnMiLCJjcmVhdGVEZXRlY3RvciIsImFsZXJ0cyIsImhpc3RvcnkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFLQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7OztBQVZBO0FBQ0E7QUFDQTtBQUNBO2VBU2U7QUFBRUEsRUFBQUEsUUFBUSxFQUFSQSxpQkFBRjtBQUFZQyxFQUFBQSxLQUFLLEVBQUxBLGNBQVo7QUFBbUJDLEVBQUFBLFNBQVMsRUFBVEEsa0JBQW5CO0FBQThCQyxFQUFBQSxjQUFjLEVBQWRBLHVCQUE5QjtBQUE4Q0MsRUFBQUEsTUFBTSxFQUFOQSxlQUE5QztBQUFzREMsRUFBQUEsT0FBTyxFQUFQQTtBQUF0RCxDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5pbXBvcnQgc2VydmljZXMgZnJvbSAnLi9zZXJ2aWNlcyc7XG5pbXBvcnQgcnVsZXMgZnJvbSAnLi9SdWxlcyc7XG5pbXBvcnQgZGV0ZWN0b3JzIGZyb20gJy4vRGV0ZWN0b3JzJztcbmltcG9ydCBjcmVhdGVEZXRlY3RvciBmcm9tICcuL0NyZWF0ZURldGVjdG9yJztcbmltcG9ydCBhbGVydHMgZnJvbSAnLi9BbGVydHMnO1xuaW1wb3J0IGhpc3RvcnkgZnJvbSAnLi9zZXJ2aWNlcy9icm93c2VySGlzdG9yeS5tb2NrJztcblxuZXhwb3J0IGRlZmF1bHQgeyBzZXJ2aWNlcywgcnVsZXMsIGRldGVjdG9ycywgY3JlYXRlRGV0ZWN0b3IsIGFsZXJ0cywgaGlzdG9yeSB9O1xuIl19