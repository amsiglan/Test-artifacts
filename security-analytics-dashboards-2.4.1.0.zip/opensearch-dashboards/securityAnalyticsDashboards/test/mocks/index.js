"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "browserServicesMock", {
  enumerable: true,
  get: function () {
    return _browserServicesMock.default;
  }
});
Object.defineProperty(exports, "httpClientMock", {
  enumerable: true,
  get: function () {
    return _httpClientMock.default;
  }
});

var _browserServicesMock = _interopRequireDefault(require("./browserServicesMock"));

var _httpClientMock = _interopRequireDefault(require("./httpClientMock"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUtBOztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5pbXBvcnQgYnJvd3NlclNlcnZpY2VzTW9jayBmcm9tICcuL2Jyb3dzZXJTZXJ2aWNlc01vY2snO1xuaW1wb3J0IGh0dHBDbGllbnRNb2NrIGZyb20gJy4vaHR0cENsaWVudE1vY2snO1xuXG5leHBvcnQgeyBicm93c2VyU2VydmljZXNNb2NrLCBodHRwQ2xpZW50TW9jayB9O1xuIl19