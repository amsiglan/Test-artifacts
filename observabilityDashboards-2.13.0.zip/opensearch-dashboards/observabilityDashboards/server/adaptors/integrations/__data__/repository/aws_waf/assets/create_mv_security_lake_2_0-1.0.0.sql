CREATE MATERIALIZED VIEW {table_name}__mview AS
SELECT
    CAST(FROM_UNIXTIME(`time`/ 1000) AS TIMESTAMP) AS `@timestamp`,
    CAST(IFNULL(metadata.product.version, 'Unknown') AS STRING) AS `aws.waf.formatVersion`,
    CAST(IFNULL(metadata.product.feature.uid, 'Unknown') AS STRING) AS `aws.waf.webaclId`,
    CAST(IFNULL(firewall_rule.uid, 'Unknown') AS STRING) AS `aws.waf.terminatingRuleId`,
    CAST(IFNULL(firewall_rule.type, 'Unknown') AS STRING) AS `aws.waf.terminatingRuleType`,
    CAST(IFNULL(action, 'Unknown') AS STRING) AS `aws.waf.action`,
    CAST(IFNULL(src_endpoint.svc_name, 'Unknown') AS STRING) AS `aws.waf.httpSourceName`,
    CAST(IFNULL(src_endpoint.uid, 'Unknown') AS STRING) AS `aws.waf.httpSourceId`,
    CAST(IFNULL(src_endpoint.ip, '0.0.0.0') AS STRING) AS `aws.waf.httpRequest.clientIp`,
    CAST(IFNULL(src_endpoint.location.country, 'Unknown') AS STRING) AS `aws.waf.httpRequest.country`,
    CAST(IFNULL(http_request.http_method, 'Unknown') AS STRING) AS `aws.waf.httpRequest.httpMethod`,
    CAST(IFNULL(http_request.url.path, 'Unknown') AS STRING) AS `aws.waf.httpRequest.uri`,
    http_request.args AS `aws.waf.httpRequest.args`,
    CAST(IFNULL(unmapped['ruleGroupList[].ruleGroupId'], 'Unknown') AS STRING) AS `aws.waf.ruleGroupList.ruleGroupId`,
    CAST(IFNULL(unmapped['ruleGroupList[].terminatingRule.action'], 'Unknown') AS STRING) AS `aws.waf.ruleGroupList.terminatingRule.action`,
    CAST(IFNULL(unmapped['ruleGroupList[].terminatingRule.ruleId'], 'Unknown') AS STRING) AS `aws.waf.ruleGroupList.terminatingRule.ruleId`,
    CAST(IFNULL(unmapped['nonTerminatingMatchingRules[].ruleId'], 'Unknown') AS STRING) AS `aws.waf.nonTerminatingMatchingRules.ruleId`,
    CAST(IFNULL(unmapped['nonTerminatingMatchingRules[].action'], 'Unknown') AS STRING) AS `aws.waf.nonTerminatingMatchingRules.action`,
    CAST(IFNULL(http_status, 0) AS LONG) AS `aws.waf.responseCodeSent`,
    metadata.labels AS `aws.waf.labels`,
    CAST(IFNULL(unmapped['ja3Fingerprint'], 'Unknown') AS STRING) as `aws.waf.ja3Fingerprint`
FROM
    {table_name}
WITH (
  auto_refresh = true,
  refresh_interval = '15 Minute',
  checkpoint_location = '{s3_checkpoint_location}',
  watermark_delay = '1 Minute',
  extra_options = '{ "{table_name}": { "maxFilesPerTrigger": "10" }}'
)
