"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "PPLNode", {
  enumerable: true,
  get: function () {
    return _node.PPLNode;
  }
});
var _node = require("./node");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZSIsInJlcXVpcmUiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmV4cG9ydCB7IFBQTE5vZGUgfSBmcm9tICcuL25vZGUnO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUtBLElBQUFBLEtBQUEsR0FBQUMsT0FBQSJ9