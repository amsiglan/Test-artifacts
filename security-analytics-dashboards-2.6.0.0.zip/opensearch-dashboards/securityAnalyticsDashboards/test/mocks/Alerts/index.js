"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _PeriodSchedule = _interopRequireDefault(require("./PeriodSchedule.mock"));

var _AlertItem = _interopRequireDefault(require("./AlertItem.mock"));

var _AlertFlyout = _interopRequireDefault(require("./components/AlertFlyout/AlertFlyout.mock"));

var _Alerts = _interopRequireDefault(require("./Alerts.mock"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
var _default = {
  alerts: _Alerts.default,
  periodSchedule: _PeriodSchedule.default,
  alertItem: _AlertItem.default,
  alertFlyout: _AlertFlyout.default
};
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImFsZXJ0cyIsInBlcmlvZFNjaGVkdWxlIiwiYWxlcnRJdGVtIiwiYWxlcnRGbHlvdXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFLQTs7QUFDQTs7QUFDQTs7QUFDQTs7OztBQVJBO0FBQ0E7QUFDQTtBQUNBO2VBT2U7QUFDYkEsRUFBQUEsTUFBTSxFQUFOQSxlQURhO0FBRWJDLEVBQUFBLGNBQWMsRUFBZEEsdUJBRmE7QUFHYkMsRUFBQUEsU0FBUyxFQUFUQSxrQkFIYTtBQUliQyxFQUFBQSxXQUFXLEVBQVhBO0FBSmEsQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IHBlcmlvZFNjaGVkdWxlIGZyb20gJy4vUGVyaW9kU2NoZWR1bGUubW9jayc7XG5pbXBvcnQgYWxlcnRJdGVtIGZyb20gJy4vQWxlcnRJdGVtLm1vY2snO1xuaW1wb3J0IGFsZXJ0Rmx5b3V0IGZyb20gJy4vY29tcG9uZW50cy9BbGVydEZseW91dC9BbGVydEZseW91dC5tb2NrJztcbmltcG9ydCBhbGVydHMgZnJvbSAnLi9BbGVydHMubW9jayc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgYWxlcnRzLFxuICBwZXJpb2RTY2hlZHVsZSxcbiAgYWxlcnRJdGVtLFxuICBhbGVydEZseW91dCxcbn07XG4iXX0=