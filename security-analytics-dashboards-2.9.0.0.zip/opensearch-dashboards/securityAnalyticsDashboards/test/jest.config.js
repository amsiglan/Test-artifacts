"use strict";

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
module.exports = {
  rootDir: '../',
  setupFiles: ['<rootDir>/test/polyfills.ts', '<rootDir>/test/setupTests.ts'],
  setupFilesAfterEnv: ['<rootDir>/test/setup.jest.ts'],
  roots: ['<rootDir>'],
  coverageDirectory: './coverage',
  moduleNameMapper: {
    '\\.(css|less|scss)$': '<rootDir>/test/mocks/styleMock.ts',
    '^ui/(.*)': '<rootDir>/../../src/legacy/ui/public/$1/'
  },
  coverageReporters: ['lcov', 'text', 'cobertura'],
  testMatch: ['**/*.test.js', '**/*.test.jsx', '**/*.test.ts', '**/*.test.tsx'],
  collectCoverageFrom: ['**/*.ts', '**/*.tsx', '**/*.js', '**/*.jsx', '!**/models/**', '!**/node_modules/**', '!**/index.ts', '!<rootDir>/index.js', '!<rootDir>/public/app.js', '!<rootDir>/public/temporary/**', '!<rootDir>/babel.config.js', '!<rootDir>/test/**', '!<rootDir>/server/**', '!<rootDir>/coverage/**', '!<rootDir>/scripts/**', '!<rootDir>/build/**', '!<rootDir>/cypress/**', '!**/vendor/**'],
  clearMocks: true,
  testPathIgnorePatterns: ['<rootDir>/build/', '<rootDir>/node_modules/'],
  transformIgnorePatterns: [// ignore all node_modules except those which require babel transforms to
  // handle newer syntax like `??=` which is not already transformed by the
  // package and not yet supported in the node version we use.
  '[/\\\\]node_modules(?![\\/\\\\](vega-lite))[/\\\\].+\\.js$'],
  modulePathIgnorePatterns: ['securityAnalyticsDashboards'],
  testEnvironment: 'jsdom',
  snapshotSerializers: ['enzyme-to-json/serializer']
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImplc3QuY29uZmlnLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydHMiLCJyb290RGlyIiwic2V0dXBGaWxlcyIsInNldHVwRmlsZXNBZnRlckVudiIsInJvb3RzIiwiY292ZXJhZ2VEaXJlY3RvcnkiLCJtb2R1bGVOYW1lTWFwcGVyIiwiY292ZXJhZ2VSZXBvcnRlcnMiLCJ0ZXN0TWF0Y2giLCJjb2xsZWN0Q292ZXJhZ2VGcm9tIiwiY2xlYXJNb2NrcyIsInRlc3RQYXRoSWdub3JlUGF0dGVybnMiLCJ0cmFuc2Zvcm1JZ25vcmVQYXR0ZXJucyIsIm1vZHVsZVBhdGhJZ25vcmVQYXR0ZXJucyIsInRlc3RFbnZpcm9ubWVudCIsInNuYXBzaG90U2VyaWFsaXplcnMiXSwibWFwcGluZ3MiOiI7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2ZDLEVBQUFBLE9BQU8sRUFBRSxLQURNO0FBRWZDLEVBQUFBLFVBQVUsRUFBRSxDQUFDLDZCQUFELEVBQWdDLDhCQUFoQyxDQUZHO0FBR2ZDLEVBQUFBLGtCQUFrQixFQUFFLENBQUMsOEJBQUQsQ0FITDtBQUlmQyxFQUFBQSxLQUFLLEVBQUUsQ0FBQyxXQUFELENBSlE7QUFLZkMsRUFBQUEsaUJBQWlCLEVBQUUsWUFMSjtBQU1mQyxFQUFBQSxnQkFBZ0IsRUFBRTtBQUNoQiwyQkFBdUIsbUNBRFA7QUFFaEIsZ0JBQVk7QUFGSSxHQU5IO0FBVWZDLEVBQUFBLGlCQUFpQixFQUFFLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsV0FBakIsQ0FWSjtBQVdmQyxFQUFBQSxTQUFTLEVBQUUsQ0FBQyxjQUFELEVBQWlCLGVBQWpCLEVBQWtDLGNBQWxDLEVBQWtELGVBQWxELENBWEk7QUFZZkMsRUFBQUEsbUJBQW1CLEVBQUUsQ0FDbkIsU0FEbUIsRUFFbkIsVUFGbUIsRUFHbkIsU0FIbUIsRUFJbkIsVUFKbUIsRUFLbkIsZUFMbUIsRUFNbkIscUJBTm1CLEVBT25CLGNBUG1CLEVBUW5CLHFCQVJtQixFQVNuQiwwQkFUbUIsRUFVbkIsZ0NBVm1CLEVBV25CLDRCQVhtQixFQVluQixvQkFabUIsRUFhbkIsc0JBYm1CLEVBY25CLHdCQWRtQixFQWVuQix1QkFmbUIsRUFnQm5CLHFCQWhCbUIsRUFpQm5CLHVCQWpCbUIsRUFrQm5CLGVBbEJtQixDQVpOO0FBZ0NmQyxFQUFBQSxVQUFVLEVBQUUsSUFoQ0c7QUFpQ2ZDLEVBQUFBLHNCQUFzQixFQUFFLENBQUMsa0JBQUQsRUFBcUIseUJBQXJCLENBakNUO0FBa0NmQyxFQUFBQSx1QkFBdUIsRUFBRSxDQUN2QjtBQUNBO0FBQ0E7QUFDQSw4REFKdUIsQ0FsQ1Y7QUF3Q2ZDLEVBQUFBLHdCQUF3QixFQUFFLENBQUMsNkJBQUQsQ0F4Q1g7QUF5Q2ZDLEVBQUFBLGVBQWUsRUFBRSxPQXpDRjtBQTBDZkMsRUFBQUEsbUJBQW1CLEVBQUUsQ0FBQywyQkFBRDtBQTFDTixDQUFqQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIHJvb3REaXI6ICcuLi8nLFxuICBzZXR1cEZpbGVzOiBbJzxyb290RGlyPi90ZXN0L3BvbHlmaWxscy50cycsICc8cm9vdERpcj4vdGVzdC9zZXR1cFRlc3RzLnRzJ10sXG4gIHNldHVwRmlsZXNBZnRlckVudjogWyc8cm9vdERpcj4vdGVzdC9zZXR1cC5qZXN0LnRzJ10sXG4gIHJvb3RzOiBbJzxyb290RGlyPiddLFxuICBjb3ZlcmFnZURpcmVjdG9yeTogJy4vY292ZXJhZ2UnLFxuICBtb2R1bGVOYW1lTWFwcGVyOiB7XG4gICAgJ1xcXFwuKGNzc3xsZXNzfHNjc3MpJCc6ICc8cm9vdERpcj4vdGVzdC9tb2Nrcy9zdHlsZU1vY2sudHMnLFxuICAgICdedWkvKC4qKSc6ICc8cm9vdERpcj4vLi4vLi4vc3JjL2xlZ2FjeS91aS9wdWJsaWMvJDEvJyxcbiAgfSxcbiAgY292ZXJhZ2VSZXBvcnRlcnM6IFsnbGNvdicsICd0ZXh0JywgJ2NvYmVydHVyYSddLFxuICB0ZXN0TWF0Y2g6IFsnKiovKi50ZXN0LmpzJywgJyoqLyoudGVzdC5qc3gnLCAnKiovKi50ZXN0LnRzJywgJyoqLyoudGVzdC50c3gnXSxcbiAgY29sbGVjdENvdmVyYWdlRnJvbTogW1xuICAgICcqKi8qLnRzJyxcbiAgICAnKiovKi50c3gnLFxuICAgICcqKi8qLmpzJyxcbiAgICAnKiovKi5qc3gnLFxuICAgICchKiovbW9kZWxzLyoqJyxcbiAgICAnISoqL25vZGVfbW9kdWxlcy8qKicsXG4gICAgJyEqKi9pbmRleC50cycsXG4gICAgJyE8cm9vdERpcj4vaW5kZXguanMnLFxuICAgICchPHJvb3REaXI+L3B1YmxpYy9hcHAuanMnLFxuICAgICchPHJvb3REaXI+L3B1YmxpYy90ZW1wb3JhcnkvKionLFxuICAgICchPHJvb3REaXI+L2JhYmVsLmNvbmZpZy5qcycsXG4gICAgJyE8cm9vdERpcj4vdGVzdC8qKicsXG4gICAgJyE8cm9vdERpcj4vc2VydmVyLyoqJyxcbiAgICAnITxyb290RGlyPi9jb3ZlcmFnZS8qKicsXG4gICAgJyE8cm9vdERpcj4vc2NyaXB0cy8qKicsXG4gICAgJyE8cm9vdERpcj4vYnVpbGQvKionLFxuICAgICchPHJvb3REaXI+L2N5cHJlc3MvKionLFxuICAgICchKiovdmVuZG9yLyoqJyxcbiAgXSxcbiAgY2xlYXJNb2NrczogdHJ1ZSxcbiAgdGVzdFBhdGhJZ25vcmVQYXR0ZXJuczogWyc8cm9vdERpcj4vYnVpbGQvJywgJzxyb290RGlyPi9ub2RlX21vZHVsZXMvJ10sXG4gIHRyYW5zZm9ybUlnbm9yZVBhdHRlcm5zOiBbXG4gICAgLy8gaWdub3JlIGFsbCBub2RlX21vZHVsZXMgZXhjZXB0IHRob3NlIHdoaWNoIHJlcXVpcmUgYmFiZWwgdHJhbnNmb3JtcyB0b1xuICAgIC8vIGhhbmRsZSBuZXdlciBzeW50YXggbGlrZSBgPz89YCB3aGljaCBpcyBub3QgYWxyZWFkeSB0cmFuc2Zvcm1lZCBieSB0aGVcbiAgICAvLyBwYWNrYWdlIGFuZCBub3QgeWV0IHN1cHBvcnRlZCBpbiB0aGUgbm9kZSB2ZXJzaW9uIHdlIHVzZS5cbiAgICAnWy9cXFxcXFxcXF1ub2RlX21vZHVsZXMoPyFbXFxcXC9cXFxcXFxcXF0odmVnYS1saXRlKSlbL1xcXFxcXFxcXS4rXFxcXC5qcyQnLFxuICBdLFxuICBtb2R1bGVQYXRoSWdub3JlUGF0dGVybnM6IFsnc2VjdXJpdHlBbmFseXRpY3NEYXNoYm9hcmRzJ10sXG4gIHRlc3RFbnZpcm9ubWVudDogJ2pzZG9tJyxcbiAgc25hcHNob3RTZXJpYWxpemVyczogWydlbnp5bWUtdG8tanNvbi9zZXJpYWxpemVyJ10sXG59O1xuIl19