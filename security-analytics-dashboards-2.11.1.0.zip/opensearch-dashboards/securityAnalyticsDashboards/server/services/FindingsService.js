"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _constants = require("../utils/constants");

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } /*
                                                                                                                                                                                                                   * Copyright OpenSearch Contributors
                                                                                                                                                                                                                   * SPDX-License-Identifier: Apache-2.0
                                                                                                                                                                                                                   */

class FindingsService {
  constructor(osDriver) {
    _defineProperty(this, "osDriver", void 0);

    _defineProperty(this, "getFindings", async (context, request, response) => {
      try {
        const {
          detectorType,
          detectorId,
          sortOrder,
          size
        } = request.query;
        const defaultParams = {
          sortOrder,
          size
        };
        let params;

        if (detectorId) {
          params = { ...defaultParams,
            detectorId
          };
        } else if (detectorType) {
          params = { ...defaultParams,
            detectorType
          };
        } else {
          throw Error(`Invalid request params: detectorId or detectorType must be specified`);
        }

        const {
          callAsCurrentUser: callWithRequest
        } = this.osDriver.asScoped(request);
        const getFindingsResponse = await callWithRequest(_constants.CLIENT_DETECTOR_METHODS.GET_FINDINGS, params);
        getFindingsResponse.findings.forEach(finding => {
          const types = [];

          if (!finding.queries.every(query => query.id.startsWith('threat_intel_'))) {
            types.push('Detection rules');
          }

          if (finding.queries.some(query => query.id.startsWith('threat_intel_'))) {
            types.push('Threat intelligence');
            finding['ruleSeverity'] = 'high';
          }

          finding['detectionType'] = types.join(', ');
        });
        return response.custom({
          statusCode: 200,
          body: {
            ok: true,
            response: getFindingsResponse
          }
        });
      } catch (error) {
        console.error('Security Analytics - FindingsService - getFindings:', error);
        return response.custom({
          statusCode: 200,
          body: {
            ok: false,
            error: error.message
          }
        });
      }
    });

    this.osDriver = osDriver;
  }
  /**
   * Calls backend GET Findings API.
   */


}

exports.default = FindingsService;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkZpbmRpbmdzU2VydmljZS50cyJdLCJuYW1lcyI6WyJGaW5kaW5nc1NlcnZpY2UiLCJjb25zdHJ1Y3RvciIsIm9zRHJpdmVyIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImRldGVjdG9yVHlwZSIsImRldGVjdG9ySWQiLCJzb3J0T3JkZXIiLCJzaXplIiwicXVlcnkiLCJkZWZhdWx0UGFyYW1zIiwicGFyYW1zIiwiRXJyb3IiLCJjYWxsQXNDdXJyZW50VXNlciIsImNhbGxXaXRoUmVxdWVzdCIsImFzU2NvcGVkIiwiZ2V0RmluZGluZ3NSZXNwb25zZSIsIkNMSUVOVF9ERVRFQ1RPUl9NRVRIT0RTIiwiR0VUX0ZJTkRJTkdTIiwiZmluZGluZ3MiLCJmb3JFYWNoIiwiZmluZGluZyIsInR5cGVzIiwicXVlcmllcyIsImV2ZXJ5IiwiaWQiLCJzdGFydHNXaXRoIiwicHVzaCIsInNvbWUiLCJqb2luIiwiY3VzdG9tIiwic3RhdHVzQ29kZSIsImJvZHkiLCJvayIsImVycm9yIiwiY29uc29sZSIsIm1lc3NhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFlQTs7a05BZkE7QUFDQTtBQUNBO0FBQ0E7O0FBY2UsTUFBTUEsZUFBTixDQUFzQjtBQUduQ0MsRUFBQUEsV0FBVyxDQUFDQyxRQUFELEVBQXVDO0FBQUE7O0FBQUEseUNBT3BDLE9BQ1pDLE9BRFksRUFFWkMsT0FGWSxFQUdaQyxRQUhZLEtBTVQ7QUFDSCxVQUFJO0FBQ0YsY0FBTTtBQUFFQyxVQUFBQSxZQUFGO0FBQWdCQyxVQUFBQSxVQUFoQjtBQUE0QkMsVUFBQUEsU0FBNUI7QUFBdUNDLFVBQUFBO0FBQXZDLFlBQWdETCxPQUFPLENBQUNNLEtBQTlEO0FBQ0EsY0FBTUMsYUFBYSxHQUFHO0FBQ3BCSCxVQUFBQSxTQURvQjtBQUVwQkMsVUFBQUE7QUFGb0IsU0FBdEI7QUFJQSxZQUFJRyxNQUFKOztBQUVBLFlBQUlMLFVBQUosRUFBZ0I7QUFDZEssVUFBQUEsTUFBTSxHQUFHLEVBQ1AsR0FBR0QsYUFESTtBQUVQSixZQUFBQTtBQUZPLFdBQVQ7QUFJRCxTQUxELE1BS08sSUFBSUQsWUFBSixFQUFrQjtBQUN2Qk0sVUFBQUEsTUFBTSxHQUFHLEVBQ1AsR0FBR0QsYUFESTtBQUVQTCxZQUFBQTtBQUZPLFdBQVQ7QUFJRCxTQUxNLE1BS0E7QUFDTCxnQkFBTU8sS0FBSyxDQUFFLHNFQUFGLENBQVg7QUFDRDs7QUFFRCxjQUFNO0FBQUVDLFVBQUFBLGlCQUFpQixFQUFFQztBQUFyQixZQUF5QyxLQUFLYixRQUFMLENBQWNjLFFBQWQsQ0FBdUJaLE9BQXZCLENBQS9DO0FBQ0EsY0FBTWEsbUJBQXdDLEdBQUcsTUFBTUYsZUFBZSxDQUNwRUcsbUNBQXdCQyxZQUQ0QyxFQUVwRVAsTUFGb0UsQ0FBdEU7QUFLQUssUUFBQUEsbUJBQW1CLENBQUNHLFFBQXBCLENBQTZCQyxPQUE3QixDQUFzQ0MsT0FBRCxJQUFrQjtBQUNyRCxnQkFBTUMsS0FBZSxHQUFHLEVBQXhCOztBQUNBLGNBQUksQ0FBQ0QsT0FBTyxDQUFDRSxPQUFSLENBQWdCQyxLQUFoQixDQUF1QmYsS0FBRCxJQUFnQkEsS0FBSyxDQUFDZ0IsRUFBTixDQUFTQyxVQUFULENBQW9CLGVBQXBCLENBQXRDLENBQUwsRUFBa0Y7QUFDaEZKLFlBQUFBLEtBQUssQ0FBQ0ssSUFBTixDQUFXLGlCQUFYO0FBQ0Q7O0FBQ0QsY0FBSU4sT0FBTyxDQUFDRSxPQUFSLENBQWdCSyxJQUFoQixDQUFzQm5CLEtBQUQsSUFBZ0JBLEtBQUssQ0FBQ2dCLEVBQU4sQ0FBU0MsVUFBVCxDQUFvQixlQUFwQixDQUFyQyxDQUFKLEVBQWdGO0FBQzlFSixZQUFBQSxLQUFLLENBQUNLLElBQU4sQ0FBVyxxQkFBWDtBQUNBTixZQUFBQSxPQUFPLENBQUMsY0FBRCxDQUFQLEdBQTBCLE1BQTFCO0FBQ0Q7O0FBRURBLFVBQUFBLE9BQU8sQ0FBQyxlQUFELENBQVAsR0FBMkJDLEtBQUssQ0FBQ08sSUFBTixDQUFXLElBQVgsQ0FBM0I7QUFDRCxTQVhEO0FBYUEsZUFBT3pCLFFBQVEsQ0FBQzBCLE1BQVQsQ0FBZ0I7QUFDckJDLFVBQUFBLFVBQVUsRUFBRSxHQURTO0FBRXJCQyxVQUFBQSxJQUFJLEVBQUU7QUFDSkMsWUFBQUEsRUFBRSxFQUFFLElBREE7QUFFSjdCLFlBQUFBLFFBQVEsRUFBRVk7QUFGTjtBQUZlLFNBQWhCLENBQVA7QUFPRCxPQWhERCxDQWdERSxPQUFPa0IsS0FBUCxFQUFtQjtBQUNuQkMsUUFBQUEsT0FBTyxDQUFDRCxLQUFSLENBQWMscURBQWQsRUFBcUVBLEtBQXJFO0FBQ0EsZUFBTzlCLFFBQVEsQ0FBQzBCLE1BQVQsQ0FBZ0I7QUFDckJDLFVBQUFBLFVBQVUsRUFBRSxHQURTO0FBRXJCQyxVQUFBQSxJQUFJLEVBQUU7QUFDSkMsWUFBQUEsRUFBRSxFQUFFLEtBREE7QUFFSkMsWUFBQUEsS0FBSyxFQUFFQSxLQUFLLENBQUNFO0FBRlQ7QUFGZSxTQUFoQixDQUFQO0FBT0Q7QUFDRixLQXhFaUQ7O0FBQ2hELFNBQUtuQyxRQUFMLEdBQWdCQSxRQUFoQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFUcUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7XG4gIElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50LFxuICBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICBJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZSxcbiAgUmVzcG9uc2VFcnJvcixcbiAgUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxufSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IEdldEZpbmRpbmdzUGFyYW1zLCBHZXRGaW5kaW5nc1Jlc3BvbnNlIH0gZnJvbSAnLi4vbW9kZWxzL2ludGVyZmFjZXMnO1xuaW1wb3J0IHsgU2VydmVyUmVzcG9uc2UgfSBmcm9tICcuLi9tb2RlbHMvdHlwZXMnO1xuaW1wb3J0IHsgQ0xJRU5UX0RFVEVDVE9SX01FVEhPRFMgfSBmcm9tICcuLi91dGlscy9jb25zdGFudHMnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBGaW5kaW5nc1NlcnZpY2Uge1xuICBvc0RyaXZlcjogSUxlZ2FjeUN1c3RvbUNsdXN0ZXJDbGllbnQ7XG5cbiAgY29uc3RydWN0b3Iob3NEcml2ZXI6IElMZWdhY3lDdXN0b21DbHVzdGVyQ2xpZW50KSB7XG4gICAgdGhpcy5vc0RyaXZlciA9IG9zRHJpdmVyO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGxzIGJhY2tlbmQgR0VUIEZpbmRpbmdzIEFQSS5cbiAgICovXG4gIGdldEZpbmRpbmdzID0gYXN5bmMgKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3Q8e30sIEdldEZpbmRpbmdzUGFyYW1zPixcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcbiAgKTogUHJvbWlzZTxcbiAgICBJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxTZXJ2ZXJSZXNwb25zZTxHZXRGaW5kaW5nc1Jlc3BvbnNlPiB8IFJlc3BvbnNlRXJyb3I+XG4gID4gPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRldGVjdG9yVHlwZSwgZGV0ZWN0b3JJZCwgc29ydE9yZGVyLCBzaXplIH0gPSByZXF1ZXN0LnF1ZXJ5O1xuICAgICAgY29uc3QgZGVmYXVsdFBhcmFtcyA9IHtcbiAgICAgICAgc29ydE9yZGVyLFxuICAgICAgICBzaXplLFxuICAgICAgfTtcbiAgICAgIGxldCBwYXJhbXM6IEdldEZpbmRpbmdzUGFyYW1zO1xuXG4gICAgICBpZiAoZGV0ZWN0b3JJZCkge1xuICAgICAgICBwYXJhbXMgPSB7XG4gICAgICAgICAgLi4uZGVmYXVsdFBhcmFtcyxcbiAgICAgICAgICBkZXRlY3RvcklkLFxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIGlmIChkZXRlY3RvclR5cGUpIHtcbiAgICAgICAgcGFyYW1zID0ge1xuICAgICAgICAgIC4uLmRlZmF1bHRQYXJhbXMsXG4gICAgICAgICAgZGV0ZWN0b3JUeXBlLFxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgRXJyb3IoYEludmFsaWQgcmVxdWVzdCBwYXJhbXM6IGRldGVjdG9ySWQgb3IgZGV0ZWN0b3JUeXBlIG11c3QgYmUgc3BlY2lmaWVkYCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgY2FsbEFzQ3VycmVudFVzZXI6IGNhbGxXaXRoUmVxdWVzdCB9ID0gdGhpcy5vc0RyaXZlci5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGNvbnN0IGdldEZpbmRpbmdzUmVzcG9uc2U6IEdldEZpbmRpbmdzUmVzcG9uc2UgPSBhd2FpdCBjYWxsV2l0aFJlcXVlc3QoXG4gICAgICAgIENMSUVOVF9ERVRFQ1RPUl9NRVRIT0RTLkdFVF9GSU5ESU5HUyxcbiAgICAgICAgcGFyYW1zXG4gICAgICApO1xuXG4gICAgICBnZXRGaW5kaW5nc1Jlc3BvbnNlLmZpbmRpbmdzLmZvckVhY2goKGZpbmRpbmc6IGFueSkgPT4ge1xuICAgICAgICBjb25zdCB0eXBlczogc3RyaW5nW10gPSBbXTtcbiAgICAgICAgaWYgKCFmaW5kaW5nLnF1ZXJpZXMuZXZlcnkoKHF1ZXJ5OiBhbnkpID0+IHF1ZXJ5LmlkLnN0YXJ0c1dpdGgoJ3RocmVhdF9pbnRlbF8nKSkpIHtcbiAgICAgICAgICB0eXBlcy5wdXNoKCdEZXRlY3Rpb24gcnVsZXMnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZmluZGluZy5xdWVyaWVzLnNvbWUoKHF1ZXJ5OiBhbnkpID0+IHF1ZXJ5LmlkLnN0YXJ0c1dpdGgoJ3RocmVhdF9pbnRlbF8nKSkpIHtcbiAgICAgICAgICB0eXBlcy5wdXNoKCdUaHJlYXQgaW50ZWxsaWdlbmNlJyk7XG4gICAgICAgICAgZmluZGluZ1sncnVsZVNldmVyaXR5J10gPSAnaGlnaCc7XG4gICAgICAgIH1cblxuICAgICAgICBmaW5kaW5nWydkZXRlY3Rpb25UeXBlJ10gPSB0eXBlcy5qb2luKCcsICcpO1xuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b20oe1xuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICByZXNwb25zZTogZ2V0RmluZGluZ3NSZXNwb25zZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NlY3VyaXR5IEFuYWx5dGljcyAtIEZpbmRpbmdzU2VydmljZSAtIGdldEZpbmRpbmdzOicsIGVycm9yKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b20oe1xuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgZXJyb3I6IGVycm9yLm1lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG59XG4iXX0=